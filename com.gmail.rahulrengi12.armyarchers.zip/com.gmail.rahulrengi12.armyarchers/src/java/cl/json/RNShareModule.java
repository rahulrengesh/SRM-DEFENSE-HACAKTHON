/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.Intent
 *  android.net.Uri
 *  com.facebook.react.bridge.ActivityEventListener
 *  com.facebook.react.bridge.Callback
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.bridge.ReadableMap
 *  java.io.PrintStream
 *  java.lang.Enum
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.HashMap
 *  java.util.Map
 *  javax.annotation.Nullable
 */
package cl.json;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import cl.json.RNShareModule;
import cl.json.social.EmailShare;
import cl.json.social.FacebookPagesManagerShare;
import cl.json.social.FacebookShare;
import cl.json.social.GenericShare;
import cl.json.social.GooglePlusShare;
import cl.json.social.InstagramShare;
import cl.json.social.LinkedinShare;
import cl.json.social.MessengerShare;
import cl.json.social.PinterestShare;
import cl.json.social.SMSShare;
import cl.json.social.ShareIntent;
import cl.json.social.SnapChatShare;
import cl.json.social.TargetChosenReceiver;
import cl.json.social.TwitterShare;
import cl.json.social.WhatsAppShare;
import com.facebook.react.bridge.ActivityEventListener;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nullable;

public class RNShareModule
extends ReactContextBaseJavaModule
implements ActivityEventListener {
    public static final int SHARE_REQUEST_CODE = 16845;
    private final ReactApplicationContext reactContext;

    public RNShareModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
        reactApplicationContext.addActivityEventListener((ActivityEventListener)this);
        this.reactContext = reactApplicationContext;
    }

    @Nullable
    public Map<String, Object> getConstants() {
        HashMap hashMap = new HashMap();
        for (SHARES sHARES : SHARES.values()) {
            hashMap.put((Object)sHARES.toString().toUpperCase(), (Object)sHARES.toString());
        }
        return hashMap;
    }

    public String getName() {
        return "RNShare";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @ReactMethod
    public void isBase64File(String string2, Callback callback, Callback callback2) {
        try {
            String string3 = Uri.parse((String)string2).getScheme();
            if (string3 != null && string3.equals((Object)"data")) {
                Object[] arrobject = new Object[]{true};
                callback2.invoke(arrobject);
                return;
            }
            Object[] arrobject = new Object[]{false};
            callback2.invoke(arrobject);
            return;
        }
        catch (Exception exception) {
            System.out.println("ERROR");
            System.out.println(exception.getMessage());
            Object[] arrobject = new Object[]{exception.getMessage()};
            callback.invoke(arrobject);
            return;
        }
    }

    @ReactMethod
    public void isPackageInstalled(String string2, Callback callback, Callback callback2) {
        try {
            boolean bl = ShareIntent.isPackageInstalled(string2, (Context)this.reactContext);
            Object[] arrobject = new Object[]{bl};
            callback2.invoke(arrobject);
            return;
        }
        catch (Exception exception) {
            PrintStream printStream = System.out;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Error: ");
            stringBuilder.append(exception.getMessage());
            printStream.println(stringBuilder.toString());
            Object[] arrobject = new Object[]{exception.getMessage()};
            callback.invoke(arrobject);
            return;
        }
    }

    public void onActivityResult(int n, int n2, Intent intent) {
        if (n == 16845 && n2 == 0) {
            Object[] arrobject = new Object[]{false, "CANCELED"};
            TargetChosenReceiver.sendCallback(true, arrobject);
        }
    }

    public void onActivityResult(Activity activity, int n, int n2, Intent intent) {
        this.onActivityResult(n, n2, intent);
    }

    public void onNewIntent(Intent intent) {
    }

    @ReactMethod
    public void open(ReadableMap readableMap, Callback callback, Callback callback2) {
        TargetChosenReceiver.registerCallbacks(callback2, callback);
        try {
            new GenericShare(this.reactContext).open(readableMap);
            return;
        }
        catch (Exception exception) {
            System.out.println("ERROR");
            System.out.println(exception.getMessage());
            Object[] arrobject = new Object[]{exception.getMessage()};
            TargetChosenReceiver.sendCallback(false, arrobject);
            return;
        }
        catch (ActivityNotFoundException activityNotFoundException) {
            System.out.println("ERROR");
            System.out.println(activityNotFoundException.getMessage());
            TargetChosenReceiver.sendCallback(false, "not_available");
            return;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @ReactMethod
    public void shareSingle(ReadableMap readableMap, Callback callback, Callback callback2) {
        System.out.println("SHARE SINGLE METHOD");
        TargetChosenReceiver.registerCallbacks(callback2, callback);
        if (ShareIntent.hasValidKey("social", readableMap)) {
            ActivityNotFoundException activityNotFoundException2;
            block6 : {
                Exception exception2;
                ShareIntent shareIntent = SHARES.getShareClass(readableMap.getString("social"), this.reactContext);
                if (shareIntent == null) throw new ActivityNotFoundException("Invalid share activity");
                try {
                    if (!(shareIntent instanceof ShareIntent)) throw new ActivityNotFoundException("Invalid share activity");
                    shareIntent.open(readableMap);
                    return;
                }
                catch (Exception exception2) {
                }
                catch (ActivityNotFoundException activityNotFoundException2) {
                    break block6;
                }
                System.out.println("ERROR");
                System.out.println(exception2.getMessage());
                Object[] arrobject = new Object[]{exception2.getMessage()};
                TargetChosenReceiver.sendCallback(false, arrobject);
                return;
            }
            System.out.println("ERROR");
            System.out.println(activityNotFoundException2.getMessage());
            Object[] arrobject = new Object[]{activityNotFoundException2.getMessage()};
            TargetChosenReceiver.sendCallback(false, arrobject);
            return;
        }
        TargetChosenReceiver.sendCallback(false, "key 'social' missing in options");
    }

}

