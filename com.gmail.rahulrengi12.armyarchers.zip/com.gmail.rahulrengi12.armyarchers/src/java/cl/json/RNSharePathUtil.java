/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.ContentUris
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Environment
 *  android.provider.DocumentsContract
 *  android.provider.MediaStore
 *  android.provider.MediaStore$Audio
 *  android.provider.MediaStore$Audio$Media
 *  android.provider.MediaStore$Images
 *  android.provider.MediaStore$Images$Media
 *  android.provider.MediaStore$Video
 *  android.provider.MediaStore$Video$Media
 *  android.text.TextUtils
 *  androidx.loader.content.CursorLoader
 *  com.facebook.react.bridge.ReactContext
 *  java.io.File
 *  java.lang.CharSequence
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 */
package cl.json;

import android.app.Application;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.TextUtils;
import androidx.loader.content.CursorLoader;
import cl.json.ShareApplication;
import com.facebook.react.bridge.ReactContext;
import java.io.File;
import java.util.ArrayList;

public class RNSharePathUtil {
    private static final ArrayList<String> authorities = new ArrayList();

    /*
     * Exception decompiling
     */
    public static Uri compatUriFromFile(ReactContext var0, File var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl45.1 : IINC : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void compileAuthorities(ReactContext reactContext) {
        if (authorities.size() == 0) {
            Application application = (Application)reactContext.getApplicationContext();
            if (application instanceof ShareApplication) {
                authorities.add((Object)((ShareApplication)application).getFileProviderAuthority());
            }
            ArrayList<String> arrayList = authorities;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(reactContext.getPackageName());
            stringBuilder.append(".rnshare.fileprovider");
            arrayList.add((Object)stringBuilder.toString());
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive exception aggregation
     */
    public static String getDataColumn(Context context, Uri uri, String string2, String[] arrstring) {
        void var6_10;
        Cursor cursor;
        block8 : {
            block6 : {
                String string3;
                block7 : {
                    String[] arrstring2 = new String[]{"_data"};
                    CursorLoader cursorLoader = new CursorLoader(context, uri, arrstring2, string2, arrstring, null);
                    cursor = cursorLoader.loadInBackground();
                    if (cursor == null) break block6;
                    try {
                        if (!cursor.moveToFirst()) break block6;
                        string3 = cursor.getString(cursor.getColumnIndexOrThrow("_data"));
                        if (cursor == null) break block7;
                    }
                    catch (Throwable throwable) {
                        break block8;
                    }
                    cursor.close();
                }
                return string3;
            }
            if (cursor != null) {
                cursor.close();
            }
            return null;
            catch (Throwable throwable) {
                cursor = null;
            }
        }
        if (cursor != null) {
            cursor.close();
        }
        throw var6_10;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static String getRealPathFromURI(Context context, Uri uri) {
        if (Build.VERSION.SDK_INT >= 19 && DocumentsContract.isDocumentUri((Context)context, (Uri)uri)) {
            Uri uri2;
            if (RNSharePathUtil.isExternalStorageDocument(uri)) {
                String[] arrstring = DocumentsContract.getDocumentId((Uri)uri).split(":");
                String string2 = arrstring[0];
                if (!"primary".equalsIgnoreCase(string2) && !"0".equalsIgnoreCase(string2)) {
                    if ("raw".equalsIgnoreCase(string2)) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("");
                        stringBuilder.append(arrstring[1]);
                        return stringBuilder.toString();
                    }
                    if (TextUtils.isEmpty((CharSequence)string2)) return null;
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append("/storage/");
                    stringBuilder.append(string2);
                    stringBuilder.append("/");
                    stringBuilder.append(arrstring[1]);
                    return stringBuilder.toString();
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append((Object)Environment.getExternalStorageDirectory());
                stringBuilder.append("/");
                stringBuilder.append(arrstring[1]);
                return stringBuilder.toString();
            }
            if (RNSharePathUtil.isDownloadsDocument(uri)) {
                String string3 = DocumentsContract.getDocumentId((Uri)uri);
                if (string3.startsWith("raw:")) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(string3.replaceFirst("raw:", ""));
                    return stringBuilder.toString();
                }
                Uri uri3 = ContentUris.withAppendedId((Uri)Uri.parse((String)"content://downloads/public_downloads"), (long)Long.valueOf((String)string3));
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("");
                stringBuilder.append(RNSharePathUtil.getDataColumn(context, uri3, null, null));
                return stringBuilder.toString();
            }
            if (!RNSharePathUtil.isMediaDocument(uri)) return null;
            String[] arrstring = DocumentsContract.getDocumentId((Uri)uri).split(":");
            String string4 = arrstring[0];
            if ("image".equals((Object)string4)) {
                uri2 = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            } else if ("video".equals((Object)string4)) {
                uri2 = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            } else if ("audio".equals((Object)string4)) {
                uri2 = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            } else {
                boolean bl = "raw".equalsIgnoreCase(string4);
                uri2 = null;
                if (bl) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("");
                    stringBuilder.append(arrstring[1]);
                    return stringBuilder.toString();
                }
            }
            String[] arrstring2 = new String[]{arrstring[1]};
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(RNSharePathUtil.getDataColumn(context, uri2, "_id=?", arrstring2));
            return stringBuilder.toString();
        }
        if ("content".equalsIgnoreCase(uri.getScheme())) {
            if (RNSharePathUtil.isGooglePhotosUri(uri)) {
                return uri.getLastPathSegment();
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("");
            stringBuilder.append(RNSharePathUtil.getDataColumn(context, uri, null, null));
            return stringBuilder.toString();
        }
        if (!"file".equalsIgnoreCase(uri.getScheme())) return null;
        return uri.getPath();
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals((Object)uri.getAuthority());
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals((Object)uri.getAuthority());
    }

    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals((Object)uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals((Object)uri.getAuthority());
    }
}

