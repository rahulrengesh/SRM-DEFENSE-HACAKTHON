/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.content.BroadcastReceiver
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.IntentSender
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Parcelable
 *  com.facebook.react.bridge.Callback
 *  com.facebook.react.bridge.ReactContext
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package cl.json.social;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.os.Build;
import android.os.Parcelable;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactContext;

public class TargetChosenReceiver
extends BroadcastReceiver {
    private static final String EXTRA_RECEIVER_TOKEN = "receiver_token";
    private static final Object LOCK = new Object();
    private static Callback failureCallback;
    private static TargetChosenReceiver sLastRegisteredReceiver;
    private static String sTargetChosenReceiveAction;
    private static Callback successCallback;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static IntentSender getSharingSenderIntent(ReactContext reactContext) {
        Object object;
        Object object2 = object = LOCK;
        synchronized (object2) {
            if (sTargetChosenReceiveAction == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(reactContext.getPackageName());
                stringBuilder.append("/");
                stringBuilder.append(TargetChosenReceiver.class.getName());
                stringBuilder.append("_ACTION");
                sTargetChosenReceiveAction = stringBuilder.toString();
            }
            Context context = reactContext.getApplicationContext();
            if (sLastRegisteredReceiver != null) {
                context.unregisterReceiver((BroadcastReceiver)sLastRegisteredReceiver);
            }
            sLastRegisteredReceiver = new TargetChosenReceiver();
            context.registerReceiver((BroadcastReceiver)sLastRegisteredReceiver, new IntentFilter(sTargetChosenReceiveAction));
        }
        Intent intent = new Intent(sTargetChosenReceiveAction);
        intent.setPackage(reactContext.getPackageName());
        intent.putExtra(EXTRA_RECEIVER_TOKEN, sLastRegisteredReceiver.hashCode());
        return PendingIntent.getBroadcast((Context)reactContext, (int)0, (Intent)intent, (int)1342177280).getIntentSender();
    }

    public static boolean isSupported() {
        return Build.VERSION.SDK_INT >= 22;
    }

    public static void registerCallbacks(Callback callback, Callback callback2) {
        successCallback = callback;
        failureCallback = callback2;
    }

    public static /* varargs */ void sendCallback(boolean bl, Object ... arrobject) {
        if (bl) {
            Callback callback = successCallback;
            if (callback != null) {
                callback.invoke(arrobject);
            }
        } else {
            Callback callback = failureCallback;
            if (callback != null) {
                callback.invoke(arrobject);
            }
        }
        successCallback = null;
        failureCallback = null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public void onReceive(Context context, Intent intent) {
        Object object;
        Object object2 = object = LOCK;
        // MONITORENTER : object2
        if (sLastRegisteredReceiver != this) {
            // MONITOREXIT : object2
            return;
        }
        context.getApplicationContext().unregisterReceiver((BroadcastReceiver)sLastRegisteredReceiver);
        sLastRegisteredReceiver = null;
        // MONITOREXIT : object2
        if (!intent.hasExtra(EXTRA_RECEIVER_TOKEN)) return;
        if (intent.getIntExtra(EXTRA_RECEIVER_TOKEN, 0) != this.hashCode()) {
            return;
        }
        ComponentName componentName = (ComponentName)intent.getParcelableExtra("android.intent.extra.CHOSEN_COMPONENT");
        if (componentName != null) {
            Object[] arrobject = new Object[]{true, componentName.flattenToString()};
            TargetChosenReceiver.sendCallback(true, arrobject);
            return;
        }
        Object[] arrobject = new Object[]{true, "OK"};
        TargetChosenReceiver.sendCallback(true, arrobject);
    }
}

