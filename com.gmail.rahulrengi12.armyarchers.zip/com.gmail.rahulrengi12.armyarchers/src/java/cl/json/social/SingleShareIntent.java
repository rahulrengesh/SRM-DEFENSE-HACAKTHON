/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentSender
 *  android.net.Uri
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReadableMap
 *  java.io.PrintStream
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 */
package cl.json.social;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import cl.json.social.ShareIntent;
import cl.json.social.TargetChosenReceiver;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableMap;
import java.io.PrintStream;

public abstract class SingleShareIntent
extends ShareIntent {
    protected String appStoreURL = null;
    protected String playStoreURL = null;

    public SingleShareIntent(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
    }

    @Override
    public void open(ReadableMap readableMap) throws ActivityNotFoundException {
        System.out.println(this.getPackage());
        if (this.getPackage() != null || this.getDefaultWebLink() != null || this.getPlayStoreLink() != null) {
            if (SingleShareIntent.isPackageInstalled(this.getPackage(), (Context)this.reactContext)) {
                System.out.println("INSTALLED");
                this.getIntent().setPackage(this.getPackage());
                super.open(readableMap);
            } else {
                System.out.println("NOT INSTALLED");
                String string2 = this.getDefaultWebLink() != null ? this.getDefaultWebLink().replace((CharSequence)"{url}", (CharSequence)SingleShareIntent.urlEncode(readableMap.getString("url"))).replace((CharSequence)"{message}", (CharSequence)SingleShareIntent.urlEncode(readableMap.getString("message"))) : (this.getPlayStoreLink() != null ? this.getPlayStoreLink() : "");
                this.setIntent(new Intent(new Intent("android.intent.action.VIEW", Uri.parse((String)string2))));
            }
        }
        super.open(readableMap);
    }

    @Override
    protected void openIntentChooser() throws ActivityNotFoundException {
        boolean bl = this.options.hasKey("forceDialog");
        Boolean bl2 = true;
        if (bl && this.options.getBoolean("forceDialog")) {
            Activity activity = this.reactContext.getCurrentActivity();
            if (activity == null) {
                TargetChosenReceiver.sendCallback(false, "Something went wrong");
                return;
            }
            if (TargetChosenReceiver.isSupported()) {
                IntentSender intentSender = TargetChosenReceiver.getSharingSenderIntent((ReactContext)this.reactContext);
                Intent intent = Intent.createChooser((Intent)this.getIntent(), (CharSequence)this.chooserTitle, (IntentSender)intentSender);
                intent.setFlags(1073741824);
                activity.startActivityForResult(intent, 16845);
                return;
            }
            Intent intent = Intent.createChooser((Intent)this.getIntent(), (CharSequence)this.chooserTitle);
            intent.setFlags(1073741824);
            activity.startActivityForResult(intent, 16845);
            TargetChosenReceiver.sendCallback(true, new Object[]{bl2, "OK"});
            return;
        }
        this.getIntent().setFlags(268435456);
        this.reactContext.startActivity(this.getIntent());
        Object[] arrobject = new Object[]{bl2, this.getIntent().getPackage()};
        TargetChosenReceiver.sendCallback(true, arrobject);
    }
}

