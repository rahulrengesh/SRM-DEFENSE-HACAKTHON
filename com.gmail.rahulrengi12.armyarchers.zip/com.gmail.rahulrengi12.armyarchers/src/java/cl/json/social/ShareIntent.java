/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ActivityNotFoundException
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentSender
 *  android.content.pm.ActivityInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ResolveInfo
 *  android.net.Uri
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReadableArray
 *  com.facebook.react.bridge.ReadableMap
 *  java.io.UnsupportedEncodingException
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.net.URLEncoder
 *  java.util.ArrayList
 *  java.util.List
 */
package cl.json.social;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Parcelable;
import android.text.TextUtils;
import cl.json.ShareFile;
import cl.json.ShareFiles;
import cl.json.social.TargetChosenReceiver;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.ReadableMap;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public abstract class ShareIntent {
    protected String chooserTitle = "Share";
    protected ShareFile fileShare;
    protected Intent intent;
    protected ReadableMap options;
    protected final ReactApplicationContext reactContext;

    public ShareIntent(ReactApplicationContext reactApplicationContext) {
        this.reactContext = reactApplicationContext;
        this.setIntent(new Intent("android.intent.action.SEND"));
        this.getIntent().setType("text/plain");
    }

    public static boolean hasValidKey(String string2, ReadableMap readableMap) {
        return readableMap != null && readableMap.hasKey(string2) && !readableMap.isNull(string2);
    }

    public static boolean isPackageInstalled(String string2, Context context) {
        PackageManager packageManager = context.getPackageManager();
        try {
            packageManager.getPackageInfo(string2, 1);
            return true;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            return false;
        }
    }

    protected static String urlEncode(String string2) {
        try {
            String string3 = URLEncoder.encode((String)string2, (String)"UTF-8");
            return string3;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("URLEncoder.encode() failed for ");
            stringBuilder.append(string2);
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    protected abstract String getDefaultWebLink();

    protected ShareFile getFileShare(ReadableMap readableMap) {
        if (ShareIntent.hasValidKey("type", readableMap)) {
            return new ShareFile(readableMap.getString("url"), readableMap.getString("type"), this.reactContext);
        }
        return new ShareFile(readableMap.getString("url"), this.reactContext);
    }

    protected ShareFiles getFileShares(ReadableMap readableMap) {
        if (ShareIntent.hasValidKey("type", readableMap)) {
            return new ShareFiles(readableMap.getArray("urls"), readableMap.getString("type"), this.reactContext);
        }
        return new ShareFiles(readableMap.getArray("urls"), this.reactContext);
    }

    protected Intent getIntent() {
        return this.intent;
    }

    protected Intent[] getIntentsToViewFile(Intent intent, Uri uri) {
        PackageManager packageManager = this.reactContext.getPackageManager();
        List list = packageManager.queryIntentActivities(intent, 0);
        Intent[] arrintent = new Intent[list.size()];
        for (int i = 0; i < list.size(); ++i) {
            ResolveInfo resolveInfo = (ResolveInfo)list.get(i);
            String string2 = resolveInfo.activityInfo.packageName;
            Intent intent2 = new Intent();
            intent2.setComponent(new ComponentName(string2, resolveInfo.activityInfo.name));
            intent2.setAction("android.intent.action.VIEW");
            intent2.setDataAndType(uri, intent.getType());
            intent2.addFlags(1);
            arrintent[i] = new Intent(intent2);
        }
        return arrintent;
    }

    protected abstract String getPackage();

    protected abstract String getPlayStoreLink();

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public void open(ReadableMap readableMap) throws ActivityNotFoundException {
        this.options = readableMap;
        if (ShareIntent.hasValidKey("subject", readableMap)) {
            this.getIntent().putExtra("android.intent.extra.SUBJECT", readableMap.getString("subject"));
        }
        if (ShareIntent.hasValidKey("title", readableMap)) {
            this.chooserTitle = readableMap.getString("title");
        }
        String string2 = ShareIntent.hasValidKey("message", readableMap) ? readableMap.getString("message") : "";
        if (ShareIntent.hasValidKey("urls", readableMap)) {
            ShareFiles shareFiles = this.getFileShares(readableMap);
            if (shareFiles.isFile()) {
                ArrayList<Uri> arrayList = shareFiles.getURI();
                this.getIntent().setAction("android.intent.action.SEND_MULTIPLE");
                this.getIntent().setType(shareFiles.getType());
                this.getIntent().putParcelableArrayListExtra("android.intent.extra.STREAM", arrayList);
                this.getIntent().addFlags(1);
                if (TextUtils.isEmpty((CharSequence)string2)) return;
                this.getIntent().putExtra("android.intent.extra.TEXT", string2);
                return;
            }
            if (!TextUtils.isEmpty((CharSequence)string2)) {
                Intent intent = this.getIntent();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string2);
                stringBuilder.append(" ");
                stringBuilder.append(readableMap.getArray("urls").toString());
                intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                return;
            }
            this.getIntent().putExtra("android.intent.extra.TEXT", readableMap.getArray("urls").toString());
            return;
        }
        if (ShareIntent.hasValidKey("url", readableMap)) {
            this.fileShare = this.getFileShare(readableMap);
            if (this.fileShare.isFile()) {
                Uri uri = this.fileShare.getURI();
                this.getIntent().setType(this.fileShare.getType());
                this.getIntent().putExtra("android.intent.extra.STREAM", (Parcelable)uri);
                this.getIntent().addFlags(1);
                if (TextUtils.isEmpty((CharSequence)string2)) return;
                this.getIntent().putExtra("android.intent.extra.TEXT", string2);
                return;
            }
            if (!TextUtils.isEmpty((CharSequence)string2)) {
                Intent intent = this.getIntent();
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string2);
                stringBuilder.append(" ");
                stringBuilder.append(readableMap.getString("url"));
                intent.putExtra("android.intent.extra.TEXT", stringBuilder.toString());
                return;
            }
            this.getIntent().putExtra("android.intent.extra.TEXT", readableMap.getString("url"));
            return;
        }
        if (TextUtils.isEmpty((CharSequence)string2)) return;
        this.getIntent().putExtra("android.intent.extra.TEXT", string2);
    }

    protected void openIntentChooser() throws ActivityNotFoundException {
        Intent intent;
        Activity activity = this.reactContext.getCurrentActivity();
        if (activity == null) {
            TargetChosenReceiver.sendCallback(false, "Something went wrong");
            return;
        }
        IntentSender intentSender = null;
        if (TargetChosenReceiver.isSupported()) {
            intentSender = TargetChosenReceiver.getSharingSenderIntent((ReactContext)this.reactContext);
            intent = Intent.createChooser((Intent)this.getIntent(), (CharSequence)this.chooserTitle, (IntentSender)intentSender);
        } else {
            intent = Intent.createChooser((Intent)this.getIntent(), (CharSequence)this.chooserTitle);
        }
        intent.setFlags(1073741824);
        if (ShareIntent.hasValidKey("showAppsToView", this.options) && ShareIntent.hasValidKey("url", this.options)) {
            Intent intent2 = new Intent("android.intent.action.VIEW");
            intent2.setType(this.fileShare.getType());
            intent.putExtra("android.intent.extra.INITIAL_INTENTS", (Parcelable[])this.getIntentsToViewFile(intent2, this.fileShare.getURI()));
        }
        activity.startActivityForResult(intent, 16845);
        if (intentSender == null) {
            Object[] arrobject = new Object[]{true, "OK"};
            TargetChosenReceiver.sendCallback(true, arrobject);
        }
    }

    protected void setIntent(Intent intent) {
        this.intent = intent;
    }
}

