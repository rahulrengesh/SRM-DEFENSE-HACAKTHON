/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ActivityNotFoundException
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.provider.Telephony
 *  android.provider.Telephony$Sms
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReadableMap
 *  java.lang.String
 */
package cl.json.social;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.os.Build;
import android.provider.Telephony;
import cl.json.social.SingleShareIntent;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReadableMap;

public class SMSShare
extends SingleShareIntent {
    private static final String PACKAGE = "com.android.mms";
    private static final String PLAY_STORE_LINK = "market://details?id=com.android.mms";
    private ReactApplicationContext reactContext = null;

    public SMSShare(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
        this.reactContext = reactApplicationContext;
    }

    @Override
    protected String getDefaultWebLink() {
        return null;
    }

    @Override
    protected String getPackage() {
        if (Build.VERSION.SDK_INT >= 19) {
            return Telephony.Sms.getDefaultSmsPackage((Context)this.reactContext);
        }
        return PACKAGE;
    }

    @Override
    protected String getPlayStoreLink() {
        return PLAY_STORE_LINK;
    }

    @Override
    public void open(ReadableMap readableMap) throws ActivityNotFoundException {
        super.open(readableMap);
        this.openIntentChooser();
    }
}

