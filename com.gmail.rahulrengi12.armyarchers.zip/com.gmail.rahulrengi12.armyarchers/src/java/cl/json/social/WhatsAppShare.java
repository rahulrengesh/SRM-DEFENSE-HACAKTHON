/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ActivityNotFoundException
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReadableMap
 *  java.lang.String
 */
package cl.json.social;

import android.content.ActivityNotFoundException;
import cl.json.social.SingleShareIntent;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReadableMap;

public class WhatsAppShare
extends SingleShareIntent {
    private static final String PACKAGE = "com.whatsapp";
    private static final String PLAY_STORE_LINK = "market://details?id=com.whatsapp";

    public WhatsAppShare(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
    }

    @Override
    protected String getDefaultWebLink() {
        return null;
    }

    @Override
    protected String getPackage() {
        return PACKAGE;
    }

    @Override
    protected String getPlayStoreLink() {
        return PLAY_STORE_LINK;
    }

    @Override
    public void open(ReadableMap readableMap) throws ActivityNotFoundException {
        super.open(readableMap);
        this.openIntentChooser();
    }
}

