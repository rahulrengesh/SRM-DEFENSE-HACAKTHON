/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Environment
 *  android.util.Base64
 *  android.webkit.MimeTypeMap
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContext
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 */
package cl.json;

import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.util.Base64;
import android.webkit.MimeTypeMap;
import cl.json.RNSharePathUtil;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class ShareFile {
    private final ReactApplicationContext reactContext;
    private String type;
    private Uri uri;
    private String url;

    public ShareFile(String string2, ReactApplicationContext reactApplicationContext) {
        this.url = string2;
        this.uri = Uri.parse((String)this.url);
        this.reactContext = reactApplicationContext;
    }

    public ShareFile(String string2, String string3, ReactApplicationContext reactApplicationContext) {
        this(string2, reactApplicationContext);
        this.type = string3;
    }

    private String getMimeType(String string2) {
        String string3 = MimeTypeMap.getFileExtensionFromUrl((String)string2);
        if (string3 != null) {
            return MimeTypeMap.getSingleton().getMimeTypeFromExtension(string3);
        }
        return null;
    }

    private String getRealPathFromURI(Uri uri) {
        return RNSharePathUtil.getRealPathFromURI((Context)this.reactContext, uri);
    }

    private boolean isBase64File() {
        if (this.uri.getScheme() != null && this.uri.getScheme().equals((Object)"data")) {
            this.type = this.uri.getSchemeSpecificPart().substring(0, this.uri.getSchemeSpecificPart().indexOf(";"));
            return true;
        }
        return false;
    }

    private boolean isLocalFile() {
        if (this.uri.getScheme() != null && (this.uri.getScheme().equals((Object)"content") || this.uri.getScheme().equals((Object)"file"))) {
            if (this.type != null) {
                return true;
            }
            this.type = this.getMimeType(this.uri.toString());
            if (this.type == null) {
                String string2 = this.getRealPathFromURI(this.uri);
                if (string2 != null) {
                    this.type = this.getMimeType(string2);
                } else {
                    return false;
                }
            }
            if (this.type == null) {
                this.type = "*/*";
            }
            return true;
        }
        return false;
    }

    public String getType() {
        String string2 = this.type;
        if (string2 == null) {
            string2 = "*/*";
        }
        return string2;
    }

    public Uri getURI() {
        String string2 = MimeTypeMap.getSingleton().getExtensionFromMimeType(this.getType());
        if (this.isBase64File()) {
            String string3 = this.uri.getSchemeSpecificPart().substring(8 + this.uri.getSchemeSpecificPart().indexOf(";base64,"));
            try {
                File file = new File(Environment.getExternalStorageDirectory(), Environment.DIRECTORY_DOWNLOADS);
                if (!file.exists() && !file.mkdirs()) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("mkdirs failed on ");
                    stringBuilder.append(file.getAbsolutePath());
                    throw new IOException(stringBuilder.toString());
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(System.nanoTime());
                stringBuilder.append(".");
                stringBuilder.append(string2);
                File file2 = new File(file, stringBuilder.toString());
                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                fileOutputStream.write(Base64.decode((String)string3, (int)0));
                fileOutputStream.flush();
                fileOutputStream.close();
                Uri uri = RNSharePathUtil.compatUriFromFile((ReactContext)this.reactContext, file2);
                return uri;
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
                return null;
            }
        }
        if (this.isLocalFile()) {
            Uri uri = Uri.parse((String)this.url);
            if (uri.getPath() == null) {
                return null;
            }
            return RNSharePathUtil.compatUriFromFile((ReactContext)this.reactContext, new File(uri.getPath()));
        }
        return null;
    }

    public boolean isFile() {
        return this.isBase64File() || this.isLocalFile();
        {
        }
    }
}

