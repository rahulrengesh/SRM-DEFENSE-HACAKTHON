/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.core.content.FileProvider
 */
package cl.json;

import androidx.core.content.FileProvider;

public class RNShareFileProvider
extends FileProvider {
}

