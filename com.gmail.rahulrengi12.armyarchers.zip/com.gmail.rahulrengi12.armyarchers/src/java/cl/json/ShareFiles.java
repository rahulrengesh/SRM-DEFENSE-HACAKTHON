/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Environment
 *  android.util.Base64
 *  android.webkit.MimeTypeMap
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReadableArray
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package cl.json;

import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.util.Base64;
import android.webkit.MimeTypeMap;
import cl.json.RNSharePathUtil;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableArray;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class ShareFiles {
    private String intentType;
    private final ReactApplicationContext reactContext;
    private ArrayList<Uri> uris = new ArrayList();

    public ShareFiles(ReadableArray readableArray, ReactApplicationContext reactApplicationContext) {
        for (int i = 0; i < readableArray.size(); ++i) {
            String string2 = readableArray.getString(i);
            if (string2 == null) continue;
            Uri uri = Uri.parse((String)string2);
            this.uris.add((Object)uri);
        }
        this.reactContext = reactApplicationContext;
    }

    public ShareFiles(ReadableArray readableArray, String string2, ReactApplicationContext reactApplicationContext) {
        this(readableArray, reactApplicationContext);
        this.intentType = string2;
    }

    private String getMimeType(String string2) {
        String string3 = MimeTypeMap.getFileExtensionFromUrl((String)string2);
        if (string3 != null) {
            return MimeTypeMap.getSingleton().getMimeTypeFromExtension(string3);
        }
        return null;
    }

    private String getRealPathFromURI(Uri uri) {
        return RNSharePathUtil.getRealPathFromURI((Context)this.reactContext, uri);
    }

    private boolean isBase64File(Uri uri) {
        if (uri.getScheme() != null && uri.getScheme().equals((Object)"data")) {
            String string2 = uri.getSchemeSpecificPart().substring(0, uri.getSchemeSpecificPart().indexOf(";"));
            String string3 = this.intentType;
            if (string3 == null) {
                this.intentType = string2;
            } else if (!string3.equalsIgnoreCase(string2) && this.intentType.split("/")[0].equalsIgnoreCase(string2.split("/")[0])) {
                this.intentType = this.intentType.split("/")[0].concat("/*");
            } else if (!this.intentType.equalsIgnoreCase(string2)) {
                this.intentType = "*/*";
            }
            return true;
        }
        return false;
    }

    private boolean isLocalFile(Uri uri) {
        if (uri.getScheme() != null && uri.getScheme().equals((Object)"content") || "file".equals((Object)uri.getScheme())) {
            String string2;
            String string3 = this.getMimeType(uri.toString());
            if (string3 == null) {
                string3 = this.getMimeType(this.getRealPathFromURI(uri));
            }
            if (string3 == null) {
                string3 = "*/*";
            }
            if ((string2 = this.intentType) == null) {
                this.intentType = string3;
            } else if (!string2.equalsIgnoreCase(string3) && this.intentType.split("/")[0].equalsIgnoreCase(string3.split("/")[0])) {
                this.intentType = this.intentType.split("/")[0].concat("/*");
            } else if (!this.intentType.equalsIgnoreCase(string3)) {
                this.intentType = "*/*";
            }
            return true;
        }
        return false;
    }

    public String getType() {
        String string2 = this.intentType;
        if (string2 == null) {
            string2 = "*/*";
        }
        return string2;
    }

    public ArrayList<Uri> getURI() {
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        ArrayList arrayList = new ArrayList();
        for (Uri uri : this.uris) {
            if (this.isBase64File(uri)) {
                String string2 = mimeTypeMap.getExtensionFromMimeType(uri.getSchemeSpecificPart().substring(0, uri.getSchemeSpecificPart().indexOf(";")));
                String string3 = uri.getSchemeSpecificPart().substring(8 + uri.getSchemeSpecificPart().indexOf(";base64,"));
                try {
                    File file = new File(Environment.getExternalStorageDirectory(), Environment.DIRECTORY_DOWNLOADS);
                    if (!file.exists() && !file.mkdirs()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("mkdirs failed on ");
                        stringBuilder.append(file.getAbsolutePath());
                        throw new IOException(stringBuilder.toString());
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(System.currentTimeMillis());
                    stringBuilder.append(".");
                    stringBuilder.append(string2);
                    File file2 = new File(file, stringBuilder.toString());
                    FileOutputStream fileOutputStream = new FileOutputStream(file2);
                    fileOutputStream.write(Base64.decode((String)string3, (int)0));
                    fileOutputStream.flush();
                    fileOutputStream.close();
                    arrayList.add((Object)RNSharePathUtil.compatUriFromFile((ReactContext)this.reactContext, file2));
                }
                catch (IOException iOException) {
                    iOException.printStackTrace();
                }
                continue;
            }
            if (!this.isLocalFile(uri) || uri.getPath() == null) continue;
            arrayList.add((Object)RNSharePathUtil.compatUriFromFile((ReactContext)this.reactContext, new File(uri.getPath())));
        }
        return arrayList;
    }

    public boolean isFile() {
        Iterator iterator = this.uris.iterator();
        boolean bl = true;
        while (iterator.hasNext()) {
            Uri uri = (Uri)iterator.next();
            bl = this.isBase64File(uri) || this.isLocalFile(uri);
            if (bl) continue;
        }
        return bl;
    }
}

