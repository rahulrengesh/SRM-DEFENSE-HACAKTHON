/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  dalvik.annotation.SourceDebugExtension
 *  expo.modules.permissions.PermissionsModule$askAsync
 *  expo.modules.permissions.PermissionsModule$createPermissionsResponseListener
 *  expo.modules.permissions.PermissionsModule$getAsync
 *  expo.modules.permissions.PermissionsTypes
 *  expo.modules.permissions.requesters.PermissionRequester
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  kotlin.Metadata
 *  kotlin.Pair
 *  kotlin.TuplesKt
 *  kotlin.TypeCastException
 *  kotlin.Unit
 *  kotlin.collections.CollectionsKt
 *  kotlin.collections.MapsKt
 *  kotlin.jvm.functions.Function2
 *  kotlin.jvm.internal.Intrinsics
 *  org.unimodules.core.ModuleRegistry
 *  org.unimodules.core.Promise
 *  org.unimodules.core.interfaces.ExpoMethod
 *  org.unimodules.interfaces.permissions.Permissions
 *  org.unimodules.interfaces.permissions.PermissionsResponse
 *  org.unimodules.interfaces.permissions.PermissionsResponseListener
 */
package expo.modules.permissions;

import android.content.Context;
import android.os.Bundle;
import dalvik.annotation.SourceDebugExtension;
import expo.modules.permissions.PermissionsModule;
import expo.modules.permissions.PermissionsTypes;
import expo.modules.permissions.requesters.LocationRequester;
import expo.modules.permissions.requesters.NotificationRequester;
import expo.modules.permissions.requesters.PermissionRequester;
import expo.modules.permissions.requesters.RemindersRequester;
import expo.modules.permissions.requesters.SimpleRequester;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.TypeCastException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.unimodules.core.ExportedModule;
import org.unimodules.core.ModuleRegistry;
import org.unimodules.core.Promise;
import org.unimodules.core.interfaces.ExpoMethod;
import org.unimodules.interfaces.permissions.Permissions;
import org.unimodules.interfaces.permissions.PermissionsResponse;
import org.unimodules.interfaces.permissions.PermissionsResponseListener;

@SourceDebugExtension(value="SMAP\nPermissionsModule.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PermissionsModule.kt\nexpo/modules/permissions/PermissionsModule\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,112:1\n1587#2,2:113\n1313#2:115\n1382#2,3:116\n1809#2,7:119\n37#3,2:126\n*E\n*S KotlinDebug\n*F\n+ 1 PermissionsModule.kt\nexpo/modules/permissions/PermissionsModule\n*L\n97#1,2:113\n107#1:115\n107#1,3:116\n108#1,7:119\n109#1,2:126\n*E\n")
@Metadata(bv={1, 0, 3}, d1={"\u0000h\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0000\n\u0002\u0010 \n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J(\u0010\u000b\u001a\u00020\f2\u0016\u0010\r\u001a\u0012\u0012\u0004\u0012\u00020\t0\u000ej\b\u0012\u0004\u0012\u00020\t`\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0007J(\u0010\u0012\u001a\u00020\u00132\u0016\u0010\r\u001a\u0012\u0012\u0004\u0012\u00020\t0\u000ej\b\u0012\u0004\u0012\u00020\t`\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0002JJ\u0010\u0014\u001a\u00020\f2\u0016\u0010\u0015\u001a\u0012\u0012\u0004\u0012\u00020\t0\u000ej\b\u0012\u0004\u0012\u00020\t`\u000f2 \u0010\u0016\u001a\u001c\u0012\u0004\u0012\u00020\u0013\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\t0\u0018\u0012\u0004\u0012\u00020\f0\u00172\u0006\u0010\u0010\u001a\u00020\u0011H\u0002J!\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\t0\u00182\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\t0\u001aH\u0002\u00a2\u0006\u0002\u0010\u001bJ(\u0010\u001c\u001a\u00020\f2\u0016\u0010\r\u001a\u0012\u0012\u0004\u0012\u00020\t0\u000ej\b\u0012\u0004\u0012\u00020\t`\u000f2\u0006\u0010\u0010\u001a\u00020\u0011H\u0007J\b\u0010\u001d\u001a\u00020\tH\u0016J\u0010\u0010\u001e\u001a\u00020\n2\u0006\u0010\u001f\u001a\u00020\tH\u0002J\u0010\u0010 \u001a\u00020\f2\u0006\u0010!\u001a\u00020\"H\u0016J*\u0010#\u001a\u00020$2\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\t0\u001a2\u0012\u0010%\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020&0\bH\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082.\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\n0\bX\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006'"}, d2={"Lexpo/modules/permissions/PermissionsModule;", "Lorg/unimodules/core/ExportedModule;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "mPermissions", "Lorg/unimodules/interfaces/permissions/Permissions;", "mRequesters", "", "", "Lexpo/modules/permissions/requesters/PermissionRequester;", "askAsync", "", "requestedPermissionsTypes", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "promise", "Lorg/unimodules/core/Promise;", "createPermissionsResponseListener", "Lorg/unimodules/interfaces/permissions/PermissionsResponseListener;", "delegateToPermissionsServiceIfNeeded", "permissionTypes", "permissionsServiceDelegate", "Lkotlin/Function2;", "", "getAndroidPermissionsFromList", "", "(Ljava/util/List;)[Ljava/lang/String;", "getAsync", "getName", "getRequester", "permissionType", "onCreate", "moduleRegistry", "Lorg/unimodules/core/ModuleRegistry;", "parsePermissionsResponse", "Landroid/os/Bundle;", "permissionMap", "Lorg/unimodules/interfaces/permissions/PermissionsResponse;", "expo-permissions_release"}, k=1, mv={1, 1, 15})
public final class PermissionsModule
extends ExportedModule {
    private Permissions mPermissions;
    private Map<String, ? extends PermissionRequester> mRequesters;

    public PermissionsModule(Context context) {
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
        super(context);
    }

    public static final /* synthetic */ Bundle access$parsePermissionsResponse(PermissionsModule permissionsModule, List list, Map map) {
        return permissionsModule.parsePermissionsResponse((List<String>)list, (Map<String, PermissionsResponse>)map);
    }

    private final PermissionsResponseListener createPermissionsResponseListener(ArrayList<String> arrayList, Promise promise) {
        return new PermissionsResponseListener(this, promise, arrayList){
            final /* synthetic */ Promise $promise;
            final /* synthetic */ ArrayList $requestedPermissionsTypes;
            final /* synthetic */ PermissionsModule this$0;
            {
                this.this$0 = permissionsModule;
                this.$promise = promise;
                this.$requestedPermissionsTypes = arrayList;
            }

            public final void onResult(Map<String, PermissionsResponse> map) {
                Promise promise = this.$promise;
                PermissionsModule permissionsModule = this.this$0;
                List list = (List)this.$requestedPermissionsTypes;
                Intrinsics.checkExpressionValueIsNotNull(map, (String)"permissionsNativeStatus");
                promise.resolve((Object)PermissionsModule.access$parsePermissionsResponse(permissionsModule, list, map));
            }
        };
    }

    private final void delegateToPermissionsServiceIfNeeded(ArrayList<String> arrayList, Function2<? super PermissionsResponseListener, ? super String[], Unit> function2, Promise promise) {
        List list = (List)arrayList;
        String[] arrstring = this.getAndroidPermissionsFromList((List<String>)list);
        boolean bl = arrstring.length == 0;
        if (bl) {
            promise.resolve((Object)this.parsePermissionsResponse((List<String>)list, (Map<String, PermissionsResponse>)MapsKt.emptyMap()));
            return;
        }
        function2.invoke((Object)this.createPermissionsResponseListener(arrayList, promise), (Object)arrstring);
    }

    private final String[] getAndroidPermissionsFromList(List<String> list) throws IllegalStateException {
        Iterable iterable = (Iterable)list;
        Collection collection = (Collection)new ArrayList(CollectionsKt.collectionSizeOrDefault((Iterable)iterable, (int)10));
        Iterator iterator = iterable.iterator();
        while (iterator.hasNext()) {
            collection.add((Object)this.getRequester((String)iterator.next()).getAndroidPermissions());
        }
        Iterator iterator2 = ((Iterable)((List)collection)).iterator();
        if (iterator2.hasNext()) {
            Object object = iterator2.next();
            while (iterator2.hasNext()) {
                List list2 = (List)iterator2.next();
                object = CollectionsKt.plus((Collection)((Collection)((List)object)), (Iterable)((Iterable)list2));
            }
            Object[] arrobject = ((Collection)object).toArray((Object[])new String[0]);
            if (arrobject != null) {
                return (String[])arrobject;
            }
            throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<T>");
        }
        throw (Throwable)new UnsupportedOperationException("Empty collection can't be reduced.");
    }

    private final PermissionRequester getRequester(String string) throws IllegalStateException {
        PermissionRequester permissionRequester;
        Map<String, ? extends PermissionRequester> map = this.mRequesters;
        if (map == null) {
            Intrinsics.throwUninitializedPropertyAccessException((String)"mRequesters");
        }
        if ((permissionRequester = (PermissionRequester)map.get((Object)string)) != null) {
            return permissionRequester;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unrecognized permission type: ");
        stringBuilder.append(string);
        throw (Throwable)new IllegalStateException(stringBuilder.toString());
    }

    private final Bundle parsePermissionsResponse(List<String> list, Map<String, PermissionsResponse> map) throws IllegalStateException {
        Bundle bundle = new Bundle();
        for (String string : (Iterable)list) {
            bundle.putBundle(string, this.getRequester(string).parseAndroidPermissions(map));
        }
        return bundle;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @ExpoMethod
    public final void askAsync(ArrayList<String> arrayList, Promise promise) {
        Intrinsics.checkParameterIsNotNull(arrayList, (String)"requestedPermissionsTypes");
        Intrinsics.checkParameterIsNotNull((Object)promise, (String)"promise");
        try {
            Permissions permissions = this.mPermissions;
            if (permissions == null) {
                Intrinsics.throwUninitializedPropertyAccessException((String)"mPermissions");
            }
            this.delegateToPermissionsServiceIfNeeded(arrayList, (Function2<? super PermissionsResponseListener, ? super String[], Unit>)((Function2)new Function2<PermissionsResponseListener, String[], Unit>(permissions){

                public final String getName() {
                    return "askForPermissions";
                }

                public final kotlin.reflect.KDeclarationContainer getOwner() {
                    return kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(Permissions.class);
                }

                public final String getSignature() {
                    return "askForPermissions(Lorg/unimodules/interfaces/permissions/PermissionsResponseListener;[Ljava/lang/String;)V";
                }

                public final void invoke(PermissionsResponseListener permissionsResponseListener, String[] arrstring) {
                    ((Permissions)this.receiver).askForPermissions(permissionsResponseListener, arrstring);
                }
            }), promise);
            return;
        }
        catch (IllegalStateException illegalStateException) {
            promise.reject("E_PERMISSIONS_UNKNOWN", "Failed to get permissions", (Throwable)illegalStateException);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @ExpoMethod
    public final void getAsync(ArrayList<String> arrayList, Promise promise) {
        Intrinsics.checkParameterIsNotNull(arrayList, (String)"requestedPermissionsTypes");
        Intrinsics.checkParameterIsNotNull((Object)promise, (String)"promise");
        try {
            Permissions permissions = this.mPermissions;
            if (permissions == null) {
                Intrinsics.throwUninitializedPropertyAccessException((String)"mPermissions");
            }
            this.delegateToPermissionsServiceIfNeeded(arrayList, (Function2<? super PermissionsResponseListener, ? super String[], Unit>)((Function2)new Function2<PermissionsResponseListener, String[], Unit>(permissions){

                public final String getName() {
                    return "getPermissions";
                }

                public final kotlin.reflect.KDeclarationContainer getOwner() {
                    return kotlin.jvm.internal.Reflection.getOrCreateKotlinClass(Permissions.class);
                }

                public final String getSignature() {
                    return "getPermissions(Lorg/unimodules/interfaces/permissions/PermissionsResponseListener;[Ljava/lang/String;)V";
                }

                public final void invoke(PermissionsResponseListener permissionsResponseListener, String[] arrstring) {
                    ((Permissions)this.receiver).getPermissions(permissionsResponseListener, arrstring);
                }
            }), promise);
            return;
        }
        catch (IllegalStateException illegalStateException) {
            promise.reject("E_PERMISSIONS_UNKNOWN", "Failed to get permissions", (Throwable)illegalStateException);
            return;
        }
    }

    @Override
    public String getName() {
        return "ExpoPermissions";
    }

    @Override
    public void onCreate(ModuleRegistry moduleRegistry2) throws IllegalStateException {
        Intrinsics.checkParameterIsNotNull((Object)moduleRegistry2, (String)"moduleRegistry");
        Permissions permissions = (Permissions)moduleRegistry2.getModule(Permissions.class);
        if (permissions != null) {
            this.mPermissions = permissions;
            Context context = this.getContext();
            Intrinsics.checkExpressionValueIsNotNull((Object)context, (String)"context");
            NotificationRequester notificationRequester = new NotificationRequester(context);
            Permissions permissions2 = this.mPermissions;
            if (permissions2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException((String)"mPermissions");
            }
            SimpleRequester simpleRequester = permissions2.isPermissionPresentInManifest("android.permission.WRITE_CONTACTS") ? new SimpleRequester("android.permission.WRITE_CONTACTS", "android.permission.READ_CONTACTS") : new SimpleRequester("android.permission.READ_CONTACTS");
            Pair[] arrpair = new Pair[]{TuplesKt.to((Object)PermissionsTypes.LOCATION.getType(), (Object)new LocationRequester()), TuplesKt.to((Object)PermissionsTypes.CAMERA.getType(), (Object)new SimpleRequester("android.permission.CAMERA")), TuplesKt.to((Object)PermissionsTypes.CONTACTS.getType(), (Object)simpleRequester), TuplesKt.to((Object)PermissionsTypes.AUDIO_RECORDING.getType(), (Object)new SimpleRequester("android.permission.RECORD_AUDIO")), TuplesKt.to((Object)PermissionsTypes.CAMERA_ROLL.getType(), (Object)new SimpleRequester("android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE")), TuplesKt.to((Object)PermissionsTypes.CALENDAR.getType(), (Object)new SimpleRequester("android.permission.READ_CALENDAR", "android.permission.WRITE_CALENDAR")), TuplesKt.to((Object)PermissionsTypes.SMS.getType(), (Object)new SimpleRequester("android.permission.READ_SMS")), TuplesKt.to((Object)PermissionsTypes.NOTIFICATIONS.getType(), (Object)notificationRequester), TuplesKt.to((Object)PermissionsTypes.USER_FACING_NOTIFICATIONS.getType(), (Object)notificationRequester), TuplesKt.to((Object)PermissionsTypes.SYSTEM_BRIGHTNESS.getType(), (Object)new SimpleRequester("android.permission.WRITE_SETTINGS")), TuplesKt.to((Object)PermissionsTypes.REMINDERS.getType(), (Object)new RemindersRequester())};
            this.mRequesters = MapsKt.mapOf((Pair[])arrpair);
            return;
        }
        throw (Throwable)new IllegalStateException("Couldn't find implementation for Permissions interface.");
    }
}

