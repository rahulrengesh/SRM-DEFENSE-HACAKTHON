/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.provider.Settings
 *  android.provider.Settings$System
 *  androidx.core.app.ActivityCompat
 *  androidx.core.content.ContextCompat
 *  com.facebook.react.modules.core.PermissionAwareActivity
 *  com.facebook.react.modules.core.PermissionListener
 *  dalvik.annotation.SourceDebugExtension
 *  expo.modules.permissions.PermissionsService$askForPermissions
 *  expo.modules.permissions.PermissionsService$askForPermissions$newListener
 *  expo.modules.permissions.PermissionsService$askForPermissionsWithPromise
 *  expo.modules.permissions.PermissionsService$delegateRequestToActivity$
 *  expo.modules.permissions.PermissionsService$delegateRequestToActivity$$inlined
 *  expo.modules.permissions.PermissionsService$delegateRequestToActivity$$inlined$run
 *  expo.modules.permissions.PermissionsService$delegateRequestToActivity$$inlined$run$lambda
 *  expo.modules.permissions.PermissionsService$getPermissionsWithPromise
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Iterable
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 *  kotlin.Metadata
 *  kotlin.Pair
 *  kotlin.TypeCastException
 *  kotlin.collections.ArraysKt
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 *  org.unimodules.core.ModuleRegistry
 *  org.unimodules.core.Promise
 *  org.unimodules.core.interfaces.ActivityProvider
 *  org.unimodules.core.interfaces.LifecycleEventListener
 *  org.unimodules.core.interfaces.RegistryLifecycleListener
 *  org.unimodules.core.interfaces.RegistryLifecycleListener$-CC
 *  org.unimodules.core.interfaces.services.UIManager
 *  org.unimodules.interfaces.permissions.Permissions
 *  org.unimodules.interfaces.permissions.PermissionsResponse
 *  org.unimodules.interfaces.permissions.PermissionsResponseListener
 *  org.unimodules.interfaces.permissions.PermissionsStatus
 */
package expo.modules.permissions;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.facebook.react.modules.core.PermissionAwareActivity;
import com.facebook.react.modules.core.PermissionListener;
import dalvik.annotation.SourceDebugExtension;
import expo.modules.permissions.PermissionsService;
import expo.modules.permissions.PermissionsService$delegateRequestToActivity$;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TypeCastException;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.unimodules.core.ModuleRegistry;
import org.unimodules.core.Promise;
import org.unimodules.core.interfaces.ActivityProvider;
import org.unimodules.core.interfaces.InternalModule;
import org.unimodules.core.interfaces.LifecycleEventListener;
import org.unimodules.core.interfaces.RegistryLifecycleListener;
import org.unimodules.core.interfaces.services.UIManager;
import org.unimodules.interfaces.permissions.Permissions;
import org.unimodules.interfaces.permissions.PermissionsResponse;
import org.unimodules.interfaces.permissions.PermissionsResponseListener;
import org.unimodules.interfaces.permissions.PermissionsStatus;

@SourceDebugExtension(value="SMAP\nPermissionsService.kt\nKotlin\n*S Kotlin\n*F\n+ 1 PermissionsService.kt\nexpo/modules/permissions/PermissionsService\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 3 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,309:1\n10894#2,2:310\n8888#2:312\n9221#2,3:313\n10032#2,2:318\n8888#2:322\n9221#2,3:323\n37#3,2:316\n1587#4,2:320\n*E\n*S KotlinDebug\n*F\n+ 1 PermissionsService.kt\nexpo/modules/permissions/PermissionsService\n*L\n48#1,2:310\n91#1:312\n91#1,3:313\n133#1,2:318\n218#1:322\n218#1,3:323\n103#1,2:316\n190#1,2:320\n*E\n")
@Metadata(bv={1, 0, 3}, d1={"\u0000\u0084\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010$\n\u0002\b\u0002\n\u0002\u0010\u0015\n\u0002\b\u0002\b\u0016\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u0003B\r\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\u0002\u0010\u0006J\u001d\u0010\u0015\u001a\u00020\u00162\u000e\u0010\u0017\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000f0\u000eH\u0002\u00a2\u0006\u0002\u0010\u0018J%\u0010\u0019\u001a\u00020\u00162\u000e\u0010\u0017\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000f0\u000e2\u0006\u0010\u001a\u001a\u00020\fH\u0014\u00a2\u0006\u0002\u0010\u001bJ)\u0010\u001c\u001a\u00020\u00162\u0006\u0010\u001d\u001a\u00020\f2\u0012\u0010\u0017\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000f0\u000e\"\u00020\u000fH\u0016\u00a2\u0006\u0002\u0010\u001eJ)\u0010\u001f\u001a\u00020\u00162\u0006\u0010 \u001a\u00020!2\u0012\u0010\u0017\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000f0\u000e\"\u00020\u000fH\u0016\u00a2\u0006\u0002\u0010\"J\b\u0010#\u001a\u00020\u0016H\u0003J\u0010\u0010$\u001a\u00020\u00142\u0006\u0010%\u001a\u00020\u000fH\u0002J%\u0010&\u001a\u00020\u00162\u000e\u0010\u0017\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000f0\u000e2\u0006\u0010\u001a\u001a\u00020\fH\u0004\u00a2\u0006\u0002\u0010\u001bJ\u0010\u0010'\u001a\u00020\u00142\u0006\u0010%\u001a\u00020\u000fH\u0002J\u0016\u0010(\u001a\u0010\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020+0*0)H\u0016J\u0010\u0010,\u001a\u00020-2\u0006\u0010%\u001a\u00020\u000fH\u0002J\u0010\u0010.\u001a\u00020-2\u0006\u0010%\u001a\u00020\u000fH\u0014J\u0018\u0010/\u001a\u0002002\u0006\u0010%\u001a\u00020\u000f2\u0006\u00101\u001a\u00020-H\u0002J)\u00102\u001a\u00020\u00162\u0006\u0010\u001d\u001a\u00020\f2\u0012\u0010\u0017\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000f0\u000e\"\u00020\u000fH\u0016\u00a2\u0006\u0002\u0010\u001eJ)\u00103\u001a\u00020\u00162\u0006\u0010 \u001a\u00020!2\u0012\u0010\u0017\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000f0\u000e\"\u00020\u000fH\u0016\u00a2\u0006\u0002\u0010\"J!\u00104\u001a\u00020\u00142\u0012\u0010\u0017\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000f0\u000e\"\u00020\u000fH\u0016\u00a2\u0006\u0002\u00105J\b\u00106\u001a\u00020\u0014H\u0002J\u0010\u00107\u001a\u00020\u00142\u0006\u0010%\u001a\u00020\u000fH\u0002J\u0010\u00108\u001a\u00020\u00142\u0006\u0010%\u001a\u00020\u000fH\u0016J\b\u00109\u001a\u00020\u0014H\u0002J\u0010\u0010:\u001a\u00020\u00162\u0006\u0010;\u001a\u00020<H\u0016J\b\u0010=\u001a\u00020\u0016H\u0016J\b\u0010>\u001a\u00020\u0016H\u0016J\b\u0010?\u001a\u00020\u0016H\u0016J1\u0010@\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u0002000A2\u000e\u0010B\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u000f0\u000e2\u0006\u0010C\u001a\u00020DH\u0002\u00a2\u0006\u0002\u0010ER\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0010\u0010\t\u001a\u0004\u0018\u00010\nX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000b\u001a\u0004\u0018\u00010\fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001a\u0010\r\u001a\f\u0012\u0006\b\u0001\u0012\u00020\u000f\u0018\u00010\u000eX\u0082\u000e\u00a2\u0006\u0004\n\u0002\u0010\u0010R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082.\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006F"}, d2={"Lexpo/modules/permissions/PermissionsService;", "Lorg/unimodules/core/interfaces/InternalModule;", "Lorg/unimodules/interfaces/permissions/Permissions;", "Lorg/unimodules/core/interfaces/LifecycleEventListener;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "getContext", "()Landroid/content/Context;", "mActivityProvider", "Lorg/unimodules/core/interfaces/ActivityProvider;", "mAskAsyncListener", "Lorg/unimodules/interfaces/permissions/PermissionsResponseListener;", "mAskAsyncRequestedPermissions", "", "", "[Ljava/lang/String;", "mAskedPermissionsCache", "Landroid/content/SharedPreferences;", "mWriteSettingsPermissionBeingAsked", "", "addToAskedPermissionsCache", "", "permissions", "([Ljava/lang/String;)V", "askForManifestPermissions", "listener", "([Ljava/lang/String;Lorg/unimodules/interfaces/permissions/PermissionsResponseListener;)V", "askForPermissions", "responseListener", "(Lorg/unimodules/interfaces/permissions/PermissionsResponseListener;[Ljava/lang/String;)V", "askForPermissionsWithPromise", "promise", "Lorg/unimodules/core/Promise;", "(Lorg/unimodules/core/Promise;[Ljava/lang/String;)V", "askForWriteSettingsPermissionFirst", "canAskAgain", "permission", "delegateRequestToActivity", "didAsk", "getExportedInterfaces", "", "Ljava/lang/Class;", "", "getManifestPermission", "", "getManifestPermissionFromContext", "getPermissionResponseFromNativeResponse", "Lorg/unimodules/interfaces/permissions/PermissionsResponse;", "result", "getPermissions", "getPermissionsWithPromise", "hasGrantedPermissions", "([Ljava/lang/String;)Z", "hasWriteSettingsPermission", "isPermissionGranted", "isPermissionPresentInManifest", "isRuntimePermissionsAvailable", "onCreate", "moduleRegistry", "Lorg/unimodules/core/ModuleRegistry;", "onHostDestroy", "onHostPause", "onHostResume", "parseNativeResult", "", "permissionsString", "grantResults", "", "([Ljava/lang/String;[I)Ljava/util/Map;", "expo-permissions_release"}, k=1, mv={1, 1, 15})
public class PermissionsService
implements InternalModule,
Permissions,
LifecycleEventListener {
    private final Context context;
    private ActivityProvider mActivityProvider;
    private PermissionsResponseListener mAskAsyncListener;
    private String[] mAskAsyncRequestedPermissions;
    private SharedPreferences mAskedPermissionsCache;
    private boolean mWriteSettingsPermissionBeingAsked;

    public PermissionsService(Context context) {
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
        this.context = context;
    }

    public static final /* synthetic */ PermissionsResponse access$getPermissionResponseFromNativeResponse(PermissionsService permissionsService, String string, int n) {
        return permissionsService.getPermissionResponseFromNativeResponse(string, n);
    }

    public static final /* synthetic */ boolean access$hasWriteSettingsPermission(PermissionsService permissionsService) {
        return permissionsService.hasWriteSettingsPermission();
    }

    public static final /* synthetic */ Map access$parseNativeResult(PermissionsService permissionsService, String[] arrstring, int[] arrn) {
        return permissionsService.parseNativeResult(arrstring, arrn);
    }

    private final void addToAskedPermissionsCache(String[] arrstring) {
        SharedPreferences sharedPreferences = this.mAskedPermissionsCache;
        if (sharedPreferences == null) {
            Intrinsics.throwUninitializedPropertyAccessException((String)"mAskedPermissionsCache");
        }
        SharedPreferences.Editor editor = sharedPreferences.edit();
        int n = arrstring.length;
        for (int i = 0; i < n; ++i) {
            editor.putBoolean(arrstring[i], true);
        }
        editor.apply();
    }

    private final void askForWriteSettingsPermissionFirst() {
        Intent intent = new Intent("android.settings.action.MANAGE_WRITE_SETTINGS");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("package:");
        stringBuilder.append(this.context.getPackageName());
        intent.setData(Uri.parse((String)stringBuilder.toString()));
        intent.addFlags(268435456);
        this.mWriteSettingsPermissionBeingAsked = true;
        this.context.startActivity(intent);
    }

    private final boolean canAskAgain(String string) {
        Activity activity;
        ActivityProvider activityProvider = this.mActivityProvider;
        if (activityProvider != null && (activity = activityProvider.getCurrentActivity()) != null) {
            return ActivityCompat.shouldShowRequestPermissionRationale((Activity)activity, (String)string);
        }
        return false;
    }

    private final boolean didAsk(String string) {
        SharedPreferences sharedPreferences = this.mAskedPermissionsCache;
        if (sharedPreferences == null) {
            Intrinsics.throwUninitializedPropertyAccessException((String)"mAskedPermissionsCache");
        }
        return sharedPreferences.getBoolean(string, false);
    }

    private final int getManifestPermission(String string) {
        Activity activity;
        ActivityProvider activityProvider = this.mActivityProvider;
        if (activityProvider != null && (activity = activityProvider.getCurrentActivity()) != null && activity instanceof PermissionAwareActivity) {
            return ContextCompat.checkSelfPermission((Context)((Context)activity), (String)string);
        }
        return this.getManifestPermissionFromContext(string);
    }

    private final PermissionsResponse getPermissionResponseFromNativeResponse(String string, int n) {
        PermissionsStatus permissionsStatus = n == 0 ? PermissionsStatus.GRANTED : (this.didAsk(string) ? PermissionsStatus.DENIED : PermissionsStatus.UNDETERMINED);
        boolean bl = permissionsStatus == PermissionsStatus.DENIED ? this.canAskAgain(string) : true;
        return new PermissionsResponse(permissionsStatus, bl);
    }

    private final boolean hasWriteSettingsPermission() {
        if (this.isRuntimePermissionsAvailable()) {
            return Settings.System.canWrite((Context)this.context.getApplicationContext());
        }
        return true;
    }

    private final boolean isPermissionGranted(String string) {
        if (string.hashCode() == -2078357533 && string.equals((Object)"android.permission.WRITE_SETTINGS")) {
            return this.hasWriteSettingsPermission();
        }
        return this.getManifestPermission(string) == 0;
    }

    private final boolean isRuntimePermissionsAvailable() {
        return Build.VERSION.SDK_INT >= 23;
    }

    private final Map<String, PermissionsResponse> parseNativeResult(String[] arrstring, int[] arrn) {
        HashMap hashMap = new HashMap();
        for (Pair pair : (Iterable)ArraysKt.zip((int[])arrn, (Object[])arrstring)) {
            int n = ((Number)pair.component1()).intValue();
            String string = (String)pair.component2();
            ((Map)hashMap).put((Object)string, (Object)this.getPermissionResponseFromNativeResponse(string, n));
        }
        return (Map)hashMap;
    }

    protected void askForManifestPermissions(String[] arrstring, PermissionsResponseListener permissionsResponseListener) {
        Intrinsics.checkParameterIsNotNull((Object)arrstring, (String)"permissions");
        Intrinsics.checkParameterIsNotNull((Object)permissionsResponseListener, (String)"listener");
        if (!this.isRuntimePermissionsAvailable()) {
            this.addToAskedPermissionsCache(arrstring);
            Collection collection = (Collection)new ArrayList(arrstring.length);
            int n = arrstring.length;
            for (int i = 0; i < n; ++i) {
                collection.add((Object)this.getManifestPermission(arrstring[i]));
            }
            permissionsResponseListener.onResult(this.parseNativeResult(arrstring, CollectionsKt.toIntArray((Collection)((Collection)((List)collection)))));
            return;
        }
        this.delegateRequestToActivity(arrstring, permissionsResponseListener);
    }

    public /* varargs */ void askForPermissions(PermissionsResponseListener permissionsResponseListener, String ... arrstring) throws IllegalStateException {
        Intrinsics.checkParameterIsNotNull((Object)permissionsResponseListener, (String)"responseListener");
        Intrinsics.checkParameterIsNotNull((Object)arrstring, (String)"permissions");
        if (ArraysKt.contains((Object[])arrstring, (Object)"android.permission.WRITE_SETTINGS") && this.isRuntimePermissionsAvailable()) {
            List list = ArraysKt.toMutableList((Object[])arrstring);
            list.remove((Object)"android.permission.WRITE_SETTINGS");
            Object[] arrobject = ((Collection)list).toArray((Object[])new String[0]);
            if (arrobject != null) {
                String[] arrstring2 = (String[])arrobject;
                PermissionsResponseListener permissionsResponseListener2 = new PermissionsResponseListener(this, permissionsResponseListener){
                    final /* synthetic */ PermissionsResponseListener $responseListener;
                    final /* synthetic */ PermissionsService this$0;
                    {
                        this.this$0 = permissionsService;
                        this.$responseListener = permissionsResponseListener;
                    }

                    public final void onResult(Map<String, PermissionsResponse> map) {
                        int n = PermissionsService.access$hasWriteSettingsPermission(this.this$0) ? 0 : -1;
                        Intrinsics.checkExpressionValueIsNotNull(map, (String)"it");
                        map.put((Object)"android.permission.WRITE_SETTINGS", (Object)PermissionsService.access$getPermissionResponseFromNativeResponse(this.this$0, "android.permission.WRITE_SETTINGS", n));
                        this.$responseListener.onResult(map);
                    }
                };
                if (!this.hasWriteSettingsPermission()) {
                    if (this.mAskAsyncListener == null) {
                        this.mAskAsyncListener = permissionsResponseListener2;
                        this.mAskAsyncRequestedPermissions = arrstring2;
                        this.addToAskedPermissionsCache(new String[]{"android.permission.WRITE_SETTINGS"});
                        this.askForWriteSettingsPermissionFirst();
                        return;
                    }
                    throw (Throwable)new IllegalStateException("Another permissions request is in progress. Await the old request and then try again.");
                }
                this.askForManifestPermissions(arrstring2, permissionsResponseListener2);
                return;
            }
            throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<T>");
        }
        this.askForManifestPermissions(arrstring, permissionsResponseListener);
    }

    public /* varargs */ void askForPermissionsWithPromise(Promise promise, String ... arrstring) {
        Intrinsics.checkParameterIsNotNull((Object)promise, (String)"promise");
        Intrinsics.checkParameterIsNotNull((Object)arrstring, (String)"permissions");
        this.askForPermissions(new PermissionsResponseListener(this, promise, arrstring){
            final /* synthetic */ String[] $permissions;
            final /* synthetic */ Promise $promise;
            final /* synthetic */ PermissionsService this$0;
            {
                this.this$0 = permissionsService;
                this.$promise = promise;
                this.$permissions = arrstring;
            }

            public final void onResult(Map<String, PermissionsResponse> map) {
                PermissionsService permissionsService = this.this$0;
                Promise promise = this.$promise;
                Object[] arrobject = this.$permissions;
                permissionsService.getPermissionsWithPromise(promise, (String[])Arrays.copyOf((Object[])arrobject, (int)arrobject.length));
            }
        }, (String[])Arrays.copyOf((Object[])arrstring, (int)arrstring.length));
    }

    protected final void delegateRequestToActivity(String[] arrstring, PermissionsResponseListener permissionsResponseListener) {
        Activity activity;
        Intrinsics.checkParameterIsNotNull((Object)arrstring, (String)"permissions");
        Intrinsics.checkParameterIsNotNull((Object)permissionsResponseListener, (String)"listener");
        this.addToAskedPermissionsCache(arrstring);
        ActivityProvider activityProvider = this.mActivityProvider;
        if (activityProvider != null && (activity = activityProvider.getCurrentActivity()) != null) {
            if (activity instanceof PermissionAwareActivity) {
                ((PermissionAwareActivity)activity).requestPermissions(arrstring, 13, new PermissionListener(this, arrstring, permissionsResponseListener){
                    final /* synthetic */ PermissionsResponseListener $listener$inlined;
                    final /* synthetic */ String[] $permissions$inlined;
                    final /* synthetic */ PermissionsService this$0;
                    {
                        this.this$0 = permissionsService;
                        this.$permissions$inlined = arrstring;
                        this.$listener$inlined = permissionsResponseListener;
                    }

                    public final boolean onRequestPermissionsResult(int n, String[] arrstring, int[] arrn) {
                        if (n == 13) {
                            PermissionsResponseListener permissionsResponseListener = this.$listener$inlined;
                            PermissionsService permissionsService = this.this$0;
                            Intrinsics.checkExpressionValueIsNotNull((Object)arrstring, (String)"receivePermissions");
                            Intrinsics.checkExpressionValueIsNotNull((Object)arrn, (String)"grantResults");
                            permissionsResponseListener.onResult(PermissionsService.access$parseNativeResult(permissionsService, arrstring, arrn));
                            return true;
                        }
                        PermissionsResponseListener permissionsResponseListener = this.$listener$inlined;
                        PermissionsService permissionsService = this.this$0;
                        Intrinsics.checkExpressionValueIsNotNull((Object)arrstring, (String)"receivePermissions");
                        int n2 = arrstring.length;
                        int[] arrn2 = new int[n2];
                        for (int i = 0; i < n2; ++i) {
                            arrn2[i] = -1;
                        }
                        permissionsResponseListener.onResult(PermissionsService.access$parseNativeResult(permissionsService, arrstring, arrn2));
                        return false;
                    }
                });
                return;
            }
            int n = arrstring.length;
            int[] arrn = new int[n];
            for (int i = 0; i < n; ++i) {
                arrn[i] = -1;
            }
            permissionsResponseListener.onResult(this.parseNativeResult(arrstring, arrn));
        }
    }

    public final Context getContext() {
        return this.context;
    }

    public List<Class<? extends Object>> getExportedInterfaces() {
        return CollectionsKt.listOf(Permissions.class);
    }

    protected int getManifestPermissionFromContext(String string) {
        Intrinsics.checkParameterIsNotNull((Object)string, (String)"permission");
        return ContextCompat.checkSelfPermission((Context)this.context, (String)string);
    }

    public /* varargs */ void getPermissions(PermissionsResponseListener permissionsResponseListener, String ... arrstring) {
        Intrinsics.checkParameterIsNotNull((Object)permissionsResponseListener, (String)"responseListener");
        Intrinsics.checkParameterIsNotNull((Object)arrstring, (String)"permissions");
        Collection collection = (Collection)new ArrayList(arrstring.length);
        int n = arrstring.length;
        for (int i = 0; i < n; ++i) {
            int n2 = this.isPermissionGranted(arrstring[i]) ? 0 : -1;
            collection.add((Object)n2);
        }
        permissionsResponseListener.onResult(this.parseNativeResult(arrstring, CollectionsKt.toIntArray((Collection)((Collection)((List)collection)))));
    }

    public /* varargs */ void getPermissionsWithPromise(Promise promise, String ... arrstring) {
        Intrinsics.checkParameterIsNotNull((Object)promise, (String)"promise");
        Intrinsics.checkParameterIsNotNull((Object)arrstring, (String)"permissions");
        this.getPermissions(new PermissionsResponseListener(promise){
            final /* synthetic */ Promise $promise;
            {
                this.$promise = promise;
            }

            /*
             * Unable to fully structure code
             * Enabled aggressive block sorting
             * Lifted jumps to return sites
             */
            public final void onResult(Map<String, PermissionsResponse> var1_1) {
                block5 : {
                    block4 : {
                        Intrinsics.checkParameterIsNotNull(var1_1, (String)"permissionsMap");
                        var2_2 = var1_1.isEmpty();
                        var3_3 = true;
                        if (var2_2) ** GOTO lbl8
                        var4_4 = var1_1.entrySet().iterator();
                        do {
                            if (var4_4.hasNext()) continue;
lbl8: // 2 sources:
                            var6_6 = true;
                            break block4;
                        } while (var5_5 = ((PermissionsResponse)((java.util.Map$Entry)var4_4.next()).getValue()).getStatus() == PermissionsStatus.GRANTED);
                        var6_6 = false;
                    }
                    if (var1_1.isEmpty()) ** GOTO lbl17
                    var7_7 = var1_1.entrySet().iterator();
                    do {
                        if (var7_7.hasNext()) continue;
lbl17: // 2 sources:
                        var9_9 = true;
                        break block5;
                    } while (var8_8 = ((PermissionsResponse)((java.util.Map$Entry)var7_7.next()).getValue()).getStatus() == PermissionsStatus.DENIED);
                    var9_9 = false;
                }
                if (!var1_1.isEmpty()) {
                    var10_10 = var1_1.entrySet().iterator();
                    while (var10_10.hasNext()) {
                        if (((PermissionsResponse)((java.util.Map$Entry)var10_10.next()).getValue()).getCanAskAgain()) continue;
                        var3_3 = false;
                        break;
                    }
                }
                var11_11 = this.$promise;
                var12_12 = new android.os.Bundle();
                var12_12.putString("expires", "never");
                var13_13 = var6_6 != false ? PermissionsStatus.GRANTED.getStatus() : (var9_9 != false ? PermissionsStatus.DENIED.getStatus() : PermissionsStatus.UNDETERMINED.getStatus());
                var12_12.putString("status", var13_13);
                var12_12.putBoolean("canAskAgain", var3_3);
                var12_12.putBoolean("granted", var6_6);
                var11_11.resolve((Object)var12_12);
            }
        }, (String[])Arrays.copyOf((Object[])arrstring, (int)arrstring.length));
    }

    public /* varargs */ boolean hasGrantedPermissions(String ... arrstring) {
        Intrinsics.checkParameterIsNotNull((Object)arrstring, (String)"permissions");
        int n = arrstring.length;
        for (int i = 0; i < n; ++i) {
            if (this.isPermissionGranted(arrstring[i])) continue;
            return false;
        }
        return true;
    }

    /*
     * Exception decompiling
     */
    public boolean isPermissionPresentInManifest(String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl27.1 : ICONST_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    public void onCreate(ModuleRegistry moduleRegistry2) throws IllegalStateException {
        Intrinsics.checkParameterIsNotNull((Object)moduleRegistry2, (String)"moduleRegistry");
        ActivityProvider activityProvider = (ActivityProvider)moduleRegistry2.getModule(ActivityProvider.class);
        if (activityProvider != null) {
            this.mActivityProvider = activityProvider;
            ((UIManager)moduleRegistry2.getModule(UIManager.class)).registerLifecycleEventListener((LifecycleEventListener)this);
            SharedPreferences sharedPreferences = this.context.getApplicationContext().getSharedPreferences("expo.modules.permissions.asked", 0);
            Intrinsics.checkExpressionValueIsNotNull((Object)sharedPreferences, (String)"context.applicationConte\u2026ME, Context.MODE_PRIVATE)");
            this.mAskedPermissionsCache = sharedPreferences;
            return;
        }
        throw (Throwable)new IllegalStateException("Couldn't find implementation for ActivityProvider.");
    }

    public /* synthetic */ void onDestroy() {
        RegistryLifecycleListener.-CC.$default$onDestroy((RegistryLifecycleListener)this);
    }

    public void onHostDestroy() {
    }

    public void onHostPause() {
    }

    public void onHostResume() {
        String[] arrstring;
        if (!this.mWriteSettingsPermissionBeingAsked) {
            return;
        }
        this.mWriteSettingsPermissionBeingAsked = false;
        PermissionsResponseListener permissionsResponseListener = this.mAskAsyncListener;
        if (permissionsResponseListener == null) {
            Intrinsics.throwNpe();
        }
        if ((arrstring = this.mAskAsyncRequestedPermissions) == null) {
            Intrinsics.throwNpe();
        }
        this.mAskAsyncListener = null;
        this.mAskAsyncRequestedPermissions = null;
        int n = arrstring.length;
        boolean bl = false;
        if (n == 0) {
            bl = true;
        }
        if (bl ^ true) {
            this.askForManifestPermissions(arrstring, permissionsResponseListener);
            return;
        }
        permissionsResponseListener.onResult((Map)new LinkedHashMap());
    }
}

