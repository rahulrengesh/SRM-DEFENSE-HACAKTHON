/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  dalvik.annotation.SourceDebugExtension
 *  expo.modules.permissions.requesters.PermissionRequester
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 *  kotlin.Metadata
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 *  org.unimodules.interfaces.permissions.PermissionsResponse
 *  org.unimodules.interfaces.permissions.PermissionsStatus
 */
package expo.modules.permissions.requesters;

import android.os.Bundle;
import dalvik.annotation.SourceDebugExtension;
import expo.modules.permissions.requesters.PermissionRequester;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.unimodules.interfaces.permissions.PermissionsResponse;
import org.unimodules.interfaces.permissions.PermissionsStatus;

@SourceDebugExtension(value="SMAP\nRemindersRequester.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RemindersRequester.kt\nexpo/modules/permissions/requesters/RemindersRequester\n*L\n1#1,24:1\n*E\n")
@Metadata(bv={1, 0, 3}, d1={"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H\u0016J\u001c\u0010\u0006\u001a\u00020\u00072\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\n0\tH\u0016\u00a8\u0006\u000b"}, d2={"Lexpo/modules/permissions/requesters/RemindersRequester;", "Lexpo/modules/permissions/requesters/PermissionRequester;", "()V", "getAndroidPermissions", "", "", "parseAndroidPermissions", "Landroid/os/Bundle;", "permissionsResponse", "", "Lorg/unimodules/interfaces/permissions/PermissionsResponse;", "expo-permissions_release"}, k=1, mv={1, 1, 15})
public final class RemindersRequester
implements PermissionRequester {
    public List<String> getAndroidPermissions() {
        return CollectionsKt.emptyList();
    }

    public Bundle parseAndroidPermissions(Map<String, PermissionsResponse> map) {
        Intrinsics.checkParameterIsNotNull(map, (String)"permissionsResponse");
        Bundle bundle = new Bundle();
        bundle.putString("status", PermissionsStatus.GRANTED.getStatus());
        bundle.putString("expires", "never");
        bundle.putBoolean("canAskAgain", true);
        bundle.putBoolean("granted", true);
        return bundle;
    }
}

