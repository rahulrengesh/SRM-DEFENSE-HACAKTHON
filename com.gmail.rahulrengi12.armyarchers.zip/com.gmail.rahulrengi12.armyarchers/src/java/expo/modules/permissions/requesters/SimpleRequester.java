/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  dalvik.annotation.SourceDebugExtension
 *  expo.modules.permissions.requesters.PermissionRequester
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  kotlin.Metadata
 *  kotlin.collections.ArraysKt
 *  kotlin.collections.MapsKt
 *  kotlin.jvm.internal.Intrinsics
 *  org.unimodules.interfaces.permissions.PermissionsResponse
 *  org.unimodules.interfaces.permissions.PermissionsStatus
 */
package expo.modules.permissions.requesters;

import android.os.Bundle;
import dalvik.annotation.SourceDebugExtension;
import expo.modules.permissions.requesters.PermissionRequester;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.Intrinsics;
import org.unimodules.interfaces.permissions.PermissionsResponse;
import org.unimodules.interfaces.permissions.PermissionsStatus;

@SourceDebugExtension(value="SMAP\nSimpleRequester.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SimpleRequester.kt\nexpo/modules/permissions/requesters/SimpleRequester\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,37:1\n1474#2,3:38\n1474#2,3:41\n1474#2,3:44\n*E\n*S KotlinDebug\n*F\n+ 1 SimpleRequester.kt\nexpo/modules/permissions/requesters/SimpleRequester\n*L\n19#1,3:38\n19#1,3:41\n19#1,3:44\n*E\n")
@Metadata(bv={1, 0, 3}, d1={"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0019\u0012\u0012\u0010\u0002\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00040\u0003\"\u00020\u0004\u00a2\u0006\u0002\u0010\u0005J\u000e\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00040\nH\u0016J\u001c\u0010\u000b\u001a\u00020\f2\u0012\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u000f0\u000eH\u0016R\u001b\u0010\u0002\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00040\u0003\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u0006\u0010\u0007\u00a8\u0006\u0010"}, d2={"Lexpo/modules/permissions/requesters/SimpleRequester;", "Lexpo/modules/permissions/requesters/PermissionRequester;", "permission", "", "", "([Ljava/lang/String;)V", "getPermission", "()[Ljava/lang/String;", "[Ljava/lang/String;", "getAndroidPermissions", "", "parseAndroidPermissions", "Landroid/os/Bundle;", "permissionsResponse", "", "Lorg/unimodules/interfaces/permissions/PermissionsResponse;", "expo-permissions_release"}, k=1, mv={1, 1, 15})
public final class SimpleRequester
implements PermissionRequester {
    private final String[] permission;

    public /* varargs */ SimpleRequester(String ... arrstring) {
        Intrinsics.checkParameterIsNotNull((Object)arrstring, (String)"permission");
        this.permission = arrstring;
    }

    public List<String> getAndroidPermissions() {
        return ArraysKt.toList((Object[])this.permission);
    }

    public final String[] getPermission() {
        return this.permission;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public Bundle parseAndroidPermissions(Map<String, PermissionsResponse> var1_1) {
        block9 : {
            block7 : {
                block8 : {
                    block6 : {
                        Intrinsics.checkParameterIsNotNull(var1_1, (String)"permissionsResponse");
                        var2_2 = new Bundle();
                        var3_3 = (Iterable)this.getAndroidPermissions();
                        if (var3_3 instanceof Collection && ((Collection)var3_3).isEmpty()) ** GOTO lbl8
                        var4_4 = var3_3.iterator();
                        do {
                            if (var4_4.hasNext()) continue;
lbl8: // 2 sources:
                            var6_6 = true;
                            break block6;
                        } while (var5_5 = ((PermissionsResponse)MapsKt.getValue(var1_1, (Object)((String)var4_4.next()))).getStatus() == PermissionsStatus.GRANTED);
                        var6_6 = false;
                    }
                    if (!var6_6) break block8;
                    var11_7 = PermissionsStatus.GRANTED;
                    break block9;
                }
                var7_8 = (Iterable)this.getAndroidPermissions();
                if (var7_8 instanceof Collection && ((Collection)var7_8).isEmpty()) ** GOTO lbl22
                var8_9 = var7_8.iterator();
                do {
                    if (var8_9.hasNext()) continue;
lbl22: // 2 sources:
                    var10_11 = true;
                    break block7;
                } while (var9_10 = ((PermissionsResponse)MapsKt.getValue(var1_1, (Object)((String)var8_9.next()))).getStatus() == PermissionsStatus.DENIED);
                var10_11 = false;
            }
            var11_7 = var10_11 != false ? PermissionsStatus.DENIED : PermissionsStatus.UNDETERMINED;
        }
        var2_2.putString("status", var11_7.getStatus());
        var2_2.putString("expires", "never");
        var12_12 = (Iterable)this.getAndroidPermissions();
        if (!(var12_12 instanceof Collection) || !((Collection)var12_12).isEmpty()) {
            var13_14 = var12_12.iterator();
            while (var13_14.hasNext()) {
                if (((PermissionsResponse)MapsKt.getValue(var1_1, (Object)((String)var13_14.next()))).getCanAskAgain()) continue;
                var14_13 = false;
                break;
            }
        } else {
            var14_13 = true;
        }
        var2_2.putBoolean("canAskAgain", var14_13);
        var15_15 = PermissionsStatus.GRANTED;
        var16_16 = false;
        if (var11_7 == var15_15) {
            var16_16 = true;
        }
        var2_2.putBoolean("granted", var16_16);
        return var2_2;
    }
}

