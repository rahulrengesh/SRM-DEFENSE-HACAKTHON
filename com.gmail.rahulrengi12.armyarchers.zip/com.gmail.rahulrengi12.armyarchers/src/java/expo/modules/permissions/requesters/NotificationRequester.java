/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  androidx.core.app.NotificationManagerCompat
 *  dalvik.annotation.SourceDebugExtension
 *  expo.modules.permissions.requesters.PermissionRequester
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 *  kotlin.Metadata
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 *  org.unimodules.interfaces.permissions.PermissionsResponse
 *  org.unimodules.interfaces.permissions.PermissionsStatus
 */
package expo.modules.permissions.requesters;

import android.content.Context;
import android.os.Bundle;
import androidx.core.app.NotificationManagerCompat;
import dalvik.annotation.SourceDebugExtension;
import expo.modules.permissions.requesters.PermissionRequester;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import org.unimodules.interfaces.permissions.PermissionsResponse;
import org.unimodules.interfaces.permissions.PermissionsStatus;

@SourceDebugExtension(value="SMAP\nNotificationRequester.kt\nKotlin\n*S Kotlin\n*F\n+ 1 NotificationRequester.kt\nexpo/modules/permissions/requesters/NotificationRequester\n*L\n1#1,29:1\n*E\n")
@Metadata(bv={1, 0, 3}, d1={"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u000e\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006H\u0016J\u001c\u0010\b\u001a\u00020\t2\u0012\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\f0\u000bH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\r"}, d2={"Lexpo/modules/permissions/requesters/NotificationRequester;", "Lexpo/modules/permissions/requesters/PermissionRequester;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "getAndroidPermissions", "", "", "parseAndroidPermissions", "Landroid/os/Bundle;", "permissionsResponse", "", "Lorg/unimodules/interfaces/permissions/PermissionsResponse;", "expo-permissions_release"}, k=1, mv={1, 1, 15})
public final class NotificationRequester
implements PermissionRequester {
    private final Context context;

    public NotificationRequester(Context context) {
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
        this.context = context;
    }

    public List<String> getAndroidPermissions() {
        return CollectionsKt.emptyList();
    }

    public Bundle parseAndroidPermissions(Map<String, PermissionsResponse> map) {
        Intrinsics.checkParameterIsNotNull(map, (String)"permissionsResponse");
        Bundle bundle = new Bundle();
        boolean bl = NotificationManagerCompat.from((Context)this.context).areNotificationsEnabled();
        PermissionsStatus permissionsStatus = bl ? PermissionsStatus.GRANTED : PermissionsStatus.DENIED;
        bundle.putString("status", permissionsStatus.getStatus());
        bundle.putString("expires", "never");
        bundle.putBoolean("canAskAgain", bl);
        bundle.putBoolean("granted", bl);
        return bundle;
    }
}

