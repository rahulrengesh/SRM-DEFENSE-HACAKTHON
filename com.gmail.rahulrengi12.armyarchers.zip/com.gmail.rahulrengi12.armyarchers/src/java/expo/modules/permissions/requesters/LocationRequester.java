/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  dalvik.annotation.SourceDebugExtension
 *  expo.modules.permissions.requesters.PermissionRequester
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  java.util.Map
 *  kotlin.Metadata
 *  kotlin.collections.CollectionsKt
 *  kotlin.collections.MapsKt
 *  kotlin.jvm.internal.Intrinsics
 *  org.unimodules.interfaces.permissions.PermissionsResponse
 *  org.unimodules.interfaces.permissions.PermissionsStatus
 */
package expo.modules.permissions.requesters;

import android.os.Build;
import android.os.Bundle;
import dalvik.annotation.SourceDebugExtension;
import expo.modules.permissions.requesters.PermissionRequester;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.Intrinsics;
import org.unimodules.interfaces.permissions.PermissionsResponse;
import org.unimodules.interfaces.permissions.PermissionsStatus;

@SourceDebugExtension(value="SMAP\nLocationRequester.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LocationRequester.kt\nexpo/modules/permissions/requesters/LocationRequester\n*L\n1#1,79:1\n*E\n")
@Metadata(bv={1, 0, 3}, d1={"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002J\u000e\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H\u0016J\u001c\u0010\u0006\u001a\u00020\u00072\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\n0\tH\u0016\u00a8\u0006\u000b"}, d2={"Lexpo/modules/permissions/requesters/LocationRequester;", "Lexpo/modules/permissions/requesters/PermissionRequester;", "()V", "getAndroidPermissions", "", "", "parseAndroidPermissions", "Landroid/os/Bundle;", "permissionsResponse", "", "Lorg/unimodules/interfaces/permissions/PermissionsResponse;", "expo-permissions_release"}, k=1, mv={1, 1, 15})
public final class LocationRequester
implements PermissionRequester {
    public List<String> getAndroidPermissions() {
        if (Build.VERSION.SDK_INT >= 29) {
            return CollectionsKt.listOf((Object[])new String[]{"android.permission.ACCESS_BACKGROUND_LOCATION", "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"});
        }
        return CollectionsKt.listOf((Object[])new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"});
    }

    public Bundle parseAndroidPermissions(Map<String, PermissionsResponse> map) {
        String string;
        boolean bl;
        String string2;
        Bundle bundle;
        boolean bl2;
        block10 : {
            block9 : {
                PermissionsResponse permissionsResponse;
                PermissionsResponse permissionsResponse2;
                block8 : {
                    String string3;
                    Intrinsics.checkParameterIsNotNull(map, (String)"permissionsResponse");
                    bundle = new Bundle();
                    permissionsResponse = (PermissionsResponse)MapsKt.getValue(map, (Object)"android.permission.ACCESS_FINE_LOCATION");
                    permissionsResponse2 = (PermissionsResponse)MapsKt.getValue(map, (Object)"android.permission.ACCESS_COARSE_LOCATION");
                    boolean bl3 = permissionsResponse2.getCanAskAgain();
                    bl = true;
                    bl2 = bl3 && permissionsResponse2.getCanAskAgain();
                    if (permissionsResponse2.getStatus() != PermissionsStatus.GRANTED && permissionsResponse.getStatus() != PermissionsStatus.GRANTED) {
                        bl = false;
                    }
                    PermissionsStatus permissionsStatus = permissionsResponse.getStatus();
                    PermissionsStatus permissionsStatus2 = PermissionsStatus.GRANTED;
                    string = "none";
                    if (permissionsStatus == permissionsStatus2) {
                        string3 = PermissionsStatus.GRANTED.getStatus();
                        string2 = "fine";
                    } else if (permissionsResponse2.getStatus() == PermissionsStatus.GRANTED) {
                        string3 = PermissionsStatus.GRANTED.getStatus();
                        string2 = "coarse";
                    } else {
                        string3 = permissionsResponse.getStatus() == PermissionsStatus.DENIED && permissionsResponse2.getStatus() == PermissionsStatus.DENIED ? PermissionsStatus.DENIED.getStatus() : PermissionsStatus.UNDETERMINED.getStatus();
                        string2 = string;
                    }
                    bundle.putString("status", string3);
                    if (Build.VERSION.SDK_INT < 29) break block8;
                    if (((PermissionsResponse)MapsKt.getValue(map, (Object)"android.permission.ACCESS_BACKGROUND_LOCATION")).getStatus() == PermissionsStatus.GRANTED) break block9;
                    string = "whenInUse";
                    break block10;
                }
                if (permissionsResponse2.getStatus() != PermissionsStatus.GRANTED && permissionsResponse.getStatus() != PermissionsStatus.GRANTED) break block10;
            }
            string = "always";
        }
        bundle.putString("expires", "never");
        bundle.putBoolean("canAskAgain", bl2);
        bundle.putBoolean("granted", bl);
        bundle.putString("scope", string);
        Bundle bundle2 = new Bundle();
        bundle2.putString("accuracy", string2);
        bundle.putBundle("android", bundle2);
        return bundle;
    }
}

