/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  dalvik.annotation.SourceDebugExtension
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package expo.modules.splashscreen;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import dalvik.annotation.SourceDebugExtension;
import expo.modules.splashscreen.SplashScreenImageResizeMode;
import expo.modules.splashscreen.SplashScreenView$WhenMappings;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@SourceDebugExtension(value="SMAP\nSplashScreenView.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SplashScreenView.kt\nexpo/modules/splashscreen/SplashScreenView\n*L\n1#1,39:1\n*E\n")
@Metadata(bv={1, 0, 3}, d1={"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fR\u0011\u0010\u0005\u001a\u00020\u0006\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b\u00a8\u0006\r"}, d2={"Lexpo/modules/splashscreen/SplashScreenView;", "Landroid/widget/RelativeLayout;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "imageView", "Landroid/widget/ImageView;", "getImageView", "()Landroid/widget/ImageView;", "configureImageViewResizeMode", "", "resizeMode", "Lexpo/modules/splashscreen/SplashScreenImageResizeMode;", "expo-splash-screen_release"}, k=1, mv={1, 1, 16})
public final class SplashScreenView
extends RelativeLayout {
    private final ImageView imageView;

    public SplashScreenView(Context context) {
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
        super(context);
        ImageView imageView = new ImageView(context);
        imageView.setLayoutParams((ViewGroup.LayoutParams)new RelativeLayout.LayoutParams(-1, -1));
        this.imageView = imageView;
        this.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        this.setClickable(true);
        this.addView((View)this.imageView);
    }

    public final void configureImageViewResizeMode(SplashScreenImageResizeMode splashScreenImageResizeMode) {
        Intrinsics.checkParameterIsNotNull((Object)((Object)splashScreenImageResizeMode), (String)"resizeMode");
        this.imageView.setScaleType(splashScreenImageResizeMode.getScaleType());
        int n = SplashScreenView$WhenMappings.$EnumSwitchMapping$0[splashScreenImageResizeMode.ordinal()];
        if (n != 1) {
            if (n != 2) {
                return;
            }
            this.imageView.setAdjustViewBounds(true);
        }
    }

    public final ImageView getImageView() {
        return this.imageView;
    }
}

