/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.view.ViewGroup
 *  expo.modules.splashscreen.SplashScreen$hide
 *  expo.modules.splashscreen.SplashScreen$preventAutoHide
 *  expo.modules.splashscreen.SplashScreen$show
 *  expo.modules.splashscreen.SplashScreenController
 *  expo.modules.splashscreen.SplashScreenImageResizeMode
 *  expo.modules.splashscreen.SplashScreenStatusBar
 *  expo.modules.splashscreen.SplashScreenViewProvider
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  java.util.WeakHashMap
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  org.unimodules.core.interfaces.SingletonModule
 */
package expo.modules.splashscreen;

import android.app.Activity;
import android.view.ViewGroup;
import expo.modules.splashscreen.NativeResourcesBasedSplashScreenViewProvider;
import expo.modules.splashscreen.SplashScreen;
import expo.modules.splashscreen.SplashScreenController;
import expo.modules.splashscreen.SplashScreenImageResizeMode;
import expo.modules.splashscreen.SplashScreenStatusBar;
import expo.modules.splashscreen.SplashScreenViewProvider;
import java.util.Map;
import java.util.WeakHashMap;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.unimodules.core.interfaces.SingletonModule;

@Metadata(bv={1, 0, 3}, d1={"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\b\u0010\t\u001a\u00020\u0004H\u0016J\u0010\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u0007H\u0007JT\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u00072!\u0010\r\u001a\u001d\u0012\u0013\u0012\u00110\u000f\u00a2\u0006\f\b\u0010\u0012\b\b\u0011\u0012\u0004\b\b(\u0012\u0012\u0004\u0012\u00020\u000b0\u000e2!\u0010\u0013\u001a\u001d\u0012\u0013\u0012\u00110\u0004\u00a2\u0006\f\b\u0010\u0012\b\b\u0011\u0012\u0004\b\b(\u0014\u0012\u0004\u0012\u00020\u000b0\u000eJ\u0010\u0010\u0015\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u0007H\u0007JT\u0010\u0015\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u00072!\u0010\r\u001a\u001d\u0012\u0013\u0012\u00110\u000f\u00a2\u0006\f\b\u0010\u0012\b\b\u0011\u0012\u0004\b\b(\u0012\u0012\u0004\u0012\u00020\u000b0\u000e2!\u0010\u0013\u001a\u001d\u0012\u0013\u0012\u00110\u0004\u00a2\u0006\f\b\u0010\u0012\b\b\u0011\u0012\u0004\b\b(\u0014\u0012\u0004\u0012\u00020\u000b0\u000eJo\u0010\u0016\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u00072\u0006\u0010\u0017\u001a\u00020\u00182\u000e\u0010\u0019\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u001b0\u001a2\u0006\u0010\u001c\u001a\u00020\u000f2\b\b\u0002\u0010\u001d\u001a\u00020\u001e2\u000e\b\u0002\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000b0\u001f2#\b\u0002\u0010\u0013\u001a\u001d\u0012\u0013\u0012\u00110\u0004\u00a2\u0006\f\b\u0010\u0012\b\b\u0011\u0012\u0004\b\b(\u0014\u0012\u0004\u0012\u00020\u000b0\u000eH\u0007Je\u0010\u0016\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\u00072\u0006\u0010\u001d\u001a\u00020\u001e2\u000e\u0010\u0019\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u001b0\u001a2\u0006\u0010\u001c\u001a\u00020\u000f2\u000e\b\u0002\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000b0\u001f2#\b\u0002\u0010\u0013\u001a\u001d\u0012\u0013\u0012\u00110\u0004\u00a2\u0006\f\b\u0010\u0012\b\b\u0011\u0012\u0004\b\b(\u0014\u0012\u0004\u0012\u00020\u000b0\u000eH\u0007R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082T\u00a2\u0006\u0002\n\u0000R\u001a\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\b0\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006 "}, d2={"Lexpo/modules/splashscreen/SplashScreen;", "Lorg/unimodules/core/interfaces/SingletonModule;", "()V", "TAG", "", "controllers", "Ljava/util/WeakHashMap;", "Landroid/app/Activity;", "Lexpo/modules/splashscreen/SplashScreenController;", "getName", "hide", "", "activity", "successCallback", "Lkotlin/Function1;", "", "Lkotlin/ParameterName;", "name", "hasEffect", "failureCallback", "reason", "preventAutoHide", "show", "resizeMode", "Lexpo/modules/splashscreen/SplashScreenImageResizeMode;", "rootViewClass", "Ljava/lang/Class;", "Landroid/view/ViewGroup;", "statusBarTranslucent", "splashScreenViewProvider", "Lexpo/modules/splashscreen/SplashScreenViewProvider;", "Lkotlin/Function0;", "expo-splash-screen_release"}, k=1, mv={1, 1, 16})
public final class SplashScreen
implements SingletonModule {
    public static final SplashScreen INSTANCE = new SplashScreen();
    private static final String TAG = "SplashScreen";
    private static final WeakHashMap<Activity, SplashScreenController> controllers = new WeakHashMap();

    private SplashScreen() {
    }

    @JvmStatic
    public static final void hide(Activity activity) {
        Intrinsics.checkParameterIsNotNull((Object)activity, (String)"activity");
        INSTANCE.hide(activity, hide.1.INSTANCE, hide.2.INSTANCE);
    }

    @JvmStatic
    public static final void preventAutoHide(Activity activity) {
        Intrinsics.checkParameterIsNotNull((Object)activity, (String)"activity");
        INSTANCE.preventAutoHide(activity, preventAutoHide.1.INSTANCE, preventAutoHide.2.INSTANCE);
    }

    @JvmStatic
    public static final void show(Activity activity, SplashScreenImageResizeMode splashScreenImageResizeMode, Class<? extends ViewGroup> class_, boolean bl) {
        SplashScreen.show$default(activity, splashScreenImageResizeMode, class_, bl, null, null, null, 112, null);
    }

    @JvmStatic
    public static final void show(Activity activity, SplashScreenImageResizeMode splashScreenImageResizeMode, Class<? extends ViewGroup> class_, boolean bl, SplashScreenViewProvider splashScreenViewProvider) {
        SplashScreen.show$default(activity, splashScreenImageResizeMode, class_, bl, splashScreenViewProvider, null, null, 96, null);
    }

    @JvmStatic
    public static final void show(Activity activity, SplashScreenImageResizeMode splashScreenImageResizeMode, Class<? extends ViewGroup> class_, boolean bl, SplashScreenViewProvider splashScreenViewProvider, Function0<Unit> function0) {
        SplashScreen.show$default(activity, splashScreenImageResizeMode, class_, bl, splashScreenViewProvider, function0, null, 64, null);
    }

    @JvmStatic
    public static final void show(Activity activity, SplashScreenImageResizeMode splashScreenImageResizeMode, Class<? extends ViewGroup> class_, boolean bl, SplashScreenViewProvider splashScreenViewProvider, Function0<Unit> function0, Function1<? super String, Unit> function1) {
        Intrinsics.checkParameterIsNotNull((Object)activity, (String)"activity");
        Intrinsics.checkParameterIsNotNull((Object)splashScreenImageResizeMode, (String)"resizeMode");
        Intrinsics.checkParameterIsNotNull(class_, (String)"rootViewClass");
        Intrinsics.checkParameterIsNotNull((Object)splashScreenViewProvider, (String)"splashScreenViewProvider");
        Intrinsics.checkParameterIsNotNull(function0, (String)"successCallback");
        Intrinsics.checkParameterIsNotNull(function1, (String)"failureCallback");
        SplashScreen.show(activity, splashScreenViewProvider, class_, bl, function0, function1);
    }

    @JvmStatic
    public static final void show(Activity activity, SplashScreenViewProvider splashScreenViewProvider, Class<? extends ViewGroup> class_, boolean bl) {
        SplashScreen.show$default(activity, splashScreenViewProvider, class_, bl, null, null, 48, null);
    }

    @JvmStatic
    public static final void show(Activity activity, SplashScreenViewProvider splashScreenViewProvider, Class<? extends ViewGroup> class_, boolean bl, Function0<Unit> function0) {
        SplashScreen.show$default(activity, splashScreenViewProvider, class_, bl, function0, null, 32, null);
    }

    @JvmStatic
    public static final void show(Activity activity, SplashScreenViewProvider splashScreenViewProvider, Class<? extends ViewGroup> class_, boolean bl, Function0<Unit> function0, Function1<? super String, Unit> function1) {
        Intrinsics.checkParameterIsNotNull((Object)activity, (String)"activity");
        Intrinsics.checkParameterIsNotNull((Object)splashScreenViewProvider, (String)"splashScreenViewProvider");
        Intrinsics.checkParameterIsNotNull(class_, (String)"rootViewClass");
        Intrinsics.checkParameterIsNotNull(function0, (String)"successCallback");
        Intrinsics.checkParameterIsNotNull(function1, (String)"failureCallback");
        if (controllers.containsKey((Object)activity)) {
            function1.invoke((Object)"'SplashScreen.show' has already been called for this activity.");
            return;
        }
        SplashScreenStatusBar.INSTANCE.configureTranslucent(activity, Boolean.valueOf((boolean)bl));
        SplashScreenController splashScreenController = new SplashScreenController(activity, class_, splashScreenViewProvider);
        ((Map)controllers).put((Object)activity, (Object)splashScreenController);
        splashScreenController.showSplashScreen(function0);
    }

    public static /* synthetic */ void show$default(Activity activity, SplashScreenImageResizeMode splashScreenImageResizeMode, Class class_, boolean bl, SplashScreenViewProvider splashScreenViewProvider, Function0 function0, Function1 function1, int n, Object object) {
        if ((n & 16) != 0) {
            splashScreenViewProvider = new NativeResourcesBasedSplashScreenViewProvider(splashScreenImageResizeMode);
        }
        SplashScreenViewProvider splashScreenViewProvider2 = splashScreenViewProvider;
        if ((n & 32) != 0) {
            function0 = show.3.INSTANCE;
        }
        Function0 function02 = function0;
        if ((n & 64) != 0) {
            function1 = show.4.INSTANCE;
        }
        SplashScreen.show(activity, splashScreenImageResizeMode, (Class<? extends ViewGroup>)class_, bl, splashScreenViewProvider2, (Function0<Unit>)function02, (Function1<? super String, Unit>)function1);
    }

    public static /* synthetic */ void show$default(Activity activity, SplashScreenViewProvider splashScreenViewProvider, Class class_, boolean bl, Function0 function0, Function1 function1, int n, Object object) {
        if ((n & 16) != 0) {
            function0 = show.1.INSTANCE;
        }
        Function0 function02 = function0;
        if ((n & 32) != 0) {
            function1 = show.2.INSTANCE;
        }
        SplashScreen.show(activity, splashScreenViewProvider, (Class<? extends ViewGroup>)class_, bl, (Function0<Unit>)function02, (Function1<? super String, Unit>)function1);
    }

    public String getName() {
        return TAG;
    }

    public final void hide(Activity activity, Function1<? super Boolean, Unit> function1, Function1<? super String, Unit> function12) {
        Intrinsics.checkParameterIsNotNull((Object)activity, (String)"activity");
        Intrinsics.checkParameterIsNotNull(function1, (String)"successCallback");
        Intrinsics.checkParameterIsNotNull(function12, (String)"failureCallback");
        if (!controllers.containsKey((Object)activity)) {
            function12.invoke((Object)"No native splash screen registered for provided activity. Please configure your application's main Activity to call 'SplashScreen.show' (https://github.com/expo/expo/tree/master/packages/expo-splash-screen#-configure-android).");
            return;
        }
        SplashScreenController splashScreenController = (SplashScreenController)controllers.get((Object)activity);
        if (splashScreenController != null) {
            splashScreenController.hideSplashScreen(function1, function12);
        }
    }

    public final void preventAutoHide(Activity activity, Function1<? super Boolean, Unit> function1, Function1<? super String, Unit> function12) {
        Intrinsics.checkParameterIsNotNull((Object)activity, (String)"activity");
        Intrinsics.checkParameterIsNotNull(function1, (String)"successCallback");
        Intrinsics.checkParameterIsNotNull(function12, (String)"failureCallback");
        if (!controllers.containsKey((Object)activity)) {
            function12.invoke((Object)"No native splash screen registered for provided activity. Please configure your application's main Activity to call 'SplashScreen.show' (https://github.com/expo/expo/tree/master/packages/expo-splash-screen#-configure-android).");
            return;
        }
        SplashScreenController splashScreenController = (SplashScreenController)controllers.get((Object)activity);
        if (splashScreenController != null) {
            splashScreenController.preventAutoHide(function1, function12);
        }
    }
}

