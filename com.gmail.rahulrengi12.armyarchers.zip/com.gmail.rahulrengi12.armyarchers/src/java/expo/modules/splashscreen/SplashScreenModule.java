/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  expo.modules.splashscreen.SplashScreenModule$Companion
 *  expo.modules.splashscreen.SplashScreenModule$hideAsync
 *  expo.modules.splashscreen.SplashScreenModule$preventAutoHideAsync
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  kotlin.Metadata
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  org.unimodules.core.ModuleRegistry
 *  org.unimodules.core.Promise
 *  org.unimodules.core.interfaces.ActivityProvider
 *  org.unimodules.core.interfaces.ExpoMethod
 */
package expo.modules.splashscreen;

import android.app.Activity;
import android.content.Context;
import expo.modules.splashscreen.SplashScreen;
import expo.modules.splashscreen.SplashScreenModule;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.unimodules.core.ExportedModule;
import org.unimodules.core.ModuleRegistry;
import org.unimodules.core.Promise;
import org.unimodules.core.errors.CurrentActivityNotFoundException;
import org.unimodules.core.interfaces.ActivityProvider;
import org.unimodules.core.interfaces.ExpoMethod;

/*
 * Exception performing whole class analysis.
 */
@Metadata(bv={1, 0, 3}, d1={"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u0000 \u00112\u00020\u0001:\u0001\u0011B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\b\u0010\u0007\u001a\u00020\bH\u0016J\u0010\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fH\u0007J\u0010\u0010\r\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\u000fH\u0016J\u0010\u0010\u0010\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fH\u0007R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082.\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0012"}, d2={"Lexpo/modules/splashscreen/SplashScreenModule;", "Lorg/unimodules/core/ExportedModule;", "context", "Landroid/content/Context;", "(Landroid/content/Context;)V", "activityProvider", "Lorg/unimodules/core/interfaces/ActivityProvider;", "getName", "", "hideAsync", "", "promise", "Lorg/unimodules/core/Promise;", "onCreate", "moduleRegistry", "Lorg/unimodules/core/ModuleRegistry;", "preventAutoHideAsync", "Companion", "expo-splash-screen_release"}, k=1, mv={1, 1, 16})
public final class SplashScreenModule
extends ExportedModule {
    public static final Companion Companion;
    private static final String ERROR_TAG = "ERR_SPLASH_SCREEN";
    private static final String NAME = "ExpoSplashScreen";
    private ActivityProvider activityProvider;

    static {
        Companion = new /* Unavailable Anonymous Inner Class!! */;
    }

    public SplashScreenModule(Context context) {
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
        super(context);
    }

    @Override
    public String getName() {
        return NAME;
    }

    @ExpoMethod
    public final void hideAsync(Promise promise) {
        Activity activity;
        Intrinsics.checkParameterIsNotNull((Object)promise, (String)"promise");
        ActivityProvider activityProvider = this.activityProvider;
        if (activityProvider == null) {
            Intrinsics.throwUninitializedPropertyAccessException((String)"activityProvider");
        }
        if ((activity = activityProvider.getCurrentActivity()) == null) {
            promise.reject((Throwable)new CurrentActivityNotFoundException());
            return;
        }
        SplashScreen.INSTANCE.hide(activity, (Function1<? super Boolean, Unit>)((Function1)new Function1<Boolean, Unit>(promise){
            final /* synthetic */ Promise $promise;
            {
                this.$promise = promise;
                super(1);
            }

            public final void invoke(boolean bl) {
                this.$promise.resolve((Object)bl);
            }
        }), (Function1<? super String, Unit>)((Function1)new Function1<String, Unit>(promise){
            final /* synthetic */ Promise $promise;
            {
                this.$promise = promise;
                super(1);
            }

            public final void invoke(String string) {
                Intrinsics.checkParameterIsNotNull((Object)string, (String)"m");
                this.$promise.reject("ERR_SPLASH_SCREEN", string);
            }
        }));
    }

    @Override
    public void onCreate(ModuleRegistry moduleRegistry2) {
        Intrinsics.checkParameterIsNotNull((Object)moduleRegistry2, (String)"moduleRegistry");
        Object object = moduleRegistry2.getModule(ActivityProvider.class);
        Intrinsics.checkExpressionValueIsNotNull((Object)object, (String)"moduleRegistry.getModule\u2026vityProvider::class.java)");
        this.activityProvider = (ActivityProvider)object;
    }

    @ExpoMethod
    public final void preventAutoHideAsync(Promise promise) {
        Activity activity;
        Intrinsics.checkParameterIsNotNull((Object)promise, (String)"promise");
        ActivityProvider activityProvider = this.activityProvider;
        if (activityProvider == null) {
            Intrinsics.throwUninitializedPropertyAccessException((String)"activityProvider");
        }
        if ((activity = activityProvider.getCurrentActivity()) == null) {
            promise.reject((Throwable)new CurrentActivityNotFoundException());
            return;
        }
        SplashScreen.INSTANCE.preventAutoHide(activity, (Function1<? super Boolean, Unit>)((Function1)new Function1<Boolean, Unit>(promise){
            final /* synthetic */ Promise $promise;
            {
                this.$promise = promise;
                super(1);
            }

            public final void invoke(boolean bl) {
                this.$promise.resolve((Object)bl);
            }
        }), (Function1<? super String, Unit>)((Function1)new Function1<String, Unit>(promise){
            final /* synthetic */ Promise $promise;
            {
                this.$promise = promise;
                super(1);
            }

            public final void invoke(String string) {
                Intrinsics.checkParameterIsNotNull((Object)string, (String)"m");
                this.$promise.reject("ERR_SPLASH_SCREEN", string);
            }
        }));
    }
}

