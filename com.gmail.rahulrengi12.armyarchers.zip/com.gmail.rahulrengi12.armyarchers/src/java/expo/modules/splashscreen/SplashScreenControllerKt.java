/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.Metadata
 */
package expo.modules.splashscreen;

import kotlin.Metadata;

@Metadata(bv={1, 0, 3}, d1={"\u0000\b\n\u0000\n\u0002\u0010\t\n\u0000\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0086T\u00a2\u0006\u0002\n\u0000\u00a8\u0006\u0002"}, d2={"SEARCH_FOR_ROOT_VIEW_INTERVAL", "", "expo-splash-screen_release"}, k=2, mv={1, 1, 16})
public final class SplashScreenControllerKt {
    public static final long SEARCH_FOR_ROOT_VIEW_INTERVAL = 20L;
}

