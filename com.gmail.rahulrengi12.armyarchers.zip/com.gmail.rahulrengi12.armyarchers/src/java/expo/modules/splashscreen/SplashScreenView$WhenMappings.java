/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  kotlin.Metadata
 */
package expo.modules.splashscreen;

import expo.modules.splashscreen.SplashScreenImageResizeMode;
import kotlin.Metadata;

@Metadata(bv={1, 0, 3}, k=3, mv={1, 1, 16})
public final class SplashScreenView$WhenMappings {
    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

    static /* synthetic */ {
        $EnumSwitchMapping$0 = new int[SplashScreenImageResizeMode.values().length];
        SplashScreenView$WhenMappings.$EnumSwitchMapping$0[SplashScreenImageResizeMode.NATIVE.ordinal()] = 1;
        SplashScreenView$WhenMappings.$EnumSwitchMapping$0[SplashScreenImageResizeMode.CONTAIN.ordinal()] = 2;
        SplashScreenView$WhenMappings.$EnumSwitchMapping$0[SplashScreenImageResizeMode.COVER.ordinal()] = 3;
    }
}

