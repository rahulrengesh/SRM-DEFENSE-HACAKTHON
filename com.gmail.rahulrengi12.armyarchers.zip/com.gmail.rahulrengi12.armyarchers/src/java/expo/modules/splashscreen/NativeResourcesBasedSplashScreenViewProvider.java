/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.view.View
 *  android.widget.ImageView
 *  androidx.core.content.ContextCompat
 *  expo.modules.splashscreen.R
 *  expo.modules.splashscreen.R$color
 *  expo.modules.splashscreen.R$drawable
 *  expo.modules.splashscreen.SplashScreenImageResizeMode
 *  expo.modules.splashscreen.SplashScreenView
 *  expo.modules.splashscreen.SplashScreenViewProvider
 *  java.lang.Object
 *  java.lang.String
 *  kotlin.Metadata
 *  kotlin.jvm.internal.Intrinsics
 */
package expo.modules.splashscreen;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import androidx.core.content.ContextCompat;
import expo.modules.splashscreen.R;
import expo.modules.splashscreen.SplashScreenImageResizeMode;
import expo.modules.splashscreen.SplashScreenView;
import expo.modules.splashscreen.SplashScreenViewProvider;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

@Metadata(bv={1, 0, 3}, d1={"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00a2\u0006\u0002\u0010\u0004J\u0010\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH\u0016J\u0010\u0010\t\u001a\u00020\n2\u0006\u0010\u0007\u001a\u00020\bH\u0002J\b\u0010\u000b\u001a\u00020\nH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006\f"}, d2={"Lexpo/modules/splashscreen/NativeResourcesBasedSplashScreenViewProvider;", "Lexpo/modules/splashscreen/SplashScreenViewProvider;", "resizeMode", "Lexpo/modules/splashscreen/SplashScreenImageResizeMode;", "(Lexpo/modules/splashscreen/SplashScreenImageResizeMode;)V", "createSplashScreenView", "Lexpo/modules/splashscreen/SplashScreenView;", "context", "Landroid/content/Context;", "getBackgroundColor", "", "getImageResource", "expo-splash-screen_release"}, k=1, mv={1, 1, 16})
public final class NativeResourcesBasedSplashScreenViewProvider
implements SplashScreenViewProvider {
    private final SplashScreenImageResizeMode resizeMode;

    public NativeResourcesBasedSplashScreenViewProvider(SplashScreenImageResizeMode splashScreenImageResizeMode) {
        Intrinsics.checkParameterIsNotNull((Object)splashScreenImageResizeMode, (String)"resizeMode");
        this.resizeMode = splashScreenImageResizeMode;
    }

    private final int getBackgroundColor(Context context) {
        return ContextCompat.getColor((Context)context, (int)R.color.splashscreen_background);
    }

    private final int getImageResource() {
        if (this.resizeMode == SplashScreenImageResizeMode.NATIVE) {
            return R.drawable.splashscreen;
        }
        return R.drawable.splashscreen_image;
    }

    public SplashScreenView createSplashScreenView(Context context) {
        Intrinsics.checkParameterIsNotNull((Object)context, (String)"context");
        SplashScreenView splashScreenView = new SplashScreenView(context);
        splashScreenView.setBackgroundColor(this.getBackgroundColor(context));
        splashScreenView.getImageView().setImageResource(this.getImageResource());
        splashScreenView.configureImageViewResizeMode(this.resizeMode);
        return splashScreenView;
    }
}

