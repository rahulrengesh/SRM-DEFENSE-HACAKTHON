/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 */
package expo.modules.splashscreen;

public final class BuildConfig {
    @Deprecated
    public static final String APPLICATION_ID = "expo.modules.splashscreen";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final String LIBRARY_PACKAGE_NAME = "expo.modules.splashscreen";
    public static final int VERSION_CODE = 13;
    public static final String VERSION_NAME = "0.6.1";
}

