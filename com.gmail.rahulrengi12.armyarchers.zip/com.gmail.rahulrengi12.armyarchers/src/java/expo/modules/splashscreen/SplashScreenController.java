/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.os.Handler
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$OnHierarchyChangeListener
 *  dalvik.annotation.SourceDebugExtension
 *  expo.modules.splashscreen.SplashScreenController$handleRootView
 *  expo.modules.splashscreen.SplashScreenController$hideSplashScreen
 *  expo.modules.splashscreen.SplashScreenController$searchForRootView
 *  expo.modules.splashscreen.SplashScreenController$showSplashScreen
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.ref.WeakReference
 *  kotlin.Metadata
 *  kotlin.TypeCastException
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 */
package expo.modules.splashscreen;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.view.ViewGroup;
import dalvik.annotation.SourceDebugExtension;
import expo.modules.splashscreen.SplashScreenController;
import expo.modules.splashscreen.SplashScreenViewProvider;
import expo.modules.splashscreen.exceptions.NoContentViewException;
import java.lang.ref.WeakReference;
import kotlin.Metadata;
import kotlin.TypeCastException;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@SourceDebugExtension(value="SMAP\nSplashScreenController.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SplashScreenController.kt\nexpo/modules/splashscreen/SplashScreenController\n*L\n1#1,127:1\n*E\n")
@Metadata(bv={1, 0, 3}, d1={"\u0000b\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u000e\u0010\u0004\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00060\u0005\u0012\u0006\u0010\u0007\u001a\u00020\b\u00a2\u0006\u0002\u0010\tJ\u0012\u0010\u0016\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0017\u001a\u00020\u0012H\u0002J\u0010\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u0017\u001a\u00020\u0006H\u0002JP\u0010\u001a\u001a\u00020\u00192#\b\u0002\u0010\u001b\u001a\u001d\u0012\u0013\u0012\u00110\u000b\u00a2\u0006\f\b\u001d\u0012\b\b\u001e\u0012\u0004\b\b(\u001f\u0012\u0004\u0012\u00020\u00190\u001c2#\b\u0002\u0010 \u001a\u001d\u0012\u0013\u0012\u00110!\u00a2\u0006\f\b\u001d\u0012\b\b\u001e\u0012\u0004\b\b(\"\u0012\u0004\u0012\u00020\u00190\u001cJL\u0010#\u001a\u00020\u00192!\u0010\u001b\u001a\u001d\u0012\u0013\u0012\u00110\u000b\u00a2\u0006\f\b\u001d\u0012\b\b\u001e\u0012\u0004\b\b(\u001f\u0012\u0004\u0012\u00020\u00190\u001c2!\u0010 \u001a\u001d\u0012\u0013\u0012\u00110!\u00a2\u0006\f\b\u001d\u0012\b\b\u001e\u0012\u0004\b\b(\"\u0012\u0004\u0012\u00020\u00190\u001cJ\b\u0010$\u001a\u00020\u0019H\u0002J\u0016\u0010%\u001a\u00020\u00192\u000e\b\u0002\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u00190&R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0006X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u000eX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0006X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0016\u0010\u0004\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00060\u0005X\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u000bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\u0012X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u001c\u0010\u0013\u001a\u0010\u0012\f\u0012\n \u0015*\u0004\u0018\u00010\u00030\u00030\u0014X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006'"}, d2={"Lexpo/modules/splashscreen/SplashScreenController;", "", "activity", "Landroid/app/Activity;", "rootViewClass", "Ljava/lang/Class;", "Landroid/view/ViewGroup;", "splashScreenViewProvider", "Lexpo/modules/splashscreen/SplashScreenViewProvider;", "(Landroid/app/Activity;Ljava/lang/Class;Lexpo/modules/splashscreen/SplashScreenViewProvider;)V", "autoHideEnabled", "", "contentView", "handler", "Landroid/os/Handler;", "rootView", "splashScreenShown", "splashScreenView", "Landroid/view/View;", "weakActivity", "Ljava/lang/ref/WeakReference;", "kotlin.jvm.PlatformType", "findRootView", "view", "handleRootView", "", "hideSplashScreen", "successCallback", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "hasEffect", "failureCallback", "", "reason", "preventAutoHide", "searchForRootView", "showSplashScreen", "Lkotlin/Function0;", "expo-splash-screen_release"}, k=1, mv={1, 1, 16})
public final class SplashScreenController {
    private boolean autoHideEnabled;
    private final ViewGroup contentView;
    private final Handler handler;
    private ViewGroup rootView;
    private final Class<? extends ViewGroup> rootViewClass;
    private boolean splashScreenShown;
    private View splashScreenView;
    private final WeakReference<Activity> weakActivity;

    public SplashScreenController(Activity activity, Class<? extends ViewGroup> class_, SplashScreenViewProvider splashScreenViewProvider) {
        Intrinsics.checkParameterIsNotNull((Object)activity, (String)"activity");
        Intrinsics.checkParameterIsNotNull(class_, (String)"rootViewClass");
        Intrinsics.checkParameterIsNotNull((Object)splashScreenViewProvider, (String)"splashScreenViewProvider");
        this.rootViewClass = class_;
        this.weakActivity = new WeakReference((Object)activity);
        ViewGroup viewGroup = (ViewGroup)activity.findViewById(16908290);
        if (viewGroup != null) {
            this.contentView = viewGroup;
            this.splashScreenView = splashScreenViewProvider.createSplashScreenView((Context)activity);
            this.handler = new Handler();
            this.autoHideEnabled = true;
            return;
        }
        throw (Throwable)new NoContentViewException();
    }

    public static final /* synthetic */ boolean access$getAutoHideEnabled$p(SplashScreenController splashScreenController) {
        return splashScreenController.autoHideEnabled;
    }

    public static final /* synthetic */ ViewGroup access$getContentView$p(SplashScreenController splashScreenController) {
        return splashScreenController.contentView;
    }

    public static final /* synthetic */ ViewGroup access$getRootView$p(SplashScreenController splashScreenController) {
        return splashScreenController.rootView;
    }

    public static final /* synthetic */ boolean access$getSplashScreenShown$p(SplashScreenController splashScreenController) {
        return splashScreenController.splashScreenShown;
    }

    public static final /* synthetic */ View access$getSplashScreenView$p(SplashScreenController splashScreenController) {
        return splashScreenController.splashScreenView;
    }

    public static final /* synthetic */ void access$searchForRootView(SplashScreenController splashScreenController) {
        splashScreenController.searchForRootView();
    }

    public static final /* synthetic */ void access$setAutoHideEnabled$p(SplashScreenController splashScreenController, boolean bl) {
        splashScreenController.autoHideEnabled = bl;
    }

    public static final /* synthetic */ void access$setRootView$p(SplashScreenController splashScreenController, ViewGroup viewGroup) {
        splashScreenController.rootView = viewGroup;
    }

    public static final /* synthetic */ void access$setSplashScreenShown$p(SplashScreenController splashScreenController, boolean bl) {
        splashScreenController.splashScreenShown = bl;
    }

    public static final /* synthetic */ void access$setSplashScreenView$p(SplashScreenController splashScreenController, View view) {
        splashScreenController.splashScreenView = view;
    }

    private final ViewGroup findRootView(View view) {
        if (this.rootViewClass.isInstance((Object)view)) {
            if (view != null) {
                return (ViewGroup)view;
            }
            throw new TypeCastException("null cannot be cast to non-null type android.view.ViewGroup");
        }
        if (true ^ Intrinsics.areEqual((Object)view, (Object)this.splashScreenView) && view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup)view;
            int n = viewGroup.getChildCount();
            for (int i = 0; i < n; ++i) {
                View view2 = viewGroup.getChildAt(i);
                Intrinsics.checkExpressionValueIsNotNull((Object)view2, (String)"view.getChildAt(idx)");
                ViewGroup viewGroup2 = this.findRootView(view2);
                if (viewGroup2 == null) continue;
                return viewGroup2;
            }
        }
        return null;
    }

    private final void handleRootView(ViewGroup viewGroup) {
        this.rootView = viewGroup;
        ViewGroup viewGroup2 = this.rootView;
        int n = viewGroup2 != null ? viewGroup2.getChildCount() : 0;
        if (n > 0 && this.autoHideEnabled) {
            SplashScreenController.hideSplashScreen$default(this, null, null, 3, null);
        }
        viewGroup.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener(this){
            final /* synthetic */ SplashScreenController this$0;
            {
                this.this$0 = splashScreenController;
            }

            public void onChildViewAdded(View view, View view2) {
                Intrinsics.checkParameterIsNotNull((Object)view, (String)"parent");
                Intrinsics.checkParameterIsNotNull((Object)view2, (String)"child");
                ViewGroup viewGroup = SplashScreenController.access$getRootView$p(this.this$0);
                if (viewGroup != null && viewGroup.getChildCount() == 1 && SplashScreenController.access$getAutoHideEnabled$p(this.this$0)) {
                    SplashScreenController.hideSplashScreen$default(this.this$0, null, null, 3, null);
                }
            }

            public void onChildViewRemoved(View view, View view2) {
                Intrinsics.checkParameterIsNotNull((Object)view, (String)"parent");
                Intrinsics.checkParameterIsNotNull((Object)view2, (String)"child");
                ViewGroup viewGroup = SplashScreenController.access$getRootView$p(this.this$0);
                if (viewGroup != null && viewGroup.getChildCount() == 0) {
                    SplashScreenController.showSplashScreen$default(this.this$0, null, 1, null);
                }
            }
        });
    }

    public static /* synthetic */ void hideSplashScreen$default(SplashScreenController splashScreenController, Function1 function1, Function1 function12, int n, Object object) {
        if ((n & 1) != 0) {
            function1 = hideSplashScreen.1.INSTANCE;
        }
        if ((n & 2) != 0) {
            function12 = hideSplashScreen.2.INSTANCE;
        }
        splashScreenController.hideSplashScreen((Function1<? super Boolean, Unit>)function1, (Function1<? super String, Unit>)function12);
    }

    private final void searchForRootView() {
        if (this.rootView != null) {
            return;
        }
        ViewGroup viewGroup = this.findRootView((View)this.contentView);
        if (viewGroup != null) {
            this.handleRootView(viewGroup);
            return;
        }
        this.handler.postDelayed(new Runnable(this){
            final /* synthetic */ SplashScreenController this$0;
            {
                this.this$0 = splashScreenController;
            }

            public final void run() {
                SplashScreenController.access$searchForRootView(this.this$0);
            }
        }, 20L);
    }

    public static /* synthetic */ void showSplashScreen$default(SplashScreenController splashScreenController, Function0 function0, int n, Object object) {
        if ((n & 1) != 0) {
            function0 = showSplashScreen.1.INSTANCE;
        }
        splashScreenController.showSplashScreen((Function0<Unit>)function0);
    }

    public final void hideSplashScreen(Function1<? super Boolean, Unit> function1, Function1<? super String, Unit> function12) {
        Intrinsics.checkParameterIsNotNull(function1, (String)"successCallback");
        Intrinsics.checkParameterIsNotNull(function12, (String)"failureCallback");
        if (!this.splashScreenShown) {
            function1.invoke((Object)false);
            return;
        }
        Activity activity = (Activity)this.weakActivity.get();
        if (activity != null && !activity.isFinishing() && !activity.isDestroyed()) {
            activity.runOnUiThread(new Runnable(this, function1){
                final /* synthetic */ Function1 $successCallback;
                final /* synthetic */ SplashScreenController this$0;
                {
                    this.this$0 = splashScreenController;
                    this.$successCallback = function1;
                }

                public final void run() {
                    SplashScreenController.access$getContentView$p(this.this$0).removeView(SplashScreenController.access$getSplashScreenView$p(this.this$0));
                    SplashScreenController.access$setAutoHideEnabled$p(this.this$0, true);
                    SplashScreenController.access$setSplashScreenShown$p(this.this$0, false);
                    this.$successCallback.invoke((Object)true);
                }
            });
            return;
        }
        function12.invoke((Object)"Cannot hide native splash screen on activity that is already destroyed (application is already closed).");
    }

    public final void preventAutoHide(Function1<? super Boolean, Unit> function1, Function1<? super String, Unit> function12) {
        Intrinsics.checkParameterIsNotNull(function1, (String)"successCallback");
        Intrinsics.checkParameterIsNotNull(function12, (String)"failureCallback");
        if (this.autoHideEnabled && this.splashScreenShown) {
            this.autoHideEnabled = false;
            function1.invoke((Object)true);
            return;
        }
        function1.invoke((Object)false);
    }

    public final void showSplashScreen(Function0<Unit> function0) {
        Intrinsics.checkParameterIsNotNull(function0, (String)"successCallback");
        Activity activity = (Activity)this.weakActivity.get();
        if (activity != null) {
            activity.runOnUiThread(new Runnable(this, function0){
                final /* synthetic */ Function0 $successCallback;
                final /* synthetic */ SplashScreenController this$0;
                {
                    this.this$0 = splashScreenController;
                    this.$successCallback = function0;
                }

                public final void run() {
                    ViewGroup viewGroup;
                    android.view.ViewParent viewParent = SplashScreenController.access$getSplashScreenView$p(this.this$0).getParent();
                    if (!(viewParent instanceof ViewGroup)) {
                        viewParent = null;
                    }
                    if ((viewGroup = (ViewGroup)viewParent) != null) {
                        viewGroup.removeView(SplashScreenController.access$getSplashScreenView$p(this.this$0));
                    }
                    SplashScreenController.access$getContentView$p(this.this$0).addView(SplashScreenController.access$getSplashScreenView$p(this.this$0));
                    SplashScreenController.access$setSplashScreenShown$p(this.this$0, true);
                    this.$successCallback.invoke();
                    SplashScreenController.access$searchForRootView(this.this$0);
                }
            });
        }
    }
}

