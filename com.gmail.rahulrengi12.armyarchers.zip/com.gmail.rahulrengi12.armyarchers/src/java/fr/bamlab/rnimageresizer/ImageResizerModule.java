/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.net.Uri
 *  android.os.AsyncTask
 *  android.util.Log
 *  com.facebook.react.bridge.Arguments
 *  com.facebook.react.bridge.Callback
 *  com.facebook.react.bridge.GuardedAsyncTask
 *  com.facebook.react.bridge.ReactApplicationContext
 *  com.facebook.react.bridge.ReactContext
 *  com.facebook.react.bridge.ReactContextBaseJavaModule
 *  com.facebook.react.bridge.ReactMethod
 *  com.facebook.react.bridge.WritableMap
 *  fr.bamlab.rnimageresizer.ImageResizer
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.util.Date
 *  java.util.concurrent.Executor
 */
package fr.bamlab.rnimageresizer;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.GuardedAsyncTask;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import fr.bamlab.rnimageresizer.ImageResizer;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.Executor;

public class ImageResizerModule
extends ReactContextBaseJavaModule {
    private Context context;

    public ImageResizerModule(ReactApplicationContext reactApplicationContext) {
        super(reactApplicationContext);
        this.context = reactApplicationContext;
    }

    private void createResizedImageWithExceptions(String string, int n, int n2, String string2, int n3, int n4, String string3, boolean bl, Callback callback, Callback callback2) throws IOException {
        Bitmap.CompressFormat compressFormat = Bitmap.CompressFormat.valueOf((String)string2);
        Uri uri = Uri.parse((String)string);
        Bitmap bitmap = ImageResizer.createResizedImage((Context)this.context, (Uri)uri, (int)n, (int)n2, (int)n3, (int)n4);
        if (bitmap != null) {
            File file;
            File file2 = this.context.getCacheDir();
            if (string3 != null) {
                file2 = new File(string3);
            }
            if ((file = ImageResizer.saveImage((Bitmap)bitmap, (File)file2, (String)Long.toString((long)new Date().getTime()), (Bitmap.CompressFormat)compressFormat, (int)n3)).isFile()) {
                WritableMap writableMap = Arguments.createMap();
                writableMap.putString("path", file.getAbsolutePath());
                writableMap.putString("uri", Uri.fromFile((File)file).toString());
                writableMap.putString("name", file.getName());
                writableMap.putDouble("size", (double)file.length());
                writableMap.putDouble("width", (double)bitmap.getWidth());
                writableMap.putDouble("height", (double)bitmap.getHeight());
                if (bl) {
                    try {
                        ImageResizer.copyExif((Context)this.context, (Uri)uri, (String)file.getAbsolutePath());
                    }
                    catch (Exception exception) {
                        Log.e((String)"ImageResizer::createResizedImageWithExceptions", (String)"EXIF copy failed", (Throwable)exception);
                    }
                }
                callback.invoke(new Object[]{writableMap});
            } else {
                callback2.invoke(new Object[]{"Error getting resized image path"});
            }
            bitmap.recycle();
            return;
        }
        throw new IOException("The image failed to be resized; invalid Bitmap result.");
    }

    @ReactMethod
    public void createResizedImage(final String string, final int n, final int n2, final String string2, final int n3, final int n4, final String string3, final boolean bl, final Callback callback, final Callback callback2) {
        GuardedAsyncTask<Void, Void> guardedAsyncTask = new GuardedAsyncTask<Void, Void>((ReactContext)this.getReactApplicationContext()){

            protected /* varargs */ void doInBackgroundGuarded(Void ... arrvoid) {
                try {
                    ImageResizerModule.this.createResizedImageWithExceptions(string, n, n2, string2, n3, n4, string3, bl, callback, callback2);
                    return;
                }
                catch (IOException iOException) {
                    Callback callback3 = callback2;
                    Object[] arrobject = new Object[]{iOException.getMessage()};
                    callback3.invoke(arrobject);
                    return;
                }
            }
        };
        guardedAsyncTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new Void[0]);
    }

    public String getName() {
        return "ImageResizerAndroid";
    }

}

