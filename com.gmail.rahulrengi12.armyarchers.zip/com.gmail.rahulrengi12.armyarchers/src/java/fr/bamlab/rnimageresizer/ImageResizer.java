/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$CompressFormat
 *  android.graphics.BitmapFactory
 *  android.graphics.BitmapFactory$Options
 *  android.graphics.Matrix
 *  android.net.Uri
 *  android.util.Base64
 *  android.util.Log
 *  androidx.exifinterface.media.ExifInterface
 *  java.io.ByteArrayOutputStream
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.OutOfMemoryError
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.net.HttpURLConnection
 *  java.net.URL
 *  java.net.URLConnection
 */
package fr.bamlab.rnimageresizer;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.util.Base64;
import android.util.Log;
import androidx.exifinterface.media.ExifInterface;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class ImageResizer {
    private static final String[] EXIF_TO_COPY_ROTATED = new String[]{"ApertureValue", "MaxApertureValue", "MeteringMode", "Artist", "BitsPerSample", "Compression", "BodySerialNumber", "BrightnessValue", "Contrast", "CameraOwnerName", "ColorSpace", "Copyright", "DateTime", "DateTimeDigitized", "DateTimeOriginal", "DeviceSettingDescription", "DigitalZoomRatio", "ExifVersion", "ExposureBiasValue", "ExposureIndex", "ExposureMode", "ExposureTime", "ExposureProgram", "Flash", "FlashEnergy", "FocalLength", "FocalLengthIn35mmFilm", "FocalPlaneResolutionUnit", "FocalPlaneXResolution", "FocalPlaneYResolution", "PhotometricInterpretation", "PlanarConfiguration", "FNumber", "GainControl", "Gamma", "GPSAltitude", "GPSAltitudeRef", "GPSAreaInformation", "GPSDateStamp", "GPSDOP", "GPSLatitude", "GPSLatitudeRef", "GPSLongitude", "GPSLongitudeRef", "GPSStatus", "GPSDestBearing", "GPSDestBearingRef", "GPSDestDistance", "GPSDestDistanceRef", "GPSDestLatitude", "GPSDestLatitudeRef", "GPSDestLongitude", "GPSDestLongitudeRef", "GPSDifferential", "GPSImgDirection", "GPSImgDirectionRef", "GPSMapDatum", "GPSMeasureMode", "GPSProcessingMethod", "GPSSatellites", "GPSSpeed", "GPSSpeedRef", "GPSStatus", "GPSTimeStamp", "GPSTrack", "GPSTrackRef", "GPSVersionID", "ImageDescription", "ImageUniqueID", "ISOSpeed", "PhotographicSensitivity", "JPEGInterchangeFormat", "JPEGInterchangeFormatLength", "LensMake", "LensModel", "LensSerialNumber", "LensSpecification", "LightSource", "Make", "MakerNote", "Model", "Saturation", "Sharpness", "ShutterSpeedValue", "Software", "SubjectDistance", "SubjectDistanceRange", "SubjectLocation", "UserComment", "WhiteBalance"};
    private static final String IMAGE_JPEG = "image/jpeg";
    private static final String IMAGE_PNG = "image/png";
    private static final String SCHEME_CONTENT = "content";
    private static final String SCHEME_DATA = "data";
    private static final String SCHEME_FILE = "file";
    private static final String SCHEME_HTTP = "http";
    private static final String SCHEME_HTTPS = "https";

    private static int calculateInSampleSize(BitmapFactory.Options options, int n, int n2) {
        int n3 = options.outHeight;
        int n4 = options.outWidth;
        int n5 = 1;
        if (n3 > n2 || n4 > n) {
            int n6 = n3 / 2;
            int n7 = n4 / 2;
            while (n6 / n5 >= n2 && n7 / n5 >= n) {
                n5 *= 2;
            }
        }
        return n5;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean copyExif(Context context, Uri uri, String string2) {
        int n2;
        ExifInterface exifInterface2;
        String[] arrstring;
        ExifInterface exifInterface;
        int n;
        block13 : {
            block11 : {
                void var3_8;
                block12 : {
                    File file = ImageResizer.getFileFromUri(context, uri);
                    if (!file.exists()) {
                        return false;
                    }
                    exifInterface = new ExifInterface(file.getAbsolutePath());
                    try {
                        exifInterface2 = new ExifInterface(string2);
                        break block11;
                    }
                    catch (Exception exception) {
                        break block12;
                    }
                    catch (Exception exception) {
                        exifInterface = null;
                    }
                }
                Log.e((String)"ImageResizer::copyExif", (String)"EXIF read failed", (Throwable)var3_8);
                exifInterface2 = null;
            }
            if (exifInterface == null) return false;
            if (exifInterface2 == null) {
                return false;
            }
            try {
                arrstring = EXIF_TO_COPY_ROTATED;
                n2 = arrstring.length;
                n = 0;
                break block13;
            }
            catch (Exception exception) {
                Log.e((String)"ImageResizer::copyExif", (String)"EXIF copy failed", (Throwable)exception);
            }
            return false;
        }
        do {
            if (n >= n2) {
                exifInterface2.saveAttributes();
                return true;
            }
            String string3 = arrstring[n];
            String string4 = exifInterface.getAttribute(string3);
            if (string4 != null) {
                exifInterface2.setAttribute(string3, string4);
            }
            ++n;
        } while (true);
    }

    public static Bitmap createResizedImage(Context context, Uri uri, int n, int n2, int n3, int n4) throws IOException {
        String string2 = uri.getScheme();
        Object object = string2 != null && !string2.equalsIgnoreCase(SCHEME_FILE) && !string2.equalsIgnoreCase(SCHEME_CONTENT) ? (!string2.equalsIgnoreCase(SCHEME_HTTP) && !string2.equalsIgnoreCase(SCHEME_HTTPS) ? (string2.equalsIgnoreCase(SCHEME_DATA) ? ImageResizer.loadBitmapFromBase64(uri) : null) : ImageResizer.loadBitmapFromURL(uri, n, n2)) : ImageResizer.loadBitmapFromFile(context, uri, n, n2);
        if (object != null) {
            Bitmap bitmap = ImageResizer.rotateImage(object, n4 + ImageResizer.getOrientation(context, uri));
            if (bitmap != null) {
                Bitmap bitmap2;
                if (bitmap != bitmap) {
                    object.recycle();
                }
                if ((bitmap2 = ImageResizer.resizeImage(bitmap, n, n2)) != null) {
                    if (bitmap2 != bitmap) {
                        bitmap.recycle();
                    }
                    return bitmap2;
                }
                throw new IOException("Unable to resize image. Most likely due to not enough memory.");
            }
            throw new IOException("Unable to rotate image. Most likely due to not enough memory.");
        }
        throw new IOException("Unable to load source image from path");
    }

    /*
     * Exception decompiling
     */
    private static File getFileFromUri(Context var0, Uri var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl65 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static int getOrientation(Context var0, Uri var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl17.1 : ICONST_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    public static int getOrientation(ExifInterface exifInterface) {
        int n = exifInterface.getAttributeInt("Orientation", 1);
        if (n != 3) {
            if (n != 6) {
                if (n != 8) {
                    return 0;
                }
                return 270;
            }
            return 90;
        }
        return 180;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static Bitmap loadBitmap(Context context, Uri uri, BitmapFactory.Options options) throws IOException {
        String string2 = uri.getScheme();
        if (string2 != null && string2.equalsIgnoreCase(SCHEME_CONTENT)) {
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            Bitmap bitmap = null;
            if (inputStream == null) return bitmap;
            Bitmap bitmap2 = BitmapFactory.decodeStream((InputStream)inputStream, null, (BitmapFactory.Options)options);
            inputStream.close();
            return bitmap2;
        }
        try {
            return BitmapFactory.decodeFile((String)uri.getPath(), (BitmapFactory.Options)options);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            throw new IOException("Error decoding image file");
        }
    }

    private static Bitmap loadBitmapFromBase64(Uri uri) {
        String string2 = uri.getSchemeSpecificPart();
        int n = string2.indexOf(44);
        if (n != -1) {
            String string3 = string2.substring(0, n).replace('\\', '/').toLowerCase();
            boolean bl = string3.startsWith(IMAGE_JPEG);
            boolean bl2 = !bl && string3.startsWith(IMAGE_PNG);
            if (bl || bl2) {
                byte[] arrby = Base64.decode((String)string2.substring(n + 1), (int)0);
                return BitmapFactory.decodeByteArray((byte[])arrby, (int)0, (int)arrby.length);
            }
        }
        return null;
    }

    private static Bitmap loadBitmapFromFile(Context context, Uri uri, int n, int n2) throws IOException {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        ImageResizer.loadBitmap(context, uri, options);
        options.inSampleSize = ImageResizer.calculateInSampleSize(options, n, n2);
        options.inJustDecodeBounds = false;
        return ImageResizer.loadBitmap(context, uri, options);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static Bitmap loadBitmapFromURL(Uri var0, int var1_1, int var2_2) throws IOException {
        block16 : {
            block15 : {
                var3_3 = null;
                var8_4 = (HttpURLConnection)new URL(var0.toString()).openConnection();
                var8_4.connect();
                var6_5 = var8_4.getInputStream();
                var9_6 = null;
                if (var6_5 == null) break block15;
                var11_7 = new ByteArrayOutputStream();
                var12_8 = new byte[1024];
                while ((var14_9 = var6_5.read(var12_8, 0, var12_8.length)) != -1) {
                    var11_7.write(var12_8, 0, var14_9);
                }
                var11_7.flush();
                var15_10 = var11_7.toByteArray();
                {
                    catch (Throwable var13_12) {
                        var11_7.close();
                        throw var13_12;
                    }
                }
                try {
                    var11_7.close();
                    var16_11 = new BitmapFactory.Options();
                    var16_11.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray((byte[])var15_10, (int)0, (int)var15_10.length, (BitmapFactory.Options)var16_11);
                    var16_11.inSampleSize = ImageResizer.calculateInSampleSize(var16_11, var1_1, var2_2);
                    var16_11.inJustDecodeBounds = false;
                    var9_6 = BitmapFactory.decodeByteArray((byte[])var15_10, (int)0, (int)var15_10.length, (BitmapFactory.Options)var16_11);
                }
                catch (Throwable var5_13) {
                    break block16;
                }
                catch (Exception var4_16) {
                    var3_3 = var6_5;
                    ** GOTO lbl-1000
                }
            }
            if (var6_5 == null) return var9_6;
            try {
                var6_5.close();
                return var9_6;
            }
            catch (IOException var10_19) {
                var10_19.printStackTrace();
            }
            return var9_6;
            catch (Throwable var5_14) {
                var6_5 = var3_3;
                break block16;
            }
            catch (Exception var4_17) {
                // empty catch block
            }
lbl-1000: // 2 sources:
            {
                var4_18.printStackTrace();
                throw new IOException("Error fetching remote image file.");
            }
        }
        if (var6_5 == null) throw var5_15;
        try {
            var6_5.close();
            throw var5_15;
        }
        catch (IOException var7_20) {
            var7_20.printStackTrace();
        }
        throw var5_15;
    }

    /*
     * Exception decompiling
     */
    private static Bitmap resizeImage(Bitmap var0, int var1, int var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    public static Bitmap rotateImage(Bitmap bitmap, float f) {
        Matrix matrix = new Matrix();
        matrix.postRotate(f);
        try {
            Bitmap bitmap2 = Bitmap.createBitmap((Bitmap)bitmap, (int)0, (int)0, (int)bitmap.getWidth(), (int)bitmap.getHeight(), (Matrix)matrix, (boolean)true);
            return bitmap2;
        }
        catch (OutOfMemoryError outOfMemoryError) {
            return null;
        }
    }

    public static File saveImage(Bitmap bitmap, File file, String string2, Bitmap.CompressFormat compressFormat, int n) throws IOException {
        if (bitmap != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append(".");
            stringBuilder.append(compressFormat.name());
            File file2 = new File(file, stringBuilder.toString());
            if (file2.createNewFile()) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmap.compress(compressFormat, n, (OutputStream)byteArrayOutputStream);
                byte[] arrby = byteArrayOutputStream.toByteArray();
                byteArrayOutputStream.flush();
                byteArrayOutputStream.close();
                FileOutputStream fileOutputStream = new FileOutputStream(file2);
                fileOutputStream.write(arrby);
                fileOutputStream.flush();
                fileOutputStream.close();
                return file2;
            }
            throw new IOException("The file already exists");
        }
        throw new IOException("The bitmap couldn't be resized");
    }
}

