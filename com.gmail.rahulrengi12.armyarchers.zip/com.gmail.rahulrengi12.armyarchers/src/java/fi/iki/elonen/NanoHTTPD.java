/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.BufferedInputStream
 *  java.io.BufferedReader
 *  java.io.BufferedWriter
 *  java.io.ByteArrayInputStream
 *  java.io.ByteArrayOutputStream
 *  java.io.Closeable
 *  java.io.DataOutputStream
 *  java.io.File
 *  java.io.FileOutputStream
 *  java.io.FilterOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.PrintWriter
 *  java.io.RandomAccessFile
 *  java.io.Reader
 *  java.io.UnsupportedEncodingException
 *  java.io.Writer
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.Enum
 *  java.lang.Error
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Iterable
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.net.InetAddress
 *  java.net.InetSocketAddress
 *  java.net.ServerSocket
 *  java.net.Socket
 *  java.net.SocketAddress
 *  java.net.SocketException
 *  java.net.SocketTimeoutException
 *  java.net.URLDecoder
 *  java.nio.Buffer
 *  java.nio.ByteBuffer
 *  java.nio.MappedByteBuffer
 *  java.nio.channels.FileChannel
 *  java.nio.channels.FileChannel$MapMode
 *  java.nio.charset.Charset
 *  java.nio.charset.CharsetEncoder
 *  java.security.KeyStore
 *  java.security.SecureRandom
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Calendar
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.StringTokenizer
 *  java.util.TimeZone
 *  java.util.logging.Level
 *  java.util.logging.Logger
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  java.util.zip.GZIPOutputStream
 *  javax.net.ssl.KeyManager
 *  javax.net.ssl.KeyManagerFactory
 *  javax.net.ssl.SSLContext
 *  javax.net.ssl.SSLServerSocket
 *  javax.net.ssl.SSLServerSocketFactory
 *  javax.net.ssl.TrustManager
 *  javax.net.ssl.TrustManagerFactory
 */
package fi.iki.elonen;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URLDecoder;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPOutputStream;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

public abstract class NanoHTTPD {
    private static final Pattern CONTENT_DISPOSITION_ATTRIBUTE_PATTERN;
    private static final String CONTENT_DISPOSITION_ATTRIBUTE_REGEX = "[ |\t]*([a-zA-Z]*)[ |\t]*=[ |\t]*['|\"]([^\"^']*)['|\"]";
    private static final Pattern CONTENT_DISPOSITION_PATTERN;
    private static final String CONTENT_DISPOSITION_REGEX = "([ |\t]*Content-Disposition[ |\t]*:)(.*)";
    private static final Pattern CONTENT_TYPE_PATTERN;
    private static final String CONTENT_TYPE_REGEX = "([ |\t]*content-type[ |\t]*:)(.*)";
    private static final Logger LOG;
    public static final String MIME_HTML = "text/html";
    public static final String MIME_PLAINTEXT = "text/plain";
    protected static Map<String, String> MIME_TYPES;
    private static final String QUERY_STRING_PARAMETER = "NanoHttpd.QUERY_STRING";
    public static final int SOCKET_READ_TIMEOUT = 5000;
    protected AsyncRunner asyncRunner;
    private final String hostname;
    private final int myPort;
    private volatile ServerSocket myServerSocket;
    private Thread myThread;
    private ServerSocketFactory serverSocketFactory = new ServerSocketFactory(){

        @Override
        public ServerSocket create() throws IOException {
            return new ServerSocket();
        }
    };
    private TempFileManagerFactory tempFileManagerFactory;

    static {
        CONTENT_DISPOSITION_PATTERN = Pattern.compile((String)CONTENT_DISPOSITION_REGEX, (int)2);
        CONTENT_TYPE_PATTERN = Pattern.compile((String)CONTENT_TYPE_REGEX, (int)2);
        CONTENT_DISPOSITION_ATTRIBUTE_PATTERN = Pattern.compile((String)CONTENT_DISPOSITION_ATTRIBUTE_REGEX);
        LOG = Logger.getLogger((String)NanoHTTPD.class.getName());
    }

    public NanoHTTPD(int n) {
        this(null, n);
    }

    public NanoHTTPD(String string2, int n) {
        this.hostname = string2;
        this.myPort = n;
        this.setTempFileManagerFactory(new TempFileManagerFactory(){

            @Override
            public TempFileManager create() {
                return new TempFileManager(){
                    private final List<TempFile> tempFiles;
                    private final File tmpdir = new File(System.getProperty((String)"java.io.tmpdir"));
                    {
                        if (!this.tmpdir.exists()) {
                            this.tmpdir.mkdirs();
                        }
                        this.tempFiles = new ArrayList();
                    }

                    @Override
                    public void clear() {
                        for (TempFile tempFile : this.tempFiles) {
                            try {
                                tempFile.delete();
                            }
                            catch (Exception exception) {
                                LOG.log(Level.WARNING, "could not delete file ", (Throwable)exception);
                            }
                        }
                        this.tempFiles.clear();
                    }

                    @Override
                    public TempFile createTempFile(String string2) throws Exception {
                        TempFile tempFile = new TempFile(this.tmpdir){
                            private final File file;
                            private final OutputStream fstream;
                            {
                                this.file = File.createTempFile((String)"NanoHTTPD-", (String)"", (File)file);
                                this.fstream = new FileOutputStream(this.file);
                            }

                            @Override
                            public void delete() throws Exception {
                                NanoHTTPD.safeClose((Object)this.fstream);
                                if (this.file.delete()) {
                                    return;
                                }
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("could not delete temporary file: ");
                                stringBuilder.append(this.file.getAbsolutePath());
                                throw new Exception(stringBuilder.toString());
                            }

                            @Override
                            public String getName() {
                                return this.file.getAbsolutePath();
                            }

                            @Override
                            public OutputStream open() throws Exception {
                                return this.fstream;
                            }
                        };
                        this.tempFiles.add((Object)tempFile);
                        return tempFile;
                    }
                };
            }
        });
        this.setAsyncRunner(new AsyncRunner(){
            private long requestCount;
            private final List<ClientHandler> running = Collections.synchronizedList((List)new ArrayList());

            @Override
            public void closeAll() {
                Iterator iterator = new ArrayList(this.running).iterator();
                while (iterator.hasNext()) {
                    ((ClientHandler)iterator.next()).close();
                }
            }

            @Override
            public void closed(ClientHandler clientHandler) {
                this.running.remove((Object)clientHandler);
            }

            @Override
            public void exec(ClientHandler clientHandler) {
                this.requestCount = 1L + this.requestCount;
                Thread thread = new Thread((Runnable)clientHandler);
                thread.setDaemon(true);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("NanoHttpd Request Processor (#");
                stringBuilder.append(this.requestCount);
                stringBuilder.append(")");
                thread.setName(stringBuilder.toString());
                this.running.add((Object)clientHandler);
                thread.start();
            }

            public List<ClientHandler> getRunning() {
                return this.running;
            }
        });
    }

    static /* synthetic */ Pattern access$300() {
        return CONTENT_DISPOSITION_PATTERN;
    }

    static /* synthetic */ Pattern access$400() {
        return CONTENT_DISPOSITION_ATTRIBUTE_PATTERN;
    }

    static /* synthetic */ Pattern access$500() {
        return CONTENT_TYPE_PATTERN;
    }

    protected static Map<String, List<String>> decodeParameters(String string2) {
        HashMap hashMap = new HashMap();
        if (string2 != null) {
            StringTokenizer stringTokenizer = new StringTokenizer(string2, "&");
            while (stringTokenizer.hasMoreTokens()) {
                String string3;
                String string4 = stringTokenizer.nextToken();
                int n = string4.indexOf(61);
                String string5 = n >= 0 ? NanoHTTPD.decodePercent(string4.substring(0, n)) : NanoHTTPD.decodePercent(string4);
                String string6 = string5.trim();
                if (!hashMap.containsKey((Object)string6)) {
                    hashMap.put((Object)string6, (Object)new ArrayList());
                }
                if ((string3 = n >= 0 ? NanoHTTPD.decodePercent(string4.substring(n + 1)) : null) == null) continue;
                ((List)hashMap.get((Object)string6)).add((Object)string3);
            }
        }
        return hashMap;
    }

    protected static Map<String, List<String>> decodeParameters(Map<String, String> map) {
        return NanoHTTPD.decodeParameters((String)map.get((Object)QUERY_STRING_PARAMETER));
    }

    protected static String decodePercent(String string2) {
        try {
            String string3 = URLDecoder.decode((String)string2, (String)"UTF8");
            return string3;
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            LOG.log(Level.WARNING, "Encoding not supported, ignored", (Throwable)unsupportedEncodingException);
            return null;
        }
    }

    public static String getMimeTypeForFile(String string2) {
        int n = string2.lastIndexOf(46);
        String string3 = n >= 0 ? (String)NanoHTTPD.mimeTypes().get((Object)string2.substring(n + 1).toLowerCase()) : null;
        if (string3 == null) {
            string3 = "application/octet-stream";
        }
        return string3;
    }

    /*
     * Exception decompiling
     */
    private static void loadMimeTypes(Map<String, String> var0, String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl83 : RETURN : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static SSLServerSocketFactory makeSSLSocketFactory(String string2, char[] arrc) throws IOException {
        try {
            KeyStore keyStore = KeyStore.getInstance((String)KeyStore.getDefaultType());
            InputStream inputStream = NanoHTTPD.class.getResourceAsStream(string2);
            if (inputStream != null) {
                keyStore.load(inputStream, arrc);
                KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance((String)KeyManagerFactory.getDefaultAlgorithm());
                keyManagerFactory.init(keyStore, arrc);
                return NanoHTTPD.makeSSLSocketFactory(keyStore, keyManagerFactory);
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to load keystore from classpath: ");
            stringBuilder.append(string2);
            throw new IOException(stringBuilder.toString());
        }
        catch (Exception exception) {
            throw new IOException(exception.getMessage());
        }
    }

    public static SSLServerSocketFactory makeSSLSocketFactory(KeyStore keyStore, KeyManagerFactory keyManagerFactory) throws IOException {
        try {
            SSLServerSocketFactory sSLServerSocketFactory = NanoHTTPD.makeSSLSocketFactory(keyStore, keyManagerFactory.getKeyManagers());
            return sSLServerSocketFactory;
        }
        catch (Exception exception) {
            throw new IOException(exception.getMessage());
        }
    }

    public static SSLServerSocketFactory makeSSLSocketFactory(KeyStore keyStore, KeyManager[] arrkeyManager) throws IOException {
        try {
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance((String)TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init(keyStore);
            SSLContext sSLContext = SSLContext.getInstance((String)"TLS");
            sSLContext.init(arrkeyManager, trustManagerFactory.getTrustManagers(), null);
            SSLServerSocketFactory sSLServerSocketFactory = sSLContext.getServerSocketFactory();
            return sSLServerSocketFactory;
        }
        catch (Exception exception) {
            throw new IOException(exception.getMessage());
        }
    }

    public static Map<String, String> mimeTypes() {
        if (MIME_TYPES == null) {
            MIME_TYPES = new HashMap();
            NanoHTTPD.loadMimeTypes(MIME_TYPES, "META-INF/nanohttpd/default-mimetypes.properties");
            NanoHTTPD.loadMimeTypes(MIME_TYPES, "META-INF/nanohttpd/mimetypes.properties");
            if (MIME_TYPES.isEmpty()) {
                LOG.log(Level.WARNING, "no mime types found in the classpath! please provide mimetypes.properties");
            }
        }
        return MIME_TYPES;
    }

    public static Response newChunkedResponse(Response.IStatus iStatus, String string2, InputStream inputStream) {
        Response response = new Response(iStatus, string2, inputStream, -1L);
        return response;
    }

    public static Response newFixedLengthResponse(Response.IStatus iStatus, String string2, InputStream inputStream, long l) {
        Response response = new Response(iStatus, string2, inputStream, l);
        return response;
    }

    public static Response newFixedLengthResponse(Response.IStatus iStatus, String string2, String string3) {
        byte[] arrby;
        ContentType contentType = new ContentType(string2);
        if (string3 == null) {
            return NanoHTTPD.newFixedLengthResponse(iStatus, string2, (InputStream)new ByteArrayInputStream(new byte[0]), 0L);
        }
        try {
            if (!Charset.forName((String)contentType.getEncoding()).newEncoder().canEncode((CharSequence)string3)) {
                contentType = contentType.tryUTF8();
            }
            arrby = string3.getBytes(contentType.getEncoding());
        }
        catch (UnsupportedEncodingException unsupportedEncodingException) {
            LOG.log(Level.SEVERE, "encoding problem, responding nothing", (Throwable)unsupportedEncodingException);
            arrby = new byte[]{};
        }
        return NanoHTTPD.newFixedLengthResponse(iStatus, contentType.getContentTypeHeader(), (InputStream)new ByteArrayInputStream(arrby), arrby.length);
    }

    public static Response newFixedLengthResponse(String string2) {
        return NanoHTTPD.newFixedLengthResponse(Response.Status.OK, MIME_HTML, string2);
    }

    private static final void safeClose(Object object) {
        if (object != null) {
            try {
                if (object instanceof Closeable) {
                    ((Closeable)object).close();
                    return;
                }
                if (object instanceof Socket) {
                    ((Socket)object).close();
                    return;
                }
                if (object instanceof ServerSocket) {
                    ((ServerSocket)object).close();
                    return;
                }
                throw new IllegalArgumentException("Unknown object to close");
            }
            catch (IOException iOException) {
                LOG.log(Level.SEVERE, "Could not close", (Throwable)iOException);
            }
        }
    }

    public void closeAllConnections() {
        NanoHTTPD nanoHTTPD = this;
        synchronized (nanoHTTPD) {
            this.stop();
            return;
        }
    }

    protected ClientHandler createClientHandler(Socket socket, InputStream inputStream) {
        return new ClientHandler(inputStream, socket);
    }

    protected ServerRunnable createServerRunnable(int n) {
        return new ServerRunnable(n);
    }

    public String getHostname() {
        return this.hostname;
    }

    public final int getListeningPort() {
        if (this.myServerSocket == null) {
            return -1;
        }
        return this.myServerSocket.getLocalPort();
    }

    public ServerSocketFactory getServerSocketFactory() {
        return this.serverSocketFactory;
    }

    public TempFileManagerFactory getTempFileManagerFactory() {
        return this.tempFileManagerFactory;
    }

    public final boolean isAlive() {
        return this.wasStarted() && !this.myServerSocket.isClosed() && this.myThread.isAlive();
    }

    public void makeSecure(SSLServerSocketFactory sSLServerSocketFactory, String[] arrstring) {
        this.serverSocketFactory = new ServerSocketFactory(sSLServerSocketFactory, arrstring){
            private String[] sslProtocols;
            private SSLServerSocketFactory sslServerSocketFactory;
            {
                this.sslServerSocketFactory = sSLServerSocketFactory;
                this.sslProtocols = arrstring;
            }

            @Override
            public ServerSocket create() throws IOException {
                SSLServerSocket sSLServerSocket = (SSLServerSocket)this.sslServerSocketFactory.createServerSocket();
                String[] arrstring = this.sslProtocols;
                if (arrstring != null) {
                    sSLServerSocket.setEnabledProtocols(arrstring);
                } else {
                    sSLServerSocket.setEnabledProtocols(sSLServerSocket.getSupportedProtocols());
                }
                sSLServerSocket.setUseClientMode(false);
                sSLServerSocket.setWantClientAuth(false);
                sSLServerSocket.setNeedClientAuth(false);
                return sSLServerSocket;
            }
        };
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public Response serve(IHTTPSession iHTTPSession) {
        HashMap hashMap = new HashMap();
        Method method = iHTTPSession.getMethod();
        if (Method.PUT.equals((Object)method) || Method.POST.equals((Object)method)) {
            iHTTPSession.parseBody((Map<String, String>)hashMap);
        }
        Map<String, String> map = iHTTPSession.getParms();
        map.put((Object)QUERY_STRING_PARAMETER, (Object)iHTTPSession.getQueryParameterString());
        return this.serve(iHTTPSession.getUri(), method, iHTTPSession.getHeaders(), map, (Map<String, String>)hashMap);
        catch (ResponseException responseException) {
            return NanoHTTPD.newFixedLengthResponse(responseException.getStatus(), MIME_PLAINTEXT, responseException.getMessage());
        }
        catch (IOException iOException) {
            Response.Status status = Response.Status.INTERNAL_ERROR;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SERVER INTERNAL ERROR: IOException: ");
            stringBuilder.append(iOException.getMessage());
            return NanoHTTPD.newFixedLengthResponse(status, MIME_PLAINTEXT, stringBuilder.toString());
        }
    }

    @Deprecated
    public Response serve(String string2, Method method, Map<String, String> map, Map<String, String> map2, Map<String, String> map3) {
        return NanoHTTPD.newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not Found");
    }

    public void setAsyncRunner(AsyncRunner asyncRunner) {
        this.asyncRunner = asyncRunner;
    }

    public void setServerSocketFactory(ServerSocketFactory serverSocketFactory) {
        this.serverSocketFactory = serverSocketFactory;
    }

    public void setTempFileManagerFactory(TempFileManagerFactory tempFileManagerFactory) {
        this.tempFileManagerFactory = tempFileManagerFactory;
    }

    public void start() throws IOException {
        this.start(5000);
    }

    public void start(int n) throws IOException {
        this.start(n, true);
    }

    /*
     * Exception decompiling
     */
    public void start(int var1, boolean var2) throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl31 : ALOAD_3 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    public void stop() {
        try {
            NanoHTTPD.safeClose((Object)this.myServerSocket);
            this.asyncRunner.closeAll();
            if (this.myThread != null) {
                this.myThread.join();
                return;
            }
        }
        catch (Exception exception) {
            LOG.log(Level.SEVERE, "Could not stop all connections", (Throwable)exception);
        }
    }

    protected boolean useGzipWhenAccepted(Response response) {
        return response.getMimeType() != null && (response.getMimeType().toLowerCase().contains((CharSequence)"text/") || response.getMimeType().toLowerCase().contains((CharSequence)"/json"));
    }

    public final boolean wasStarted() {
        return this.myServerSocket != null && this.myThread != null;
    }

    public static interface AsyncRunner {
        public void closeAll();

        public void closed(ClientHandler var1);

        public void exec(ClientHandler var1);
    }

    public class ClientHandler
    implements Runnable {
        private final Socket acceptSocket;
        private final InputStream inputStream;

        public ClientHandler(InputStream inputStream, Socket socket) {
            this.inputStream = inputStream;
            this.acceptSocket = socket;
        }

        public void close() {
            NanoHTTPD.safeClose((Object)this.inputStream);
            NanoHTTPD.safeClose((Object)this.acceptSocket);
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        public void run() {
            OutputStream outputStream;
            Throwable throwable22;
            block5 : {
                outputStream = null;
                try {
                    try {
                        outputStream = this.acceptSocket.getOutputStream();
                        TempFileManager tempFileManager = NanoHTTPD.this.tempFileManagerFactory.create();
                        NanoHTTPD nanoHTTPD = NanoHTTPD.this;
                        InputStream inputStream = this.inputStream;
                        InetAddress inetAddress = this.acceptSocket.getInetAddress();
                        IHTTPSession iHTTPSession = new IHTTPSession(tempFileManager, inputStream, outputStream, inetAddress){
                            public static final int BUFSIZE = 8192;
                            public static final int MAX_HEADER_SIZE = 1024;
                            private static final int MEMORY_STORE_LIMIT = 1024;
                            private static final int REQUEST_BUFFER_LEN = 512;
                            private CookieHandler cookies;
                            private Map<String, String> headers;
                            private final BufferedInputStream inputStream;
                            private Method method;
                            private final OutputStream outputStream;
                            private Map<String, List<String>> parms;
                            private String protocolVersion;
                            private String queryParameterString;
                            private String remoteHostname;
                            private String remoteIp;
                            private int rlen;
                            private int splitbyte;
                            private final TempFileManager tempFileManager;
                            private String uri;
                            {
                                this.tempFileManager = tempFileManager;
                                this.inputStream = new BufferedInputStream(inputStream, 8192);
                                this.outputStream = outputStream;
                            }
                            {
                                this.tempFileManager = tempFileManager;
                                this.inputStream = new BufferedInputStream(inputStream, 8192);
                                this.outputStream = outputStream;
                                String string2 = !inetAddress.isLoopbackAddress() && !inetAddress.isAnyLocalAddress() ? inetAddress.getHostAddress().toString() : "127.0.0.1";
                                this.remoteIp = string2;
                                String string3 = !inetAddress.isLoopbackAddress() && !inetAddress.isAnyLocalAddress() ? inetAddress.getHostName().toString() : "localhost";
                                this.remoteHostname = string3;
                                this.headers = new HashMap();
                            }

                            /*
                             * Enabled aggressive block sorting
                             * Enabled unnecessary exception pruning
                             * Enabled aggressive exception aggregation
                             */
                            private void decodeHeader(BufferedReader bufferedReader, Map<String, String> map, Map<String, List<String>> map2, Map<String, String> map3) throws ResponseException {
                                try {
                                    String string2;
                                    String string3 = bufferedReader.readLine();
                                    if (string3 == null) {
                                        return;
                                    }
                                    StringTokenizer stringTokenizer = new StringTokenizer(string3);
                                    if (!stringTokenizer.hasMoreTokens()) {
                                        throw new ResponseException(Response.Status.BAD_REQUEST, "BAD REQUEST: Syntax error. Usage: GET /example/file.html");
                                    }
                                    map.put((Object)"method", (Object)stringTokenizer.nextToken());
                                    if (!stringTokenizer.hasMoreTokens()) {
                                        throw new ResponseException(Response.Status.BAD_REQUEST, "BAD REQUEST: Missing URI. Usage: GET /example/file.html");
                                    }
                                    String string4 = stringTokenizer.nextToken();
                                    int n = string4.indexOf(63);
                                    if (n >= 0) {
                                        this.decodeParms(string4.substring(n + 1), map2);
                                        string2 = NanoHTTPD.decodePercent(string4.substring(0, n));
                                    } else {
                                        string2 = NanoHTTPD.decodePercent(string4);
                                    }
                                    if (stringTokenizer.hasMoreTokens()) {
                                        this.protocolVersion = stringTokenizer.nextToken();
                                    } else {
                                        this.protocolVersion = "HTTP/1.1";
                                        LOG.log(Level.FINE, "no protocol version specified, strange. Assuming HTTP/1.1.");
                                    }
                                    String string5 = bufferedReader.readLine();
                                    while (string5 != null && !string5.trim().isEmpty()) {
                                        int n2 = string5.indexOf(58);
                                        if (n2 >= 0) {
                                            map3.put((Object)string5.substring(0, n2).trim().toLowerCase(Locale.US), (Object)string5.substring(n2 + 1).trim());
                                        }
                                        string5 = bufferedReader.readLine();
                                    }
                                    map.put((Object)"uri", (Object)string2);
                                    return;
                                }
                                catch (IOException iOException) {
                                    Response.Status status = Response.Status.INTERNAL_ERROR;
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append("SERVER INTERNAL ERROR: IOException: ");
                                    stringBuilder.append(iOException.getMessage());
                                    throw new ResponseException(status, stringBuilder.toString(), (Exception)((Object)iOException));
                                }
                            }

                            /*
                             * Unable to fully structure code
                             * Enabled aggressive block sorting
                             * Enabled unnecessary exception pruning
                             * Enabled aggressive exception aggregation
                             * Lifted jumps to return sites
                             */
                            private void decodeMultipartFormData(ContentType var1_1, ByteBuffer var2_2, Map<String, List<String>> var3_3, Map<String, String> var4_4) throws ResponseException {
                                var7_5 = this.getBoundaryPositions(var2_2, var1_1.getBoundary().getBytes());
                                var8_6 = var7_5.length;
                                var9_7 = 2;
                                if (var8_6 < var9_7) throw new ResponseException(Response.Status.BAD_REQUEST, "BAD REQUEST: Content type is multipart/form-data but contains less than two boundary strings.");
                                var10_8 = 1024;
                                var11_9 = new byte[var10_8];
                                var12_10 = 0;
                                var13_11 = 0;
                                while (var12_10 < (var14_12 = var7_5.length) - (var15_13 = 1)) {
                                    block18 : {
                                        block24 : {
                                            var2_2.position(var7_5[var12_10]);
                                            var17_14 = var2_2.remaining() < var10_8 ? var2_2.remaining() : 1024;
                                            var2_2.get(var11_9, 0, var17_14);
                                            var19_15 = new BufferedReader((Reader)new InputStreamReader((InputStream)new ByteArrayInputStream(var11_9, 0, var17_14), Charset.forName((String)var1_1.getEncoding())), var17_14);
                                            var20_16 = var19_15.readLine();
                                            if (var20_16 == null) throw new ResponseException(Response.Status.BAD_REQUEST, "BAD REQUEST: Content type is multipart/form-data but chunk does not start with boundary.");
                                            if (var20_16.contains((CharSequence)var1_1.getBoundary()) == false) throw new ResponseException(Response.Status.BAD_REQUEST, "BAD REQUEST: Content type is multipart/form-data but chunk does not start with boundary.");
                                            var21_17 = var19_15.readLine();
                                            var22_18 = null;
                                            var23_19 = var13_11;
                                            var24_20 = null;
                                            var25_21 = null;
                                            var26_22 = 2;
                                            do {
                                                block20 : {
                                                    block21 : {
                                                        block19 : {
                                                            if (var21_17 == null || var21_17.trim().length() <= 0) break block19;
                                                            var48_33 = NanoHTTPD.access$300().matcher((CharSequence)var21_17);
                                                            if (!var48_33.matches()) break block20;
                                                            var50_35 = var48_33.group(var9_7);
                                                            var51_36 = NanoHTTPD.access$400().matcher((CharSequence)var50_35);
                                                            break block21;
                                                        }
                                                        var27_23 = 0;
                                                        break;
                                                    }
                                                    while (var51_36.find()) {
                                                        block23 : {
                                                            block22 : {
                                                                var52_37 = var51_36.group(var15_13);
                                                                if (!"name".equalsIgnoreCase(var52_37)) break block22;
                                                                var58_41 = var51_36.group(2);
                                                                ** GOTO lbl53
                                                            }
                                                            if (!"filename".equalsIgnoreCase(var52_37)) break block23;
                                                            var53_38 = var51_36.group(2);
                                                            if (var53_38.isEmpty()) ** GOTO lbl56
                                                            if (var23_19 > 0) {
                                                                var54_39 = new StringBuilder();
                                                                var54_39.append(var22_18);
                                                                var56_40 = var23_19 + 1;
                                                                var54_39.append(String.valueOf((int)var23_19));
                                                                var58_41 = var54_39.toString();
                                                                var24_20 = var53_38;
                                                                var23_19 = var56_40;
lbl53: // 2 sources:
                                                                var22_18 = var58_41;
                                                            } else {
                                                                ++var23_19;
lbl56: // 2 sources:
                                                                var24_20 = var53_38;
                                                            }
                                                        }
                                                        var15_13 = 1;
                                                    }
                                                }
                                                if ((var49_34 = NanoHTTPD.access$500().matcher((CharSequence)var21_17)).matches()) {
                                                    var25_21 = var49_34.group(2).trim();
                                                }
                                                var21_17 = var19_15.readLine();
                                                ++var26_22;
                                                var9_7 = 2;
                                                var15_13 = 1;
                                            } while (true);
                                            do {
                                                var28_24 = var26_22 - 1;
                                                if (var26_22 <= 0) break;
                                                var27_23 = this.scipOverNewLine(var11_9, var27_23);
                                                var26_22 = var28_24;
                                                continue;
                                                break;
                                            } while (true);
                                            if (var27_23 >= var17_14 - 4) throw new ResponseException(Response.Status.INTERNAL_ERROR, "Multipart header size exceeds MAX_HEADER_SIZE.");
                                            var29_25 = var27_23 + var7_5[var12_10];
                                            ++var12_10;
                                            var30_26 = -4 + var7_5[var12_10];
                                            var2_2.position(var29_25);
                                            var32_27 = (List)var3_3.get(var22_18);
                                            if (var32_27 == null) {
                                                var32_27 = new ArrayList();
                                                var3_3.put((Object)var22_18, (Object)var32_27);
                                            }
                                            if (var25_21 == null) {
                                                var34_28 = new byte[var30_26 - var29_25];
                                                var2_2.get(var34_28);
                                                var32_27.add((Object)new String(var34_28, var1_1.getEncoding()));
                                                break block18;
                                            }
                                            var37_29 = this.saveTmpFile(var2_2, var29_25, var30_26 - var29_25, var24_20);
                                            if (var4_4.containsKey((Object)var22_18)) break block24;
                                            var4_4.put((Object)var22_18, (Object)var37_29);
                                            ** GOTO lbl109
                                        }
                                        var38_30 = 2;
                                        do {
                                            var39_31 = new StringBuilder();
                                            var39_31.append(var22_18);
                                            var39_31.append(var38_30);
                                            if (!var4_4.containsKey((Object)var39_31.toString())) break;
                                            ++var38_30;
                                        } while (true);
                                        try {
                                            var42_32 = new StringBuilder();
                                            var42_32.append(var22_18);
                                            var42_32.append(var38_30);
                                            var4_4.put((Object)var42_32.toString(), (Object)var37_29);
lbl109: // 2 sources:
                                            var32_27.add((Object)var24_20);
                                        }
                                        catch (Exception var6_42) {
                                            throw new ResponseException(Response.Status.INTERNAL_ERROR, var6_42.toString());
                                        }
                                        catch (ResponseException var5_43) {
                                            throw var5_43;
                                        }
                                    }
                                    var13_11 = var23_19;
                                    var10_8 = 1024;
                                    var9_7 = 2;
                                }
                            }

                            private void decodeParms(String string2, Map<String, List<String>> map) {
                                if (string2 == null) {
                                    this.queryParameterString = "";
                                    return;
                                }
                                this.queryParameterString = string2;
                                StringTokenizer stringTokenizer = new StringTokenizer(string2, "&");
                                while (stringTokenizer.hasMoreTokens()) {
                                    String string3;
                                    String string4;
                                    String string5 = stringTokenizer.nextToken();
                                    int n = string5.indexOf(61);
                                    if (n >= 0) {
                                        string3 = NanoHTTPD.decodePercent(string5.substring(0, n)).trim();
                                        string4 = NanoHTTPD.decodePercent(string5.substring(n + 1));
                                    } else {
                                        string3 = NanoHTTPD.decodePercent(string5).trim();
                                        string4 = "";
                                    }
                                    List list = (List)map.get((Object)string3);
                                    if (list == null) {
                                        list = new ArrayList();
                                        map.put((Object)string3, (Object)list);
                                    }
                                    list.add((Object)string4);
                                }
                            }

                            private int findHeaderEnd(byte[] arrby, int n) {
                                int n2;
                                int n3 = 0;
                                while ((n2 = n3 + 1) < n) {
                                    int n4;
                                    if (arrby[n3] == 13 && arrby[n2] == 10 && (n4 = n3 + 3) < n && arrby[n3 + 2] == 13 && arrby[n4] == 10) {
                                        return n3 + 4;
                                    }
                                    if (arrby[n3] == 10 && arrby[n2] == 10) {
                                        return n3 + 2;
                                    }
                                    n3 = n2;
                                }
                                return 0;
                            }

                            private int[] getBoundaryPositions(ByteBuffer byteBuffer, byte[] arrby) {
                                int[] arrn = new int[]{};
                                if (byteBuffer.remaining() < arrby.length) {
                                    return arrn;
                                }
                                byte[] arrby2 = new byte[4096 + arrby.length];
                                int n = byteBuffer.remaining() < arrby2.length ? byteBuffer.remaining() : arrby2.length;
                                byteBuffer.get(arrby2, 0, n);
                                int n2 = n - arrby.length;
                                int[] arrn2 = arrn;
                                int n3 = 0;
                                do {
                                    int[] arrn3 = arrn2;
                                    for (int i = 0; i < n2; ++i) {
                                        int[] arrn4 = arrn3;
                                        for (int j = 0; j < arrby.length && arrby2[i + j] == arrby[j]; ++j) {
                                            if (j != -1 + arrby.length) continue;
                                            int[] arrn5 = new int[1 + arrn4.length];
                                            System.arraycopy((Object)arrn4, (int)0, (Object)arrn5, (int)0, (int)arrn4.length);
                                            arrn5[arrn4.length] = n3 + i;
                                            arrn4 = arrn5;
                                        }
                                        arrn3 = arrn4;
                                    }
                                    n3 += n2;
                                    System.arraycopy((Object)arrby2, (int)(arrby2.length - arrby.length), (Object)arrby2, (int)0, (int)arrby.length);
                                    n2 = arrby2.length - arrby.length;
                                    if (byteBuffer.remaining() < n2) {
                                        n2 = byteBuffer.remaining();
                                    }
                                    byteBuffer.get(arrby2, arrby.length, n2);
                                    if (n2 <= 0) {
                                        return arrn3;
                                    }
                                    arrn2 = arrn3;
                                } while (true);
                            }

                            private RandomAccessFile getTmpBucket() {
                                try {
                                    RandomAccessFile randomAccessFile = new RandomAccessFile(this.tempFileManager.createTempFile(null).getName(), "rw");
                                    return randomAccessFile;
                                }
                                catch (Exception exception) {
                                    throw new Error((Throwable)exception);
                                }
                            }

                            /*
                             * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
                             * Loose catch block
                             * Enabled aggressive block sorting
                             * Enabled unnecessary exception pruning
                             * Enabled aggressive exception aggregation
                             * Lifted jumps to return sites
                             */
                            private String saveTmpFile(ByteBuffer byteBuffer, int n, int n2, String string2) {
                                void var7_13;
                                FileOutputStream fileOutputStream;
                                block7 : {
                                    String string3;
                                    void var6_16;
                                    if (n2 <= 0) return "";
                                    fileOutputStream = null;
                                    TempFile tempFile = this.tempFileManager.createTempFile(string2);
                                    ByteBuffer byteBuffer2 = byteBuffer.duplicate();
                                    FileOutputStream fileOutputStream2 = new FileOutputStream(tempFile.getName());
                                    try {
                                        FileChannel fileChannel = fileOutputStream2.getChannel();
                                        byteBuffer2.position(n).limit(n + n2);
                                        fileChannel.write(byteBuffer2.slice());
                                        string3 = tempFile.getName();
                                    }
                                    catch (Throwable throwable) {
                                        fileOutputStream = fileOutputStream2;
                                        break block7;
                                    }
                                    catch (Exception exception) {
                                        fileOutputStream = fileOutputStream2;
                                        throw new Error((Throwable)var6_16);
                                    }
                                    NanoHTTPD.safeClose((Object)fileOutputStream2);
                                    return string3;
                                    catch (Throwable throwable) {
                                        break block7;
                                    }
                                    catch (Exception exception) {
                                        // empty catch block
                                    }
                                    {
                                        throw new Error((Throwable)var6_16);
                                    }
                                }
                                NanoHTTPD.safeClose(fileOutputStream);
                                throw var7_13;
                            }

                            private int scipOverNewLine(byte[] arrby, int n) {
                                while (arrby[n] != 10) {
                                    ++n;
                                }
                                return n + 1;
                            }

                            /*
                             * Exception decompiling
                             */
                            @Override
                            public void execute() throws IOException {
                                // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
                                // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
                                // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
                                // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
                                // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
                                // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
                                // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
                                // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
                                // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
                                // org.benf.cfr.reader.entities.g.p(Method.java:396)
                                // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
                                // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
                                // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
                                // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
                                // org.benf.cfr.reader.b.a(Driver.java:128)
                                // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
                                // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
                                // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
                                // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
                                // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
                                // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
                                // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
                                // java.lang.Thread.run(Thread.java:919)
                                throw new IllegalStateException("Decompilation failed");
                            }

                            public long getBodySize() {
                                if (this.headers.containsKey((Object)"content-length")) {
                                    return Long.parseLong((String)((String)this.headers.get((Object)"content-length")));
                                }
                                int n = this.splitbyte;
                                int n2 = this.rlen;
                                if (n < n2) {
                                    return n2 - n;
                                }
                                return 0L;
                            }

                            @Override
                            public CookieHandler getCookies() {
                                return this.cookies;
                            }

                            @Override
                            public final Map<String, String> getHeaders() {
                                return this.headers;
                            }

                            @Override
                            public final InputStream getInputStream() {
                                return this.inputStream;
                            }

                            @Override
                            public final Method getMethod() {
                                return this.method;
                            }

                            @Override
                            public final Map<String, List<String>> getParameters() {
                                return this.parms;
                            }

                            @Deprecated
                            @Override
                            public final Map<String, String> getParms() {
                                HashMap hashMap = new HashMap();
                                for (String string2 : this.parms.keySet()) {
                                    hashMap.put((Object)string2, ((List)this.parms.get((Object)string2)).get(0));
                                }
                                return hashMap;
                            }

                            @Override
                            public String getQueryParameterString() {
                                return this.queryParameterString;
                            }

                            @Override
                            public String getRemoteHostName() {
                                return this.remoteHostname;
                            }

                            @Override
                            public String getRemoteIpAddress() {
                                return this.remoteIp;
                            }

                            @Override
                            public final String getUri() {
                                return this.uri;
                            }

                            /*
                             * Loose catch block
                             * Enabled aggressive block sorting
                             * Enabled unnecessary exception pruning
                             * Enabled aggressive exception aggregation
                             * Lifted jumps to return sites
                             */
                            @Override
                            public void parseBody(Map<String, String> map) throws IOException, ResponseException {
                                RandomAccessFile randomAccessFile;
                                void var2_14;
                                block16 : {
                                    block15 : {
                                        RandomAccessFile randomAccessFile2;
                                        long l;
                                        ByteArrayOutputStream byteArrayOutputStream;
                                        block14 : {
                                            l = this.getBodySize();
                                            if (l < 1024L) {
                                                ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
                                                randomAccessFile2 = new DataOutputStream((OutputStream)byteArrayOutputStream2);
                                                byteArrayOutputStream = byteArrayOutputStream2;
                                                randomAccessFile = null;
                                                break block14;
                                            }
                                            randomAccessFile = this.getTmpBucket();
                                            byteArrayOutputStream = null;
                                            randomAccessFile2 = randomAccessFile;
                                        }
                                        try {
                                            ByteBuffer byteBuffer;
                                            byte[] arrby = new byte[512];
                                            while (this.rlen >= 0 && l > 0L) {
                                                this.rlen = this.inputStream.read(arrby, 0, (int)Math.min((long)l, (long)512L));
                                                l -= (long)this.rlen;
                                                if (this.rlen <= 0) continue;
                                                randomAccessFile2.write(arrby, 0, this.rlen);
                                            }
                                            if (byteArrayOutputStream != null) {
                                                byteBuffer = ByteBuffer.wrap((byte[])byteArrayOutputStream.toByteArray(), (int)0, (int)byteArrayOutputStream.size());
                                            } else {
                                                byteBuffer = randomAccessFile.getChannel().map(FileChannel.MapMode.READ_ONLY, 0L, randomAccessFile.length());
                                                randomAccessFile.seek(0L);
                                            }
                                            if (Method.POST.equals((Object)this.method)) {
                                                ContentType contentType = new ContentType((String)this.headers.get((Object)"content-type"));
                                                if (contentType.isMultipart()) {
                                                    if (contentType.getBoundary() == null) throw new ResponseException(Response.Status.BAD_REQUEST, "BAD REQUEST: Content type is multipart/form-data but boundary missing. Usage: GET /example/file.html");
                                                    this.decodeMultipartFormData(contentType, byteBuffer, this.parms, map);
                                                } else {
                                                    byte[] arrby2 = new byte[byteBuffer.remaining()];
                                                    byteBuffer.get(arrby2);
                                                    String string2 = new String(arrby2, contentType.getEncoding()).trim();
                                                    if ("application/x-www-form-urlencoded".equalsIgnoreCase(contentType.getContentType())) {
                                                        this.decodeParms(string2, this.parms);
                                                    } else if (string2.length() != 0) {
                                                        map.put((Object)"postData", (Object)string2);
                                                    }
                                                }
                                                break block15;
                                            }
                                            if (!Method.PUT.equals((Object)this.method)) break block15;
                                            map.put((Object)"content", (Object)this.saveTmpFile(byteBuffer, 0, byteBuffer.limit(), null));
                                        }
                                        catch (Throwable throwable) {}
                                    }
                                    NanoHTTPD.safeClose((Object)randomAccessFile);
                                    return;
                                    break block16;
                                    catch (Throwable throwable) {
                                        randomAccessFile = null;
                                    }
                                }
                                NanoHTTPD.safeClose(randomAccessFile);
                                throw var2_14;
                            }
                        };
                        while (!this.acceptSocket.isClosed()) {
                            iHTTPSession.execute();
                        }
                    }
                    catch (Exception exception) {
                        if (exception instanceof SocketException && "NanoHttpd Shutdown".equals((Object)exception.getMessage()) || exception instanceof SocketTimeoutException) break block5;
                        LOG.log(Level.SEVERE, "Communication with the client broken, or an bug in the handler code", (Throwable)exception);
                    }
                }
                catch (Throwable throwable22) {}
            }
            NanoHTTPD.safeClose((Object)outputStream);
            NanoHTTPD.safeClose((Object)this.inputStream);
            NanoHTTPD.safeClose((Object)this.acceptSocket);
            NanoHTTPD.this.asyncRunner.closed(this);
            return;
            NanoHTTPD.safeClose((Object)outputStream);
            NanoHTTPD.safeClose((Object)this.inputStream);
            NanoHTTPD.safeClose((Object)this.acceptSocket);
            NanoHTTPD.this.asyncRunner.closed(this);
            throw throwable22;
        }
    }

    protected static class ContentType {
        private static final String ASCII_ENCODING = "US-ASCII";
        private static final Pattern BOUNDARY_PATTERN;
        private static final String BOUNDARY_REGEX = "[ |\t]*(boundary)[ |\t]*=[ |\t]*['|\"]?([^\"^'^;^,]*)['|\"]?";
        private static final Pattern CHARSET_PATTERN;
        private static final String CHARSET_REGEX = "[ |\t]*(charset)[ |\t]*=[ |\t]*['|\"]?([^\"^'^;^,]*)['|\"]?";
        private static final String CONTENT_REGEX = "[ |\t]*([^/^ ^;^,]+/[^ ^;^,]+)";
        private static final Pattern MIME_PATTERN;
        private static final String MULTIPART_FORM_DATA_HEADER = "multipart/form-data";
        private final String boundary;
        private final String contentType;
        private final String contentTypeHeader;
        private final String encoding;

        static {
            MIME_PATTERN = Pattern.compile((String)CONTENT_REGEX, (int)2);
            CHARSET_PATTERN = Pattern.compile((String)CHARSET_REGEX, (int)2);
            BOUNDARY_PATTERN = Pattern.compile((String)BOUNDARY_REGEX, (int)2);
        }

        public ContentType(String string2) {
            this.contentTypeHeader = string2;
            if (string2 != null) {
                this.contentType = this.getDetailFromContentHeader(string2, MIME_PATTERN, "", 1);
                this.encoding = this.getDetailFromContentHeader(string2, CHARSET_PATTERN, null, 2);
            } else {
                this.contentType = "";
                this.encoding = "UTF-8";
            }
            if (MULTIPART_FORM_DATA_HEADER.equalsIgnoreCase(this.contentType)) {
                this.boundary = this.getDetailFromContentHeader(string2, BOUNDARY_PATTERN, null, 2);
                return;
            }
            this.boundary = null;
        }

        private String getDetailFromContentHeader(String string2, Pattern pattern, String string3, int n) {
            Matcher matcher = pattern.matcher((CharSequence)string2);
            if (matcher.find()) {
                string3 = matcher.group(n);
            }
            return string3;
        }

        public String getBoundary() {
            return this.boundary;
        }

        public String getContentType() {
            return this.contentType;
        }

        public String getContentTypeHeader() {
            return this.contentTypeHeader;
        }

        public String getEncoding() {
            String string2 = this.encoding;
            if (string2 == null) {
                string2 = ASCII_ENCODING;
            }
            return string2;
        }

        public boolean isMultipart() {
            return MULTIPART_FORM_DATA_HEADER.equalsIgnoreCase(this.contentType);
        }

        public ContentType tryUTF8() {
            if (this.encoding == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(this.contentTypeHeader);
                stringBuilder.append("; charset=UTF-8");
                return new ContentType(stringBuilder.toString());
            }
            return this;
        }
    }

    public static class Cookie {
        private final String e;
        private final String n;
        private final String v;

        public Cookie(String string2, String string3) {
            this(string2, string3, 30);
        }

        public Cookie(String string2, String string3, int n) {
            this.n = string2;
            this.v = string3;
            this.e = Cookie.getHTTPTime(n);
        }

        public Cookie(String string2, String string3, String string4) {
            this.n = string2;
            this.v = string3;
            this.e = string4;
        }

        public static String getHTTPTime(int n) {
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone((String)"GMT"));
            calendar.add(5, n);
            return simpleDateFormat.format(calendar.getTime());
        }

        public String getHTTPHeader() {
            Object[] arrobject = new Object[]{this.n, this.v, this.e};
            return String.format((String)"%s=%s; expires=%s", (Object[])arrobject);
        }
    }

    public class CookieHandler
    implements Iterable<String> {
        private final HashMap<String, String> cookies = new HashMap();
        private final ArrayList<Cookie> queue = new ArrayList();

        public CookieHandler(Map<String, String> map) {
            String string2 = (String)map.get((Object)"cookie");
            if (string2 != null) {
                String[] arrstring = string2.split(";");
                int n = arrstring.length;
                for (int i = 0; i < n; ++i) {
                    String[] arrstring2 = arrstring[i].trim().split("=");
                    if (arrstring2.length != 2) continue;
                    this.cookies.put((Object)arrstring2[0], (Object)arrstring2[1]);
                }
            }
        }

        public void delete(String string2) {
            this.set(string2, "-delete-", -30);
        }

        public Iterator<String> iterator() {
            return this.cookies.keySet().iterator();
        }

        public String read(String string2) {
            return (String)this.cookies.get((Object)string2);
        }

        public void set(Cookie cookie) {
            this.queue.add((Object)cookie);
        }

        public void set(String string2, String string3, int n) {
            this.queue.add((Object)new Cookie(string2, string3, Cookie.getHTTPTime(n)));
        }

        public void unloadQueue(Response response) {
            Iterator iterator = this.queue.iterator();
            while (iterator.hasNext()) {
                response.addHeader("Set-Cookie", ((Cookie)iterator.next()).getHTTPHeader());
            }
        }
    }

    public static interface IHTTPSession {
        public void execute() throws IOException;

        public CookieHandler getCookies();

        public Map<String, String> getHeaders();

        public InputStream getInputStream();

        public Method getMethod();

        public Map<String, List<String>> getParameters();

        @Deprecated
        public Map<String, String> getParms();

        public String getQueryParameterString();

        public String getRemoteHostName();

        public String getRemoteIpAddress();

        public String getUri();

        public void parseBody(Map<String, String> var1) throws IOException, ResponseException;
    }

    public static final class Method
    extends Enum<Method> {
        private static final /* synthetic */ Method[] $VALUES;
        public static final /* enum */ Method CONNECT;
        public static final /* enum */ Method COPY;
        public static final /* enum */ Method DELETE;
        public static final /* enum */ Method GET;
        public static final /* enum */ Method HEAD;
        public static final /* enum */ Method LOCK;
        public static final /* enum */ Method MKCOL;
        public static final /* enum */ Method MOVE;
        public static final /* enum */ Method OPTIONS;
        public static final /* enum */ Method PATCH;
        public static final /* enum */ Method POST;
        public static final /* enum */ Method PROPFIND;
        public static final /* enum */ Method PROPPATCH;
        public static final /* enum */ Method PUT;
        public static final /* enum */ Method TRACE;
        public static final /* enum */ Method UNLOCK;

        static {
            GET = new Method();
            PUT = new Method();
            POST = new Method();
            DELETE = new Method();
            HEAD = new Method();
            OPTIONS = new Method();
            TRACE = new Method();
            CONNECT = new Method();
            PATCH = new Method();
            PROPFIND = new Method();
            PROPPATCH = new Method();
            MKCOL = new Method();
            MOVE = new Method();
            COPY = new Method();
            LOCK = new Method();
            UNLOCK = new Method();
            Method[] arrmethod = new Method[]{GET, PUT, POST, DELETE, HEAD, OPTIONS, TRACE, CONNECT, PATCH, PROPFIND, PROPPATCH, MKCOL, MOVE, COPY, LOCK, UNLOCK};
            $VALUES = arrmethod;
        }

        static Method lookup(String string2) {
            if (string2 == null) {
                return null;
            }
            try {
                Method method = Method.valueOf(string2);
                return method;
            }
            catch (IllegalArgumentException illegalArgumentException) {
                return null;
            }
        }

        public static Method valueOf(String string2) {
            return (Method)Enum.valueOf(Method.class, (String)string2);
        }

        public static Method[] values() {
            return (Method[])$VALUES.clone();
        }
    }

    public static class Response
    implements Closeable {
        private boolean chunkedTransfer;
        private long contentLength;
        private InputStream data;
        private boolean encodeAsGzip;
        private final Map<String, String> header = new HashMap<String, String>(){

            public String put(String string2, String string3) {
                Map map = Response.this.lowerCaseHeader;
                String string4 = string2 == null ? string2 : string2.toLowerCase();
                map.put((Object)string4, (Object)string3);
                return (String)super.put((Object)string2, (Object)string3);
            }
        };
        private boolean keepAlive;
        private final Map<String, String> lowerCaseHeader = new HashMap();
        private String mimeType;
        private Method requestMethod;
        private IStatus status;

        protected Response(IStatus iStatus, String string2, InputStream inputStream, long l) {
            this.status = iStatus;
            this.mimeType = string2;
            if (inputStream == null) {
                this.data = new ByteArrayInputStream(new byte[0]);
                this.contentLength = 0L;
            } else {
                this.data = inputStream;
                this.contentLength = l;
            }
            long l2 = this.contentLength LCMP 0L;
            boolean bl = false;
            if (l2 < 0) {
                bl = true;
            }
            this.chunkedTransfer = bl;
            this.keepAlive = true;
        }

        private void sendBody(OutputStream outputStream, long l) throws IOException {
            byte[] arrby = new byte[(int)16384L];
            boolean bl = l == -1L;
            int n;
            long l2;
            while ((l > 0L || bl) && (n = this.data.read(arrby, 0, (int)(l2 = bl ? 16384L : Math.min((long)l, (long)16384L)))) > 0) {
                outputStream.write(arrby, 0, n);
                if (bl) continue;
                l -= (long)n;
            }
            return;
        }

        private void sendBodyWithCorrectEncoding(OutputStream outputStream, long l) throws IOException {
            if (this.encodeAsGzip) {
                GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(outputStream);
                this.sendBody((OutputStream)gZIPOutputStream, -1L);
                gZIPOutputStream.finish();
                return;
            }
            this.sendBody(outputStream, l);
        }

        private void sendBodyWithCorrectTransferAndEncoding(OutputStream outputStream, long l) throws IOException {
            if (this.requestMethod != Method.HEAD && this.chunkedTransfer) {
                ChunkedOutputStream chunkedOutputStream = new ChunkedOutputStream(outputStream);
                this.sendBodyWithCorrectEncoding((OutputStream)chunkedOutputStream, -1L);
                chunkedOutputStream.finish();
                return;
            }
            this.sendBodyWithCorrectEncoding(outputStream, l);
        }

        public void addHeader(String string2, String string3) {
            this.header.put((Object)string2, (Object)string3);
        }

        public void close() throws IOException {
            InputStream inputStream = this.data;
            if (inputStream != null) {
                inputStream.close();
            }
        }

        public void closeConnection(boolean bl) {
            if (bl) {
                this.header.put((Object)"connection", (Object)"close");
                return;
            }
            this.header.remove((Object)"connection");
        }

        public InputStream getData() {
            return this.data;
        }

        public String getHeader(String string2) {
            return (String)this.lowerCaseHeader.get((Object)string2.toLowerCase());
        }

        public String getMimeType() {
            return this.mimeType;
        }

        public Method getRequestMethod() {
            return this.requestMethod;
        }

        public IStatus getStatus() {
            return this.status;
        }

        public boolean isCloseConnection() {
            return "close".equals((Object)this.getHeader("connection"));
        }

        protected void printHeader(PrintWriter printWriter, String string2, String string3) {
            printWriter.append((CharSequence)string2).append((CharSequence)": ").append((CharSequence)string3).append((CharSequence)"\r\n");
        }

        /*
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         */
        protected void send(OutputStream outputStream) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("E, d MMM yyyy HH:mm:ss 'GMT'", Locale.US);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone((String)"GMT"));
            try {
                if (this.status == null) {
                    throw new Error("sendResponse(): Status can't be null.");
                }
                PrintWriter printWriter = new PrintWriter((Writer)new BufferedWriter((Writer)new OutputStreamWriter(outputStream, new ContentType(this.mimeType).getEncoding())), false);
                printWriter.append((CharSequence)"HTTP/1.1 ").append((CharSequence)this.status.getDescription()).append((CharSequence)" \r\n");
                if (this.mimeType != null) {
                    this.printHeader(printWriter, "Content-Type", this.mimeType);
                }
                if (this.getHeader("date") == null) {
                    this.printHeader(printWriter, "Date", simpleDateFormat.format(new Date()));
                }
                for (Map.Entry entry : this.header.entrySet()) {
                    this.printHeader(printWriter, (String)entry.getKey(), (String)entry.getValue());
                }
                if (this.getHeader("connection") == null) {
                    String string2 = this.keepAlive ? "keep-alive" : "close";
                    this.printHeader(printWriter, "Connection", string2);
                }
                if (this.getHeader("content-length") != null) {
                    this.encodeAsGzip = false;
                }
                if (this.encodeAsGzip) {
                    this.printHeader(printWriter, "Content-Encoding", "gzip");
                    this.setChunkedTransfer(true);
                }
                long l = this.data != null ? this.contentLength : 0L;
                if (this.requestMethod != Method.HEAD && this.chunkedTransfer) {
                    this.printHeader(printWriter, "Transfer-Encoding", "chunked");
                } else if (!this.encodeAsGzip) {
                    l = this.sendContentLengthHeaderIfNotAlreadyPresent(printWriter, l);
                }
                printWriter.append((CharSequence)"\r\n");
                printWriter.flush();
                this.sendBodyWithCorrectTransferAndEncoding(outputStream, l);
                outputStream.flush();
                NanoHTTPD.safeClose((Object)this.data);
                return;
            }
            catch (IOException iOException) {
                LOG.log(Level.SEVERE, "Could not send response to the client", (Throwable)iOException);
                return;
            }
        }

        /*
         * Exception decompiling
         */
        protected long sendContentLengthHeaderIfNotAlreadyPresent(PrintWriter var1, long var2) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl29 : NEW : trying to set 1 previously set to 0
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
            // java.lang.Thread.run(Thread.java:919)
            throw new IllegalStateException("Decompilation failed");
        }

        public void setChunkedTransfer(boolean bl) {
            this.chunkedTransfer = bl;
        }

        public void setData(InputStream inputStream) {
            this.data = inputStream;
        }

        public void setGzipEncoding(boolean bl) {
            this.encodeAsGzip = bl;
        }

        public void setKeepAlive(boolean bl) {
            this.keepAlive = bl;
        }

        public void setMimeType(String string2) {
            this.mimeType = string2;
        }

        public void setRequestMethod(Method method) {
            this.requestMethod = method;
        }

        public void setStatus(IStatus iStatus) {
            this.status = iStatus;
        }

        private static class ChunkedOutputStream
        extends FilterOutputStream {
            public ChunkedOutputStream(OutputStream outputStream) {
                super(outputStream);
            }

            public void finish() throws IOException {
                this.out.write("0\r\n\r\n".getBytes());
            }

            public void write(int n) throws IOException {
                byte[] arrby = new byte[]{(byte)n};
                this.write(arrby, 0, 1);
            }

            public void write(byte[] arrby) throws IOException {
                this.write(arrby, 0, arrby.length);
            }

            public void write(byte[] arrby, int n, int n2) throws IOException {
                if (n2 == 0) {
                    return;
                }
                OutputStream outputStream = this.out;
                Object[] arrobject = new Object[]{n2};
                outputStream.write(String.format((String)"%x\r\n", (Object[])arrobject).getBytes());
                this.out.write(arrby, n, n2);
                this.out.write("\r\n".getBytes());
            }
        }

        public static interface IStatus {
            public String getDescription();

            public int getRequestStatus();
        }

    }

    public static final class ResponseException
    extends Exception {
        private static final long serialVersionUID = 6569838532917408380L;
        private final Response.Status status;

        public ResponseException(Response.Status status, String string2) {
            super(string2);
            this.status = status;
        }

        public ResponseException(Response.Status status, String string2, Exception exception) {
            super(string2, (Throwable)exception);
            this.status = status;
        }

        public Response.Status getStatus() {
            return this.status;
        }
    }

    public class ServerRunnable
    implements Runnable {
        private IOException bindException;
        private boolean hasBinded = false;
        private final int timeout;

        public ServerRunnable(int n) {
            this.timeout = n;
        }

        static /* synthetic */ boolean access$1100(ServerRunnable serverRunnable) {
            return serverRunnable.hasBinded;
        }

        static /* synthetic */ IOException access$1200(ServerRunnable serverRunnable) {
            return serverRunnable.bindException;
        }

        public void run() {
            try {
                ServerSocket serverSocket = NanoHTTPD.this.myServerSocket;
                InetSocketAddress inetSocketAddress = NanoHTTPD.this.hostname != null ? new InetSocketAddress(NanoHTTPD.this.hostname, NanoHTTPD.this.myPort) : new InetSocketAddress(NanoHTTPD.this.myPort);
                serverSocket.bind((SocketAddress)inetSocketAddress);
                this.hasBinded = true;
            }
            catch (IOException iOException) {
                this.bindException = iOException;
                return;
            }
            do {
                try {
                    Socket socket = NanoHTTPD.this.myServerSocket.accept();
                    if (this.timeout > 0) {
                        socket.setSoTimeout(this.timeout);
                    }
                    InputStream inputStream = socket.getInputStream();
                    NanoHTTPD.this.asyncRunner.exec(NanoHTTPD.this.createClientHandler(socket, inputStream));
                }
                catch (IOException iOException) {
                    LOG.log(Level.FINE, "Communication with the client broken", (Throwable)iOException);
                }
            } while (!NanoHTTPD.this.myServerSocket.isClosed());
            return;
        }
    }

    public static interface ServerSocketFactory {
        public ServerSocket create() throws IOException;
    }

    public static interface TempFile {
        public void delete() throws Exception;

        public String getName();

        public OutputStream open() throws Exception;
    }

    public static interface TempFileManager {
        public void clear();

        public TempFile createTempFile(String var1) throws Exception;
    }

    public static interface TempFileManagerFactory {
        public TempFileManager create();
    }

}

