/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  fi.iki.elonen.NanoHTTPD
 *  fi.iki.elonen.NanoHTTPD$Response
 *  fi.iki.elonen.NanoHTTPD$Response$IStatus
 *  java.io.ByteArrayInputStream
 *  java.io.InputStream
 *  java.lang.String
 *  java.util.Map
 */
package fi.iki.elonen;

import fi.iki.elonen.NanoHTTPD;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Map;

public class InternalRewrite
extends NanoHTTPD.Response {
    private final Map<String, String> headers;
    private final String uri;

    public InternalRewrite(Map<String, String> map, String string) {
        super((NanoHTTPD.Response.IStatus)NanoHTTPD.Response.Status.OK, "text/html", (InputStream)new ByteArrayInputStream(new byte[0]), 0L);
        this.headers = map;
        this.uri = string;
    }

    public Map<String, String> getHeaders() {
        return this.headers;
    }

    public String getUri() {
        return this.uri;
    }
}

