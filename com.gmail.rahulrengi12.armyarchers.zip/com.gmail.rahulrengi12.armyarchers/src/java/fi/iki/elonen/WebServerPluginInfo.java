/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package fi.iki.elonen;

import fi.iki.elonen.WebServerPlugin;

public interface WebServerPluginInfo {
    public String[] getIndexFilesForMimeType(String var1);

    public String[] getMimeTypes();

    public WebServerPlugin getWebServerPlugin(String var1);
}

