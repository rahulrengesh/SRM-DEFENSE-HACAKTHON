/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  fi.iki.elonen.NanoHTTPD
 *  fi.iki.elonen.NanoHTTPD$IHTTPSession
 *  fi.iki.elonen.NanoHTTPD$Method
 *  fi.iki.elonen.NanoHTTPD$Response
 *  fi.iki.elonen.NanoHTTPD$Response$IStatus
 *  fi.iki.elonen.SimpleWebServer$2
 *  fi.iki.elonen.SimpleWebServer$3
 *  fi.iki.elonen.WebServerPlugin
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileNotFoundException
 *  java.io.FilenameFilter
 *  java.io.InputStream
 *  java.io.PrintStream
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 */
package fi.iki.elonen;

import fi.iki.elonen.InternalRewrite;
import fi.iki.elonen.NanoHTTPD;
import fi.iki.elonen.SimpleWebServer;
import fi.iki.elonen.WebServerPlugin;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SimpleWebServer
extends NanoHTTPD {
    public static final String ACCESS_CONTROL_ALLOW_HEADER_PROPERTY_NAME = "AccessControlAllowHeader";
    private static final String ALLOWED_METHODS = "GET, POST, PUT, DELETE, OPTIONS, HEAD";
    static final String DEFAULT_ALLOWED_HEADERS = "origin,accept,content-type";
    public static final List<String> INDEX_FILE_NAMES;
    private static final String LICENCE;
    private static final int MAX_AGE = 151200;
    private static Map<String, WebServerPlugin> mimeTypeHandlers;
    private final String cors;
    private final boolean quiet;
    protected List<File> rootDirs;

    /*
     * Exception decompiling
     */
    static {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl37 : ALOAD_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    public SimpleWebServer(String string, int n, File file, boolean bl) {
        this(string, n, (List<File>)Collections.singletonList((Object)file), bl, null);
    }

    public SimpleWebServer(String string, int n, File file, boolean bl, String string2) {
        this(string, n, (List<File>)Collections.singletonList((Object)file), bl, string2);
    }

    public SimpleWebServer(String string, int n, List<File> list, boolean bl) {
        this(string, n, list, bl, null);
    }

    public SimpleWebServer(String string, int n, List<File> list, boolean bl, String string2) {
        super(string, n);
        this.quiet = bl;
        this.cors = string2;
        this.rootDirs = new ArrayList(list);
        this.init();
    }

    private String calculateAllowHeaders(Map<String, String> map) {
        return System.getProperty((String)ACCESS_CONTROL_ALLOW_HEADER_PROPERTY_NAME, (String)DEFAULT_ALLOWED_HEADERS);
    }

    private boolean canServeUri(String string, File file) {
        WebServerPlugin webServerPlugin;
        boolean bl = new File(file, string).exists();
        if (!bl && (webServerPlugin = (WebServerPlugin)mimeTypeHandlers.get((Object)SimpleWebServer.getMimeTypeForFile((String)string))) != null) {
            bl = webServerPlugin.canServeUri(string, file);
        }
        return bl;
    }

    private NanoHTTPD.Response defaultRespond(Map<String, String> map, NanoHTTPD.IHTTPSession iHTTPSession, String string) {
        NanoHTTPD.Response response;
        String string2;
        String string3 = string.trim().replace(File.separatorChar, '/');
        int n = string3.indexOf(63);
        boolean bl = false;
        if (n >= 0) {
            string3 = string3.substring(0, string3.indexOf(63));
        }
        if ((string2 = string3).contains((CharSequence)"../")) {
            return this.getForbiddenResponse("Won't serve ../ for security reasons.");
        }
        File file = null;
        for (int i = 0; !bl && i < this.rootDirs.size(); ++i) {
            file = (File)this.rootDirs.get(i);
            bl = this.canServeUri(string2, file);
        }
        if (!bl) {
            return this.getNotFoundResponse();
        }
        File file2 = new File(file, string2);
        if (file2.isDirectory() && !string2.endsWith("/")) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append("/");
            String string4 = stringBuilder.toString();
            NanoHTTPD.Response.Status status = NanoHTTPD.Response.Status.REDIRECT;
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("<html><body>Redirected: <a href=\"");
            stringBuilder2.append(string4);
            stringBuilder2.append("\">");
            stringBuilder2.append(string4);
            stringBuilder2.append("</a></body></html>");
            NanoHTTPD.Response response2 = SimpleWebServer.newFixedLengthResponse(status, "text/html", stringBuilder2.toString());
            response2.addHeader("Location", string4);
            return response2;
        }
        if (file2.isDirectory()) {
            String string5 = this.findIndexFileInDirectory(file2);
            if (string5 == null) {
                if (file2.canRead()) {
                    return SimpleWebServer.newFixedLengthResponse(NanoHTTPD.Response.Status.OK, "text/html", this.listDirectory(string2, file2));
                }
                return this.getForbiddenResponse("No directory listing.");
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string2);
            stringBuilder.append(string5);
            return this.respond(map, iHTTPSession, stringBuilder.toString());
        }
        String string6 = SimpleWebServer.getMimeTypeForFile((String)string2);
        WebServerPlugin webServerPlugin = (WebServerPlugin)mimeTypeHandlers.get((Object)string6);
        if (webServerPlugin != null && webServerPlugin.canServeUri(string2, file)) {
            response = webServerPlugin.serveFile(string2, map, iHTTPSession, file2, string6);
            if (response != null && response instanceof InternalRewrite) {
                InternalRewrite internalRewrite = (InternalRewrite)response;
                return this.respond(internalRewrite.getHeaders(), iHTTPSession, internalRewrite.getUri());
            }
        } else {
            response = this.serveFile(string2, map, file2, string6);
        }
        if (response != null) {
            return response;
        }
        return this.getNotFoundResponse();
    }

    /*
     * Exception decompiling
     */
    private String encodeUri(String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl10 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    private String findIndexFileInDirectory(File file) {
        for (String string : INDEX_FILE_NAMES) {
            if (!new File(file, string).isFile()) continue;
            return string;
        }
        return null;
    }

    /*
     * Exception decompiling
     */
    public static void main(String[] var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl240 : ALOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }

    private NanoHTTPD.Response newFixedFileResponse(File file, String string) throws FileNotFoundException {
        NanoHTTPD.Response response = SimpleWebServer.newFixedLengthResponse((NanoHTTPD.Response.IStatus)NanoHTTPD.Response.Status.OK, (String)string, (InputStream)new FileInputStream(file), (long)((int)file.length()));
        response.addHeader("Accept-Ranges", "bytes");
        return response;
    }

    public static NanoHTTPD.Response newFixedLengthResponse(NanoHTTPD.Response.IStatus iStatus, String string, String string2) {
        NanoHTTPD.Response response = NanoHTTPD.newFixedLengthResponse((NanoHTTPD.Response.IStatus)iStatus, (String)string, (String)string2);
        response.addHeader("Accept-Ranges", "bytes");
        return response;
    }

    protected static void registerPluginForMimeType(String[] arrstring, String string, WebServerPlugin webServerPlugin, Map<String, String> map) {
        if (string != null) {
            if (webServerPlugin == null) {
                return;
            }
            if (arrstring != null) {
                int n = arrstring.length;
                for (int i = 0; i < n; ++i) {
                    String string2 = arrstring[i];
                    int n2 = string2.lastIndexOf(46);
                    if (n2 < 0) continue;
                    String string3 = string2.substring(n2 + 1).toLowerCase();
                    SimpleWebServer.mimeTypes().put((Object)string3, (Object)string);
                }
                INDEX_FILE_NAMES.addAll((Collection)Arrays.asList((Object[])arrstring));
            }
            mimeTypeHandlers.put((Object)string, (Object)webServerPlugin);
            webServerPlugin.initialize(map);
        }
    }

    private NanoHTTPD.Response respond(Map<String, String> map, NanoHTTPD.IHTTPSession iHTTPSession, String string) {
        NanoHTTPD.Response response;
        if (this.cors != null && NanoHTTPD.Method.OPTIONS.equals((Object)iHTTPSession.getMethod())) {
            NanoHTTPD.Response.Status status = NanoHTTPD.Response.Status.OK;
            response = new NanoHTTPD.Response((NanoHTTPD.Response.IStatus)status, "text/plain", null, 0L);
        } else {
            response = this.defaultRespond(map, iHTTPSession, string);
        }
        String string2 = this.cors;
        if (string2 != null) {
            response = this.addCORSHeaders(map, response, string2);
        }
        return response;
    }

    protected NanoHTTPD.Response addCORSHeaders(Map<String, String> map, NanoHTTPD.Response response, String string) {
        response.addHeader("Access-Control-Allow-Origin", string);
        response.addHeader("Access-Control-Allow-Headers", this.calculateAllowHeaders(map));
        response.addHeader("Access-Control-Allow-Credentials", "true");
        response.addHeader("Access-Control-Allow-Methods", ALLOWED_METHODS);
        response.addHeader("Access-Control-Max-Age", "151200");
        return response;
    }

    protected NanoHTTPD.Response getForbiddenResponse(String string) {
        NanoHTTPD.Response.Status status = NanoHTTPD.Response.Status.FORBIDDEN;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FORBIDDEN: ");
        stringBuilder.append(string);
        return SimpleWebServer.newFixedLengthResponse(status, "text/plain", stringBuilder.toString());
    }

    protected NanoHTTPD.Response getInternalErrorResponse(String string) {
        NanoHTTPD.Response.Status status = NanoHTTPD.Response.Status.INTERNAL_ERROR;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("INTERNAL ERROR: ");
        stringBuilder.append(string);
        return SimpleWebServer.newFixedLengthResponse(status, "text/plain", stringBuilder.toString());
    }

    protected NanoHTTPD.Response getNotFoundResponse() {
        return SimpleWebServer.newFixedLengthResponse(NanoHTTPD.Response.Status.NOT_FOUND, "text/plain", "Error 404, file not found.");
    }

    public void init() {
    }

    protected String listDirectory(String string, File file) {
        int n;
        String string2;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Directory ");
        stringBuilder.append(string);
        String string3 = stringBuilder.toString();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("<html><head><title>");
        stringBuilder2.append(string3);
        stringBuilder2.append("</title><style><!--\n");
        stringBuilder2.append("span.dirname { font-weight: bold; }\n");
        stringBuilder2.append("span.filesize { font-size: 75%; }\n");
        stringBuilder2.append("// -->\n");
        stringBuilder2.append("</style>");
        stringBuilder2.append("</head><body><h1>");
        stringBuilder2.append(string3);
        stringBuilder2.append("</h1>");
        StringBuilder stringBuilder3 = new StringBuilder(stringBuilder2.toString());
        String string4 = string.length() > 1 && (n = (string2 = string.substring(0, string.length() - 1)).lastIndexOf(47)) >= 0 && n < string2.length() ? string.substring(0, n + 1) : null;
        List list = Arrays.asList((Object[])file.list((FilenameFilter)new 2(this)));
        Collections.sort((List)list);
        List list2 = Arrays.asList((Object[])file.list((FilenameFilter)new 3(this)));
        Collections.sort((List)list2);
        if (string4 != null || list2.size() + list.size() > 0) {
            stringBuilder3.append("<ul>");
            if (string4 != null || list2.size() > 0) {
                stringBuilder3.append("<section class=\"directories\">");
                if (string4 != null) {
                    stringBuilder3.append("<li><a rel=\"directory\" href=\"");
                    stringBuilder3.append(string4);
                    stringBuilder3.append("\"><span class=\"dirname\">..</span></a></li>");
                }
                for (String string5 : list2) {
                    StringBuilder stringBuilder4 = new StringBuilder();
                    stringBuilder4.append(string5);
                    stringBuilder4.append("/");
                    String string6 = stringBuilder4.toString();
                    stringBuilder3.append("<li><a rel=\"directory\" href=\"");
                    StringBuilder stringBuilder5 = new StringBuilder();
                    stringBuilder5.append(string);
                    stringBuilder5.append(string6);
                    stringBuilder3.append(this.encodeUri(stringBuilder5.toString()));
                    stringBuilder3.append("\"><span class=\"dirname\">");
                    stringBuilder3.append(string6);
                    stringBuilder3.append("</span></a></li>");
                }
                stringBuilder3.append("</section>");
            }
            if (list.size() > 0) {
                stringBuilder3.append("<section class=\"files\">");
                for (String string7 : list) {
                    stringBuilder3.append("<li><a href=\"");
                    StringBuilder stringBuilder6 = new StringBuilder();
                    stringBuilder6.append(string);
                    stringBuilder6.append(string7);
                    stringBuilder3.append(this.encodeUri(stringBuilder6.toString()));
                    stringBuilder3.append("\"><span class=\"filename\">");
                    stringBuilder3.append(string7);
                    stringBuilder3.append("</span></a>");
                    long l = new File(file, string7).length();
                    stringBuilder3.append("&nbsp;<span class=\"filesize\">(");
                    if (l < 1024L) {
                        stringBuilder3.append(l);
                        stringBuilder3.append(" bytes");
                    } else if (l < 0x100000L) {
                        stringBuilder3.append(l / 1024L);
                        stringBuilder3.append(".");
                        stringBuilder3.append(l % 1024L / 10L % 100L);
                        stringBuilder3.append(" KB");
                    } else {
                        stringBuilder3.append(l / 0x100000L);
                        stringBuilder3.append(".");
                        stringBuilder3.append(l % 0x100000L / 10000L % 100L);
                        stringBuilder3.append(" MB");
                    }
                    stringBuilder3.append(")</span></li>");
                }
                stringBuilder3.append("</section>");
            }
            stringBuilder3.append("</ul>");
        }
        stringBuilder3.append("</body></html>");
        return stringBuilder3.toString();
    }

    public NanoHTTPD.Response serve(NanoHTTPD.IHTTPSession iHTTPSession) {
        Map map = iHTTPSession.getHeaders();
        Map map2 = iHTTPSession.getParms();
        String string = iHTTPSession.getUri();
        if (!this.quiet) {
            PrintStream printStream = System.out;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)iHTTPSession.getMethod());
            stringBuilder.append(" '");
            stringBuilder.append(string);
            stringBuilder.append("' ");
            printStream.println(stringBuilder.toString());
            for (String string2 : map.keySet()) {
                PrintStream printStream2 = System.out;
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("  HDR: '");
                stringBuilder2.append(string2);
                stringBuilder2.append("' = '");
                stringBuilder2.append((String)map.get((Object)string2));
                stringBuilder2.append("'");
                printStream2.println(stringBuilder2.toString());
            }
            for (String string3 : map2.keySet()) {
                PrintStream printStream3 = System.out;
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("  PRM: '");
                stringBuilder3.append(string3);
                stringBuilder3.append("' = '");
                stringBuilder3.append((String)map2.get((Object)string3));
                stringBuilder3.append("'");
                printStream3.println(stringBuilder3.toString());
            }
        }
        for (File file : this.rootDirs) {
            if (file.isDirectory()) continue;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("given path is not a directory (");
            stringBuilder.append((Object)file);
            stringBuilder.append(").");
            return this.getInternalErrorResponse(stringBuilder.toString());
        }
        return this.respond((Map<String, String>)Collections.unmodifiableMap((Map)map), iHTTPSession, string);
    }

    /*
     * Exception decompiling
     */
    NanoHTTPD.Response serveFile(String var1, Map<String, String> var2, File var3, String var4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        // java.lang.Thread.run(Thread.java:919)
        throw new IllegalStateException("Decompilation failed");
    }
}

